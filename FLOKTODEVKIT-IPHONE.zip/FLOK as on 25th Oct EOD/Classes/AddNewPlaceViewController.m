//
//  AddNewPlaceViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 07/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AddNewPlaceViewController.h"
#import "PlaceProfileViewController.h"

@implementation AddNewPlaceViewController
@synthesize txtName, txtAddress1, txtAddress2, txtAddress3, txtCity, txtState, txtCountry, txtWebsite;
@synthesize dataSourceArray;
@synthesize arrFieldParams;

//@synthesize userName, passWord;

/*
 - (id)initWithStyle:(UITableViewStyle)style {
 // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 if (self = [super initWithStyle:style]) {
 }
 return self;
 }
 */


- (void)viewDidLoad 
{
	[super viewDidLoad];
	tableFlok.backgroundColor = [UIColor clearColor];
	flagPlaceTypes = NO;
	strPlaceTypeId = @"";
	[strPlaceTypeId retain];
	strTagCsv = @"";
	[strTagCsv retain];
	strPlaceId = @"";
	[strPlaceId retain];
	
	arrPlaceTypes = [[[NSMutableArray alloc] init] retain];
	arrPlaceTags = [[[NSMutableArray alloc] init] retain];

	self.dataSourceArray = [NSMutableArray arrayWithObjects: [NSArray arrayWithObjects:							
						[NSDictionary dictionaryWithObjectsAndKeys: @"Placename", kLabelKey, self.txtName, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"Address1", kLabelKey, self.txtAddress1, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"Address2", kLabelKey, self.txtAddress2, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"Address3", kLabelKey, self.txtAddress3, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"City", kLabelKey, self.txtCity, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"State", kLabelKey, self.txtState, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"Country", kLabelKey, self.txtCountry, kViewKey, nil]
							, [NSDictionary dictionaryWithObjectsAndKeys: @"Website", kLabelKey, self.txtWebsite, kViewKey, nil]
							, nil]
						, [NSArray arrayWithObjects: @"Place Type", @"Place Tags", nil]
						, [NSArray arrayWithObject: @"Submit"]
					, nil];
	
	currRequestNum = 1;
	[self showHUDWithTitle:@"Getting Place Types"];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}
 

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];

//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	if ( flagSelectionDone )
	{
		flagSelectionDone = NO;
		if ( flagPlaceTypes )
		{
			strPlaceTypeId = [[arrSelectedItems objectAtIndex:0] objectAtIndex:1];
			[strPlaceTypeId retain];
		}
		else
		{
			NSMutableString *msg = [[[NSMutableString alloc] init] retain];
			NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
			for ( int i=0; i < [arrSelectedItems count]; i++ )
			{
				NSString *tagid = [[arrSelectedItems objectAtIndex:i] objectAtIndex:1]  ;
				[tagcsv appendFormat:@",%@", tagid ];
				[msg appendFormat:@", %@", [[arrSelectedItems objectAtIndex:i] objectAtIndex:0]];
			}
			strTagCsv = [tagcsv substringFromIndex:1];
			[strTagCsv retain];
			strMessageToTweet = [msg substringFromIndex:1];
			[strMessageToTweet retain];
			[tagcsv release];
			tagcsv = nil;
		}
		[tableFlok reloadData];
	}
}
 
- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@place/gettypes?username=%@&password=%@" 
						 , SESSION_URL ]; 
	else if ( currRequestNum == 2 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/gettags?username=%@&password=%@"
						 , SESSION_URL ];
	else if ( currRequestNum == 3 )
		strRequestUrl = [NSString stringWithFormat:@"%@place/updateplace?username=%@&password=%@&placetypeid=%@%@"
						 , SESSION_URL , strPlaceTypeId, strParameters ];
	else if ( currRequestNum == 4 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/updateplacetag?username=%@&password=%@&placeid=%@&tagcsv=%@"
						 , SESSION_URL , strPlaceId, strTagCsv ]; 

	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl ];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"alreadyexist" ] )
		{
			alert.tag = 40;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"no_same_area" ] )
		{
			alert.tag = 30;
			[alert show];
		}
	}
	else
	{
		if ( currRequestNum == 1 )
		{
			[arrPlaceTypes removeAllObjects];
			[arrPlaceTypes retain];
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[arrPlaceTypes addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"type"], [dicRecord valueForKey:@"placetypeid"], nil] ];
				[arrPlaceTypes retain];
			}
			arrRecords = nil;
			currRequestNum = 2;
			[self fetchJsonData];
//			[self killHUD];
		}
		else if ( currRequestNum == 2 )
		{
			[arrPlaceTags removeAllObjects];
			[arrPlaceTags retain];
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[arrPlaceTags addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"placetagname"], [dicRecord valueForKey:@"placetagid"], nil] ];
				[arrPlaceTags retain];
			}
			arrRecords = nil;
			[self killHUD];
		}
		else if ( currRequestNum == 3 )
		{
			strPlaceId = [dicResponse valueForKey:@"placeid"];
			[strPlaceId retain];
			dicPlaceDetails = [NSDictionary dictionaryWithDictionary:dicResponse];
			[dicPlaceDetails retain];
			NSLog(@"Need to call Tagging this Place view");
			[self killHUD];
			currRequestNum = 4;
			[self showHUDWithTitle:@"Updating Tag info"];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
		else if ( currRequestNum == 4 )
		{
			[self killHUD];
			strMessageToTweet = [NSString stringWithFormat:@"%@ has just tagged %@ as %@ using http://flok.to", kUsername, txtName.text, strMessageToTweet ] ;
			[strMessageToTweet retain];
			//tweeting and facebook comes here
			
			PlaceProfileViewController *placeProfileViewController = [[PlaceProfileViewController alloc] initWithNibName:@"PlaceProfileView" bundle:nil ];
			placeProfileViewController.dicPlaceDetails = dicPlaceDetails;
			[placeProfileViewController.dicPlaceDetails retain];
			[self.navigationController pushViewController:placeProfileViewController animated:YES];
			[placeProfileViewController release];
			placeProfileViewController = nil;
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
}



/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [dataSourceArray count];
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[dataSourceArray objectAtIndex:section] count] ;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    static NSString *CellIdentifier;
	
	int rowID = indexPath.row;
	int secID = indexPath.section;
	UITableViewCell *cell = nil;
	
	if ( secID == 0  )
	{
		CellIdentifier = @"DisplayCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.selectionStyle = UITableViewCellSelectionStyleNone;
//			[cell.textLabel setFrame:  CGRectMake( 5, 12.5, 90, 20)];
			cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
//			cell.textLabel.textAlignment = UITextAlignmentRight;
			cell.textLabel.textColor = [UIColor colorWithRed:0.203754 green:0.335363 blue:0.531151 alpha:1];
		}
		else
		{
			// the cell is being recycled, remove old embedded controls
			UIView *viewToRemove = nil;
			viewToRemove = [cell.contentView viewWithTag: rowID+1];
			if (viewToRemove)
				[viewToRemove removeFromSuperview];
		}
		
		cell.textLabel.text = [[[self.dataSourceArray objectAtIndex: secID] objectAtIndex: rowID] valueForKey:kLabelKey];
		
		UIControl *control = [[[self.dataSourceArray objectAtIndex: secID] objectAtIndex: rowID] valueForKey:kViewKey];
		[cell.contentView addSubview:control];
	}
	else if ( secID == 1 )
	{
		CellIdentifier = @"SourceCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//			cell.textLabel.opaque = NO;
			//			cell.textLabel.textColor = [UIColor blackColor];
			//			cell.textLabel.font = [UIFont systemFontOfSize:13];	
		}
		cell.textLabel.text = [[self.dataSourceArray objectAtIndex: secID] objectAtIndex:rowID];
		if ( rowID )
		{
			if ( ![strTagCsv isEqualToString:@""] )
			{				
				cell.detailTextLabel.text = @"Selected tags";
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			}
			else
			{
				cell.detailTextLabel.text = @"This is a Mandatory Field";
				cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
			}
		}
		else
		{
			if ( ![strPlaceTypeId isEqualToString:@""] )
			{
				cell.detailTextLabel.text = @"Selected a type";
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			}
			else
			{
				cell.detailTextLabel.text = @"This is a Mandatory Field";
				cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
			}
		}
	}
	else
	{
		CellIdentifier = @"SubmitCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			
//			cell.textLabel.opaque = NO;
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			//			cell.textLabel.textColor = [UIColor blackColor];
			//			cell.textLabel.font = [UIFont systemFontOfSize:13];	
		}
		
		cell.textLabel.text = [[self.dataSourceArray objectAtIndex: secID] objectAtIndex:rowID];
	}
	//	cell.backgroundColor = [UIColor clearColor];	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int rowID = indexPath.row;
	int secID = indexPath.section;
	
	if ( secID == 0  )
	{
	}
	else if ( secID == 1 )
	{
		SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
		selectionViewController.choiceViewController = self;
		[selectionViewController.choiceViewController retain];
		if ( rowID )
		{
			flagPlaceTypes = NO;
			selectionViewController.arrRecords = [NSArray arrayWithArray:arrPlaceTags];
			selectionViewController.strInstructions = @"Select between 1 and 5 tags";
			selectionViewController.noOfSelectionsNeeded = 5;
		}
		else
		{
			flagPlaceTypes = YES;
			selectionViewController.arrRecords = [NSArray arrayWithArray:arrPlaceTypes];
			selectionViewController.strInstructions = @"Select One of the Place Types";
			selectionViewController.noOfSelectionsNeeded = 1;
		}
		[selectionViewController.arrRecords retain];
		[selectionViewController.strInstructions retain];
		[self.navigationController pushViewController:selectionViewController animated:YES];
		[selectionViewController release];
		selectionViewController = nil;
	}
	else
	{
		BOOL flagInvalidRegistration = NO;
		NSMutableString *strTemp = [[[NSMutableString alloc] initWithString:@"&placeid=0"] retain];
		if ( ! [strPlaceTypeId isEqualToString:@""] && ![strTagCsv isEqualToString:@""] )
		{
			for ( NSDictionary *dicRecord in [self.dataSourceArray objectAtIndex: 0] )
			{
				UITextField *currTextField = [dicRecord valueForKey:kViewKey];
				[strTemp appendFormat:@"&%@=%@", [[dicRecord valueForKey:kLabelKey] lowercaseString], currTextField.text ];
				if ( (currTextField.tag == 3) || (currTextField.tag == 4) || (currTextField.tag == 8) )
				{
				}
				else
				{
					if ( [currTextField.text isEqualToString:@""] )
						flagInvalidRegistration = YES;
				}
				if ( flagInvalidRegistration )
					break;
			}
		}
		else
			flagInvalidRegistration = YES;
		if ( ! flagInvalidRegistration )
		{
			strParameters = [NSString stringWithFormat:@"%@", strTemp ];
			[strParameters retain];
			[strTemp release];
			currRequestNum = 3;
			[self showHUDWithTitle:@"Adding Place"];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
			//			[self showHUDWithTitle:@"Updating Profile"];
			//			currRequestNum = 2;
			//			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
		else
		{
			[strTemp release];
			NSLog(@"Invalid selection");
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Insufficient Data" message:@"You have missed some Mandatory fields" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alert show];
		}
	}
}

#pragma mark textField Methods
//- (void)textFieldDidBeginEditing:(UITextField *)textField
//{
//	if ( textField.tag > 3 )
//	{
//		CGRect rc = [textField bounds];
//		UITableView * v = tableFlok;
//		rc = [textField convertRect:rc toView:v];
//		CGPoint pt = rc.origin ;
//		pt.x = 0 ;
//		//	pt.y = 20;
//		[v setContentOffset:pt animated:YES];
//	}
//}

//- (void)textFieldDidEndEditing:(UITextField *)textField
//{
//}


#pragma mark Text Filed Functions
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
//	if ( textField.tag > 3 )
//	{
//		CGRect rc = [textField bounds];
//		UITableView * v = tableFlok;
//		rc = [textField convertRect:rc toView:v];
//		CGPoint pt = rc.origin ;
//		pt.x = 0 ;
//		pt.y = 0;
//		[v setContentOffset:pt animated:YES];
//	}
	[textField resignFirstResponder];
	return YES;
}


- (void) setTextField : (UITextField *) currTextField
{
	[currTextField setFrame:CGRectMake( 100, 7, 190, 31)];
	if ( (currTextField.tag == 1) || (currTextField.tag == 8) )
	{
		if ( currTextField.tag == 1 )
			currTextField.placeholder = @"This is a Mandatory Field";
		currTextField.clearsOnBeginEditing = NO;
		currTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
		currTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
	}
	else
		currTextField.userInteractionEnabled = NO;
	currTextField.text = [arrFieldParams objectAtIndex:currTextField.tag-1];
	currTextField.font = [UIFont systemFontOfSize:14];		
	currTextField.delegate = self;
	currTextField.borderStyle = UITextBorderStyleRoundedRect;
	currTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
}

#pragma mark Lazy creation of controls

- (UITextField *) txtName
{
	if (txtName == nil)
	{
		txtName = [[UITextField alloc] init];
		txtName.tag = 1;
		[self setTextField:txtName];
	}
	return txtName;
}

- (UITextField *) txtAddress1
{
	if (txtAddress1 == nil)
	{
		txtAddress1 = [[UITextField alloc] init];
		txtAddress1.tag = 2;
		[self setTextField:txtAddress1];
	}
	return txtAddress1;
}

- (UITextField *) txtAddress2
{
	if (txtAddress2 == nil)
	{
		txtAddress2 = [[UITextField alloc] init];
		txtAddress2.tag = 3;
		[self setTextField:txtAddress2];
	}
	return txtAddress2;
}

- (UITextField *) txtAddress3
{
	if (txtAddress3 == nil)
	{
		txtAddress3 = [[UITextField alloc] init];
		txtAddress3.tag = 4;
		[self setTextField:txtAddress3];
	}
	return txtAddress3;
}

- (UITextField *) txtCity
{
	if (txtCity == nil)
	{
		txtCity = [[UITextField alloc] init];
		txtCity.tag = 5;
		[self setTextField:txtCity];
	}
	return txtCity;
}

- (UITextField *) txtState
{
	if (txtState == nil)
	{
		txtState = [[UITextField alloc] init];
		txtState.tag = 6;
		[self setTextField:txtState];
	}
	return txtState;
}

- (UITextField *) txtCountry
{
	if (txtCountry == nil)
	{
		txtCountry = [[UITextField alloc] init];
		txtCountry.tag = 7;
		[self setTextField:txtCountry];
	}
	return txtCountry;
}

- (UITextField *) txtWebsite
{
	if (txtWebsite == nil)
	{
		txtWebsite = [[UITextField alloc] init];
		txtWebsite.tag = 8;
		[self setTextField:txtWebsite];
	}
	return txtWebsite;
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of AddNewPlaceViewController");
	[txtName release];
	[txtAddress1 release];
	[txtAddress2 release];
	[txtAddress3 release];
	[txtCity release];
	[txtState release];
	[txtCountry release];
	[txtWebsite release];

	[tableFlok release];
	[dataSourceArray release];
	[arrPlaceTypes release];
	[arrPlaceTags release];
	[strPlaceId release];
	[strParameters release];
	[strTagCsv release];
	[strPlaceId release];
	dicPlaceDetails = nil;
	[strMessageToTweet release];
	arrFieldParams = nil;
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of AddNewPlaceViewController");
}


@end


//
//  MapViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "AnnotationController.h"

typedef enum {
	SearchPlacesIdLike = 0,
	SearchPlacesByTag,
	SearchPersonLikeMe,
	SearchPersonByTag
} FLOKSearchStyle;


@interface MapViewController : UIViewController <MKMapViewDelegate>
{
	IBOutlet UIButton *tagNewPlaceBtn;
	IBOutlet MKMapView *mapViewFlok;
	FLOKSearchStyle searchStyle;
	NSString *strTagCsv, *strPlaceTypeId;
	int currRequestNum, currZoomLevel;
	NSArray *arrOriginalRecords;
	AnnotationController *newAnnotation;
	NSMutableArray *arrAnnos, *arrRecords;
	NSMutableArray *arrButtons;
	CLLocationCoordinate2D currUserCoordinate;
	BOOL flagInitialSetup;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, assign) FLOKSearchStyle searchStyle;
@property (nonatomic, retain) NSString *strTagCsv, *strPlaceTypeId;

//- (IBAction) placesBtnAction;
//- (IBAction) peopleBtnAction;
- (void) loadAnnotations;
//- (void) showAddress;
- (IBAction) tagNewPlaceBtnAction;

#pragma mark Map Clustering
- (int) pixelDistanceOfLat1: (float)lat1 andLon1: (float) lon1 andLat2: (float) lat2 andLon2: (float) lon2 andZoom: (int) zoom;
- (float) latToY: (float) lat ;
- (float) lonToX: (float) lon ;
- (NSMutableArray *)  clusterMarkers: (NSMutableArray *) unClusteredMarkers andDistance:(int) distance andZoom: (int) zoom ;
- (int) getZoomLevel;

@end

//
//  PlacesByTagViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PlacesByTagViewController.h"
#import "MapViewController.h"

@implementation PlacesByTagViewController

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];
	
	currRequestNum = 0;
	tableFlok.backgroundColor = [UIColor clearColor];
	arrTableData = [[[NSMutableArray alloc] initWithObjects:@"Select a Tag", @"Select a Type", @"Done", nil] retain];
	arrTagData = [[[NSMutableArray alloc] init] retain];
	arrSelectedTypes = [[[NSMutableArray alloc] initWithObjects:@"", @"", nil] retain]; 
	
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
//	[arrTableData addObject:[[[NSMutableArray alloc] initWithObjects:
}



- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
	//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	
	if ( flagSelectionDone )
	{
		flagSelectionDone = NO;
		NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
		NSMutableString *tagname = [[[NSMutableString alloc] init] retain];
		for ( NSArray *arrTypeData in arrSelectedItems )
		{
			[tagcsv appendFormat:@",%@", [arrTypeData objectAtIndex:1] ];
			[tagname appendFormat:@", %@", [arrTypeData objectAtIndex:0] ];
		}
		[arrSelectedTypes replaceObjectAtIndex:currCatgNum withObject:[tagcsv substringFromIndex:1] ];
		[arrSelectedTypes retain];
		[arrTableData replaceObjectAtIndex:currCatgNum withObject:[tagname substringFromIndex:2] ];
		[arrTableData retain];
		[tagcsv release];
		[tagname release];
//			else
//		{
//			MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
//			if (currRequestNum == 1)
//				mapViewController.searchStyle = SearchPlacesByTag;
//			else
//				mapViewController.searchStyle = SearchPersonByTag;
//			mapViewController.strTagCsv = [tagcsv substringFromIndex:1];
//			[mapViewController.strTagCsv retain];
//			[self.navigationController pushViewController: mapViewController animated:YES];
//			[mapViewController release];
//			mapViewController = nil;
//		}
		[arrSelectedItems removeAllObjects];
		[arrSelectedItems retain];
		[tableFlok reloadData];
	}
}

/*
- (void)viewDidAppear:(BOOL)animated 
{
	[super viewDidAppear:animated];	
		currRequestNum = 5;
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}
*/


- (IBAction) placesByTagBtnAction
{
	
	currRequestNum = 1;
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}


- (void) fetchJsonData
{
	NSString *strUrl;
	if ( currRequestNum == 0 )
		strUrl = [NSString stringWithFormat:@"%@placetag/getplacearchetypes?username=%@&password=%@"
				  , SESSION_URL ];
	else if ( currRequestNum == 1 )
		strUrl = [NSString stringWithFormat:@"%@place/gettypes?username=%@&password=%@"
				  , SESSION_URL ];
//	else if ( currRequestNum == 2 )
//		strUrl = [NSString stringWithFormat:@"%@placetag/searchplacebytagtype?username=%@&password=%@&archetypeid=%@&placetypeid=%@"
//				  , SESSION_URL, strArcheTypeCsv, strPlaceTypeCsv ];
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			//			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			//			[alert show];
		}
		else
			alert.tag = 20;
		[alert show];
	}
	else
	{
		if ( currRequestNum == 1)
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableArray *arrTemp = [[[NSMutableArray alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[arrTemp addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"type"], [dicRecord valueForKey:@"placetypeid"], nil] ];
				[arrTemp retain];
			}
			arrRecords = nil;
			[arrTagData addObject:[NSArray arrayWithArray:arrTemp] ];
			[arrTagData retain];
			[self killHUD];
		}
		else if ( currRequestNum == 0 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableArray *arrTemp = [[[NSMutableArray alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[arrTemp addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"arche_type"], [dicRecord valueForKey:@"placetagid"], nil] ];
				[arrTemp retain];
			}
			arrRecords = nil;
			[arrTagData addObject:[NSArray arrayWithArray:arrTemp]];
			[arrTagData retain];
			currRequestNum = 1;
			[self fetchJsonData];
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [arrTableData count];
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier;// = @"Cell";
	int secID = indexPath.section;
    
	if ( secID == 2 )
	{
		CellIdentifier = @"Done Cell";
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			cell.accessoryType = UITableViewCellAccessoryNone;
		}
		
		// Set up the cell...
		cell.textLabel.text = [arrTableData objectAtIndex:secID];
		
		return cell;
	}
	else
	{
		CellIdentifier = @"Cell";
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		}
		
		// Set up the cell...
		cell.textLabel.text = [arrTableData objectAtIndex:secID];
		if ( [[arrSelectedTypes objectAtIndex:secID] isEqualToString:@""] )
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		else
			cell.accessoryType = UITableViewCellAccessoryCheckmark;
		
		return cell;
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int secID = indexPath.section;

	if ( secID == 2 )
	{
		if ( [[arrSelectedTypes objectAtIndex:0] isEqualToString:@""] && [[arrSelectedTypes objectAtIndex:1] isEqualToString:@""] )
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Please select atleast arche type or place type." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];
			[tableView deselectRowAtIndexPath:indexPath animated:YES];
		}
		else
		{
			MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
			mapViewController.searchStyle = SearchPlacesByTag;
			mapViewController.strTagCsv = [arrSelectedTypes objectAtIndex:0];
			[mapViewController.strTagCsv retain];
			mapViewController.strPlaceTypeId = [arrSelectedTypes objectAtIndex:1];
			[mapViewController.strPlaceTypeId retain];
			[self.navigationController pushViewController: mapViewController animated:YES];
			[mapViewController release];
			mapViewController = nil;
		}
	}
	else
	{
		currCatgNum = secID;
		flagSelectionDone = NO;
		SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
		selectionViewController.arrRecords = [arrTagData objectAtIndex:secID];
		[selectionViewController.arrRecords retain];
		selectionViewController.strInstructions = @"Select any one of the types below";
		[selectionViewController.strInstructions retain];
		selectionViewController.noOfSelectionsNeeded = 1;
		selectionViewController.choiceViewController = self;
		[selectionViewController.choiceViewController retain];
		[self.navigationController pushViewController:selectionViewController animated:YES];
		[selectionViewController release];
		selectionViewController = nil;
	}
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of PlacesByTagViewController");
   	[imgViewTheme release];
	[tableFlok release];
	[arrTagData release];
	[arrTableData release];
	[arrSelectedTypes release];
	[super dealloc];
	NSLog(@"Completed dealloc of PlacesByTagViewController");
}

@end


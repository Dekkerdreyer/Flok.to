//
//  MyProfileViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MyProfileViewController.h"
#import "AvatarViewController.h"
#import "ProfileQuestionsViewController.h"

@implementation MyProfileViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	[webViewTags setBackgroundColor:[UIColor whiteColor]];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadTagInfo)	name:NOTF_ClearedTags object:nil];

	dicCredentials = [NSMutableDictionary dictionaryWithDictionary: [self retrieveCredentials:kLoginFile ]];
	[dicCredentials retain];
	lblSince.text = [NSString stringWithFormat:@"Part of the Flok since %@", [[dicCredentials objectForKey:@"cd"] substringToIndex:10]];
	lblName.text = [[dicCredentials objectForKey:@"username"] capitalizedString];
	flagReloadProfile = YES;
	flagEditTags = NO;
	strSelfTags = @"";
	[strSelfTags retain];
//	imgViewAvatar.image = [UIImage imageWithContentsOfFile:[self getFullFilePath:kAvatarFile]];
//	[self loadBackGround];

	
}

- (void)viewWillAppear:(BOOL)animated 
{
    [super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	imgViewAvatar.image = [UIImage imageWithContentsOfFile:[self getFullFilePath:kAvatarFile]];
	if ( flagReloadProfile )
		[self loadBackGround];
}

- (void)viewDidAppear:(BOOL)animated 
{
    [super viewDidAppear:animated];
	lblTweet.text = [self getLatestTweet];
}

- (NSString *) getLatestTweet
{
	NSString *strTweet = @"";
	[strTweet retain];
	if ( kTwitterAuthorized ) 
	{
		OAuth *oAuth = [[[OAuth alloc] initWithConsumerKey:TWITTER_OAUTH_CONSUMER_KEY andConsumerSecret:TWITTER_OAUTH_CONSUMER_SECRET ] retain];
		[oAuth loadOAuthTwitterContextFromUserDefaults];
		if (oAuth.oauth_token_authorized)
			NSLog(@"authorized ");
		else
			NSLog(@"Not authorized ");
		//	NSLog(@"Logged in as %@.", oAuth.screen_name);
		ASIFormDataRequest *request = nil;
		NSString *getUrl = [NSString stringWithFormat: @"https://api.twitter.com/1/users/show.json?user_id=%@", oAuth.user_id];
		[getUrl retain];
		[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
		for ( int retryCount = 0; retryCount < 3; retryCount ++ )
		{
			request = [[ASIHTTPRequest alloc]   initWithURL:[NSURL URLWithString:getUrl] ];
			
			[request addRequestHeader:@"Authorization" 
								value: [oAuth oAuthHeaderForMethod:@"GET"   andUrl:getUrl	andParams:nil] ];
			
			[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
			[request startSynchronous];
			[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
			
			NSLog(@"HTTP result code: %d\n ", request.responseStatusCode);
			if ( request.responseStatusCode == 200 )
				break;
			else if ( retryCount < 2 )
				[request release];
		}
		NSLog(@"Response message:%@, HTTP result code: %d", request.responseStatusMessage, request.responseStatusCode);
		if ( request.responseStatusCode == 200 )
		{
			NSDictionary *dicResult = [NSDictionary dictionaryWithDictionary: [[request responseString] JSONValue]];    
			if ( dicResult )
			{
				dicResult = [dicResult valueForKey:@"status"];
				if ( dicResult )
				{
					if ( [dicResult valueForKey:@"text"] )
					{
						strTweet = [dicResult valueForKey:@"text"];
						[strTweet retain];
					}
				}
			}
		}
		[request release];
		[getUrl release];
		[oAuth release];
	}
	return [strTweet autorelease];
}

- (void) reloadTagInfo
{
	flagReloadProfile = YES;
}

- (void) loadBackGround
{
	[self showHUDWithTitle:@"Downloading Info" ];
	
	flagReloadProfile = NO;	
	currRequestNum = 1;	
	
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

- (void) loadTagInfo
{
	NSString *strRequestUrl = [NSString stringWithFormat:@"%@usertag/gettagsbyother?username=%@&password=%@" , 
							   SESSION_URL ]; 
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSString *strTagInfo = [NSString stringWithContentsOfURL:[NSURL URLWithString: [strRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] encoding:NSUTF8StringEncoding error:nil];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
	[webViewTags loadHTMLString:strTagInfo baseURL:nil];
	
	//	NSURLRequest *requestObj = [NSURLRequest requestWithURL: [NSURL URLWithString: [strRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] ];
	//	[webViewTags loadRequest:requestObj];	
	
	[self killHUD];
//	if ( flagUpdatedTags )
//	{
//		flagUpdatedTags = NO;
//		strMessageToTweet = [NSString stringWithFormat:@"%@ has just tagged %@ as %@ using http://flok.to", kUsername, lblName.text, strMessageToTweet ] ;
//		[strMessageToTweet retain];
//		flagUpdatedFacebook = NO;
//		flagUpdatedTwitter = NO;
//		[self statusUpdation];
//	}
}


- (void) continueSelfTagging
{
	ProfileQuestionsViewController *profileQuestionsViewController = [[ProfileQuestionsViewController alloc] initWithNibName:@"ProfileQuestionsView" bundle:nil];
	profileQuestionsViewController.dicCredentials = dicCredentials;
	[profileQuestionsViewController.dicCredentials retain];
	profileQuestionsViewController.view.frame = self.view.frame;
	if ( flagEditTags )
	{
		profileQuestionsViewController.strPreSelectedTags = strSelfTags;
		[profileQuestionsViewController.strPreSelectedTags retain];
	}
	[self.navigationController pushViewController:profileQuestionsViewController animated:YES];
	[profileQuestionsViewController release];
	profileQuestionsViewController = nil;
}

- (void) continueAvatarUpdation
{
	AvatarViewController *avatarViewController = [[AvatarViewController alloc] initWithNibName:@"AvatarView" bundle:nil];
	
	avatarViewController.dicCredentials = dicCredentials;
	[avatarViewController.dicCredentials retain];
	avatarViewController.imgAvatar = imgViewAvatar.image;
	[avatarViewController.imgAvatar retain];
	avatarViewController.view.frame = self.view.frame;
	[self.navigationController pushViewController:avatarViewController animated:YES];
	[avatarViewController release];
	avatarViewController = nil;
}

- (IBAction) clearTagsBtnAction
{
//	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"You have opted to clear your tags. This will clear all tags, including your own self-selected profile tags, from this profile" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Proceed", nil] autorelease];
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"You have opted to clear your tags. This will clear all tags, including your own self-selected profile tags, from this profile" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Clear All Tags", @"Clear Tags given by Others", nil] autorelease];
	alert.tag = 35;
	[alert show];
}

- (IBAction) avatarBtnAction
{
	[self continueAvatarUpdation];
}

- (IBAction) editBtnAction
{
	flagReloadProfile = YES;
	flagEditTags = YES;
	[self continueSelfTagging];
}

- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/getselftags?username=%@&password=%@"
						 , SESSION_URL ];
	else if ( currRequestNum == 2 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/gettagsbyother?username=%@&password=%@"
						 , SESSION_URL ]; 
	else if ( currRequestNum == 3 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/clearalltags?username=%@&password=%@"
						 , SESSION_URL ]; 
	else if ( currRequestNum == 4 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/clearalltags?username=%@&password=%@&tags=%@"
						 , SESSION_URL, @"all" ]; 
	else if ( currRequestNum == 5 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/clearalltags?username=%@&password=%@&tags=%@"
						 , SESSION_URL , @"byothers"]; 
	
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"nodata" ] )
		{
			if ( currRequestNum == 1 )
			{
				txtViewSelf.text = @"No tags at this moment";
				currRequestNum = 2;
				[self showHUDWithTitle:@"Downloading Info" ];
				[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTagInfo) userInfo:nil repeats:NO];
			}
//			else if ( currRequestNum == 2 )
//				txtViewOthers.text = @"No tags at this moment";
		}
	}
	else
	{
		if ( currRequestNum == 1 || currRequestNum == 2 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableString *strTags = [[[NSMutableString alloc] init] retain];
			NSMutableString *strTagIds = [[[NSMutableString alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[strTags appendFormat:@",  %@", [dicRecord valueForKey:@"tagname"] ];
				[strTagIds appendFormat:@",%@", [dicRecord valueForKey:@"tagid"]];
			}
			if ( currRequestNum == 1 )
			{
				if ( [strTags length] > 3 )
					txtViewSelf.text = [strTags substringFromIndex:3];
				if ( [strTagIds length] > 1 )
					strSelfTags = [strTagIds substringFromIndex:1];
				[strSelfTags retain];
			}
				
//			else
//				txtViewOthers.text = [strTags substringFromIndex:3];
			[strTags release];
			[strTagIds release];
			arrRecords = nil;
			if ( currRequestNum == 1 )
			{
				currRequestNum = 2;
				[self loadTagInfo];
			}
			else
				[self killHUD];
		}
		else if ( currRequestNum == 3 )
		{
			if ( [dicResponse objectForKey:@"successmsg"] )
			{
				txtViewSelf.text = @"";
//				txtViewOthers.text = @"";
				[self killHUD];
				[self continueSelfTagging];
			}
		}
		else if ( currRequestNum == 4 )
		{
			if ( [dicResponse objectForKey:@"successmsg"] )
			{
				txtViewSelf.text = @"";
				//				txtViewOthers.text = @"";
				[self killHUD];
				[self continueSelfTagging];
			}
		}
		else if ( currRequestNum == 5 )
		{
			[self loadTagInfo];
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if (alertView.tag == 30 )
	{
		if (currRequestNum == 1 )
		{
			currRequestNum = 2;
			[self showHUDWithTitle:@"Downloading Info" ];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTagInfo) userInfo:nil repeats:NO];
		}
	}
	else if (alertView.tag == 25)
	{
		if (buttonIndex)
		{
			flagReloadProfile = YES;
			[self showHUDWithTitle:@"Deleting Tags" ];
			currRequestNum = 3;		
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
	}
	else if (alertView.tag == 35)
	{
		if (buttonIndex == 1)
		{
			flagReloadProfile = YES;
			[self showHUDWithTitle:@"Deleting All Tags" ];
			currRequestNum = 4;		
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
		else if (buttonIndex == 2)
		{
			flagReloadProfile = YES;
			[self showHUDWithTitle:@"Deleting Tags by others" ];
			currRequestNum = 5;		
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
	}
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of MyProfileViewController");
	[lblTweet release];
	[lblSince release];
	[lblName release];
	[txtViewSelf release];
	[imgViewAvatar release];
	dicCredentials = nil;
	if ( [webViewTags isLoading] )
		[webViewTags stopLoading];
	[webViewTags release];
	[strSelfTags release];
  	[imgViewTheme release];
  [super dealloc];
	NSLog(@"Completed dealloc of MyProfileViewController");
}


@end

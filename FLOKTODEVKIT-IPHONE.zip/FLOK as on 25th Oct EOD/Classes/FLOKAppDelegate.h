//
//  FLOKAppDelegate.h
//  FLOK
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "MBProgressHUD.h"

@interface FLOKAppDelegate : NSObject <UIApplicationDelegate> 
{    
	UIWindow *window;
	UINavigationController *navigationController;
	MBProgressHUD *HUD;
	
	//	Global Variables
	
//	NSString *gUserName, *gPassword;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, retain) MBProgressHUD *HUD;

//@property (nonatomic, retain) NSString *gUserName, *gPassword;

@end


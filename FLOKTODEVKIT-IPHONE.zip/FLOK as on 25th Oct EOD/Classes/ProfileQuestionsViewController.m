//
//  ProfileQuestionsViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ProfileQuestionsViewController.h"


@implementation ProfileQuestionsViewController

@synthesize dicCredentials;
@synthesize strSelectedItems, strPreSelectedTags;

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];
	
	currRequestNum = 1;
	currCatgNum = 3;
	flagTagDataIsReady = NO;
	if ( [dicCredentials objectForKey:@"tagsStatus"] )
	{
		self.view.frame = CGRectMake( 0, 0, 320, 460 );
		tableFlok.frame = CGRectMake( 0, 0, 320, 460 );
	}
	
	arrSectionHeaders = [[NSArray arrayWithObjects: @"Which of these tags best describe you?", @"What kinds of music do you enjoy most?", @"Which of these activities sound like fun?", @"I'm done!", nil ]retain];
	arrTagData = [[[NSMutableArray alloc] init]retain];
	arrSelections = [[[NSMutableArray alloc] init] retain];
	for ( int i=0; i < 3; i++ )
	{
		[arrTagData addObject:[[[NSMutableArray alloc] init] autorelease] ];
		[arrSelections addObject:[[[NSMutableArray alloc] init] autorelease] ];
	}
	[arrTagData retain];
	[arrSelections retain];
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
	
	if ( flagSelectionDone )
	{
		flagSelectionDone = NO;
		if ( currCatgNum < 3)
		{
			for ( NSArray *arrItem in arrSelectedItems )
				[[arrSelections objectAtIndex:currCatgNum] addObject:[NSArray arrayWithArray:arrItem] ];
			[arrSelections retain];
			currCatgNum = 3;
			[tableFlok reloadData];
		}
	}
}


- (void) fetchJsonData
{
	NSString *strUrl;
	if ( currRequestNum == 1 )
		strUrl = [NSString stringWithFormat:@"%@usertag/gettagcategories?username=%@&password=%@"
					  , SESSION_URL ];
	else if ( currRequestNum == 2 )
		strUrl = [NSString stringWithFormat:@"%@user/getuserdetails?username=%@&password=%@"
					  , SESSION_URL ];
	else if ( currRequestNum == 3 )
		strUrl = [NSString stringWithFormat:@"%@usertag/updateusertag?username=%@&password=%@&touserid=%@&tagcsv=%@"
					  , SESSION_URL, kUserID, strSelectedItems ];
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
		}
		else
			alert.tag = 20;
		[alert show];
	}
	else
	{
		if ( currRequestNum == 1 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			for ( NSDictionary *dicRecord in arrRecords )
			{
				int i = [[dicRecord valueForKey:@"categoryid"] intValue] ;
				if ( i == 1 )
				{
					[[arrTagData objectAtIndex:1] addObject:[NSArray arrayWithObjects: [dicRecord valueForKey:@"tagname"], [dicRecord valueForKey:@"tagid"], nil ]];
				}
				else if ( i == 2)
				{
					[[arrTagData objectAtIndex:0] addObject:[NSArray arrayWithObjects: [dicRecord valueForKey:@"tagname"], [dicRecord valueForKey:@"tagid"], nil ]];
				}
				else
				{
					[[arrTagData objectAtIndex:2] addObject:[NSArray arrayWithObjects: [dicRecord valueForKey:@"tagname"], [dicRecord valueForKey:@"tagid"], nil ]];
				}
				dicRecord = nil;
			}
			[arrTagData retain];
			arrRecords = nil;
			if ( strPreSelectedTags )
			{
				[self loadPreselections];
			}
			flagTagDataIsReady = YES;
			[tableFlok reloadData];
			[self killHUD];
		}
		else if ( currRequestNum == 2 )
		{
			userId = [dicResponse objectForKey:@"userid"];
			[userId retain];
//			dicUserInfo = [NSDictionary dictionaryWithDictionary:dicResponse];
//			[dicUserInfo retain];
			currRequestNum = 3;
			[self fetchJsonData];			
		}
		else if ( currRequestNum == 3 )
		{
			[self killHUD];
			if ( [dicCredentials objectForKey:@"tagsStatus"] )
			{
//				[dicCredentials setObject:@"1" forKey:@"tagsStatus"];
//				[dicCredentials retain];
//				[self saveCredentials:dicCredentials toFile:kProfileCreationFile];
				NSString *filePath = [self getFullFilePath:kProfileCreationFile];
				if ( [[NSFileManager defaultManager] removeItemAtPath:filePath error:NULL] )
					NSLog(@"Successfully deleted  %@", filePath);
				else
					NSLog(@" Failed to delete %@", filePath);
				
				[self saveCredentials:dicResponse toFile:kLoginFile];
				[self.navigationController popToRootViewControllerAnimated:YES];
			}
			else
			{
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_ClearedTags object:nil];
				strMessageToTweet = [NSString stringWithFormat:@"%@ has just tagged %@ as %@ using http://flok.to", kUsername, @"self", strMessageToTweet ] ;
				[strMessageToTweet retain];
				NSLog(@" strMessageToTweet is '%@' ", strMessageToTweet);
				//tweeting and facebook comes here
				
				[self.navigationController popViewControllerAnimated:YES];
			}
		}
			
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
}

- (void) loadPreselections
{
	NSMutableArray *arrTemp = [[[NSMutableArray alloc] initWithArray:[strPreSelectedTags componentsSeparatedByString:@","]] retain];
//	NSArray *arrTemp = [strPreSelectedTags componentsSeparatedByString:@","];
	[arrTemp retain];
	for ( int i = 0; i < 3; i++ )
	{
		int maxCount = [[arrTagData objectAtIndex:i] count];
		for ( int j=0, found = 0; ( (j < maxCount) && (found < 3) ); j++)
		{
			for ( NSString *tagID in arrTemp )
			{
				if ( [tagID isEqualToString:[[[arrTagData objectAtIndex:i]objectAtIndex:j] objectAtIndex:1] ] )
				{
					found++;
					NSArray *modArray = [NSArray arrayWithObjects:[[[arrTagData objectAtIndex:i]objectAtIndex:j] objectAtIndex:0], tagID, @"1", nil];
					[[arrTagData objectAtIndex:i] replaceObjectAtIndex:j withObject:modArray];
					[arrTagData retain];
					[arrTemp removeObject:tagID];
					if ( ! [arrTemp count] )
						found = 3;
					break;
				}
			}
		}
	}
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if (flagTagDataIsReady)
		return [arrSectionHeaders count];
	else
		return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if ( indexPath.section == 3 )
		return 40;
	else
		return 45;
}

//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
//{
//	if (flagTagDataIsReady)
//		return [arrSectionHeaders objectAtIndex:section];
//	else
//		return nil;
//}
//
//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
//{
//	if (flagTagDataIsReady)
//		return [NSArray arrayWithObjects:@"Attributes", @"Music", @"Activities", @"Submit", nil];
//	else
//		return nil;
//}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if (flagTagDataIsReady)
		return 1;
	else
		return 0;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier;
	int secID = indexPath.section;
	UITableViewCell *cell = nil;
	if ( secID == 3 )
	{
		CellIdentifier = @"Submit Cell";
		
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			cell.accessoryType = UITableViewCellAccessoryNone;
		}
//		cell.textLabel.text = @"Submit";			
	}
	else
	{
		CellIdentifier = @"Tag Cell";
		
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
//			cell.textLabel.numberOfLines = 0;
//			cell.backgroundColor = [UIColor groupTableViewBackgroundColor];
		}
		
		// Set up the cell...

		if ( [[arrSelections objectAtIndex:secID] count] )
		{
			cell.detailTextLabel.text = [NSString stringWithFormat:@"Selected %d tags", [[arrSelections objectAtIndex:secID] count]  ];
			cell.accessoryType = UITableViewCellAccessoryCheckmark;
		}
		else
		{
			cell.detailTextLabel.text = @"Yet to select tags for this category";
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		}
	}
	NSArray *arrTemp = [NSArray arrayWithObjects:@"Attributes", @"Music", @"Activities", @"Update my tags", nil];
	cell.textLabel.text = [arrTemp objectAtIndex:secID];
	return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int secID = indexPath.section;
	if ( indexPath.section == 3 )
	{
		BOOL invalidSelections = NO;
		for ( int i = 0; i < 3; i++ )
		{
			if ( ! [[arrSelections objectAtIndex:i] count] )
			{
				invalidSelections = YES;
				break;
			}
		}	
		if ( ! invalidSelections )
		{
			NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
			NSMutableString *msg = [[[NSMutableString alloc] init] retain];
			for ( int i = 0; i < 3; i++ )
			{
				int j = 0;
				BOOL flagPluralTags = NO;
				int count = [[arrSelections objectAtIndex:i] count];
				if ( count > 1 )
					flagPluralTags = YES;
				for ( NSArray *arrTagItem in [arrSelections objectAtIndex:i] )
				{
					[tagcsv appendFormat:@",%@", [arrTagItem objectAtIndex:1] ];
					if ( flagPluralTags && (j++ == count - 1) )
						[msg appendFormat:@" and %@", [arrTagItem objectAtIndex:0]];
					else
						[msg appendFormat:@", %@", [arrTagItem objectAtIndex:0]];
				}
			}
			strSelectedItems = [tagcsv substringFromIndex:1];
			[strSelectedItems retain];
			[tagcsv release];
			strMessageToTweet = [msg substringFromIndex:1];
			[strMessageToTweet retain];
			[msg release];
			currRequestNum = 3;
			[self showHUDWithTitle:@"Updating Tag Info"];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
//			[self showHUDWithTitle:@"Updating Profile"];
//			currRequestNum = 2;
//			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
		else
		{
			NSLog(@"Invalid selection");
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Invalid Selection" message:@"You have to select exactly 3 Tags from each category" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alert show];
		}
	}
	else
	{
		[[arrSelections objectAtIndex:secID] removeAllObjects];
		[arrSelections retain];
		currCatgNum = secID;
		
		SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
		selectionViewController.arrRecords = [NSArray arrayWithArray:[arrTagData objectAtIndex:secID]];
		[selectionViewController.arrRecords retain];
		selectionViewController.strInstructions = [arrSectionHeaders objectAtIndex:secID];
		[selectionViewController.strInstructions retain];
		selectionViewController.noOfSelectionsNeeded = 3;
		selectionViewController.choiceViewController = self;
		[selectionViewController.choiceViewController retain];
		if ( [dicCredentials objectForKey:@"tagsStatus"] )
			selectionViewController.flagNeedResize = YES;
		if ( strPreSelectedTags )
			selectionViewController.flagPreselectionReqd = YES;
		[self.navigationController pushViewController:selectionViewController animated:YES];
		[selectionViewController release];
		selectionViewController = nil;		
	}
}

- (void) updateProfile
{
	[self killHUD];
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of ProfileQuestionsViewController");
	dicCredentials = nil;
	dicUserInfo = nil;
	[arrTableData release];
	[arrTagData release];
	[arrSelections release];
	[arrPreSelections release];
	arrSectionHeaders = nil;
	[strSelectedItems release];
	[userId release];
	[tableFlok release];
	[strMessageToTweet release];
	if ( strPreSelectedTags )
		[strPreSelectedTags release];
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of ProfileQuestionsViewController");
}


@end


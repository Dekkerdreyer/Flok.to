#import "MyCLController.h"

@implementation MyCLController

@synthesize locationManager;
@synthesize delegate;
@synthesize locationMeasurements;
@synthesize bestEffortAtLocation;

- (id) init {
	self = [super init];
	if (self != nil) {
		self.locationManager = [[[CLLocationManager alloc] init] autorelease];
		self.locationManager.delegate = self; // send loc updates to myself
		self.locationMeasurements = [NSMutableArray array];
	}
	return self;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation 
{
	// store all of the measurements, just so we can see what kind of data we might receive
	[locationMeasurements addObject:newLocation];

	// test the age of the location measurement to determine if the measurement is cached
	// in most cases you will not want to rely on cached measurements
	NSTimeInterval locationAge = -[newLocation.timestamp timeIntervalSinceNow];
	if (locationAge > 5.0) return;

	// test that the horizontal accuracy does not indicate an invalid measurement
	if (newLocation.horizontalAccuracy < 0) return;

	// test the measurement to see if it is more accurate than the previous measurement
	if (bestEffortAtLocation == nil || bestEffortAtLocation.horizontalAccuracy > newLocation.horizontalAccuracy) 
	{
		// store the location as the "best effort"		
		self.bestEffortAtLocation = newLocation;
	}

	
	[self.delegate locationUpdate:newLocation];
}


- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
	[self.delegate locationError:error];
}

- (void)dealloc {
	NSLog(@"Entered dealloc of MyCLController");
	[self.locationManager release];
	[locationMeasurements release];
	[bestEffortAtLocation release];
    [super dealloc];
	NSLog(@"Completed dealloc of MyCLController");
}

@end


//
//  MapViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MapViewController.h"
#import "PersonProfileViewController.h"
#import "PlaceProfileViewController.h"
#import "AcceptNewPlaceViewController.h"
#import "MapDetailViewController.h"


@implementation MapViewController

@synthesize searchStyle;
@synthesize strTagCsv, strPlaceTypeId;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	//	arrRecords = [[[NSMutableArray alloc] init]retain];
	arrAnnos = [[[NSMutableArray alloc] init]retain];
	arrButtons = [[[NSMutableArray alloc] init]retain];
	arrRecords = [[[NSMutableArray alloc] init] retain];
	flagInitialSetup = YES;
	
	if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
	{
		tagNewPlaceBtn.userInteractionEnabled = YES;
		tagNewPlaceBtn.hidden = NO;
	}
	
	
	currUserCoordinate.latitude = [kUser_Latitude floatValue];
	currUserCoordinate.longitude = [kUser_Longitude floatValue];
	
	MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(currUserCoordinate, 20000, 20000);
	MKCoordinateRegion adjustedRegion = [mapViewFlok regionThatFits:viewRegion];
	[mapViewFlok setRegion:adjustedRegion];
	
	mapViewFlok.centerCoordinate = currUserCoordinate;
	//	mapViewFlok.userLocation = coordinate;
	//	mapViewFlok.showsUserLocation = NO;	
	
	//	[self addUserLocation];
	currZoomLevel = [self getZoomLevel];
	
	
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval:0.2  target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

- (void) addUserLocation
{
	newAnnotation = [[[AnnotationController alloc] initWithCoordinate:currUserCoordinate] retain];
	newAnnotation.annTitle = kUsername;
	newAnnotation.annSubTitle = @"You are Here";
	newAnnotation.annTag = 0;
	newAnnotation.annType = AnnUser;
	newAnnotation.annImage = [NSString stringWithFormat:@"Pin-%@.png", @"User"];
	[arrAnnos addObject:newAnnotation];
	[arrAnnos retain];
	[newAnnotation release];
	newAnnotation = nil;
}

/*
 - (IBAction) placesBtnAction
 {
 imgViewBtnBG.image = [UIImage imageNamed:@"patta_right.png"];
 }
 
 - (IBAction) peopleBtnAction
 {
 imgViewBtnBG.image = [UIImage imageNamed:@"patta_left.png"];
 }
 */

- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( searchStyle == SearchPersonByTag )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/searchuserbytag?username=%@&password=%@&tagcsv=%@"
						 , SESSION_URL, strTagCsv]; 
	else if ( searchStyle == SearchPersonLikeMe )
		strRequestUrl = [NSString stringWithFormat:@"%@user/searchpeoplelikeme?username=%@&password=%@"
						 , SESSION_URL ];
	else if ( searchStyle == SearchPlacesByTag )
//		strRequestUrl = [NSString stringWithFormat:@"%@placetag/searchplacebytag?username=%@&password=%@&tagcsv=%@"
//						 , SESSION_URL, strTagCsv]; 
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/searchplacebytagtype?username=%@&password=%@&archetypeid=%@&placetypeid=%@"
				  , SESSION_URL, strTagCsv, strPlaceTypeId ];
	else if ( searchStyle == SearchPlacesIdLike )
		strRequestUrl = [NSString stringWithFormat:@"%@place/searchplacesilike?username=%@&password=%@"
						 , SESSION_URL ]; 
	
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"nodata" ] )
		{
			alert.message = @"Sorry. No results match right now";
			alert.tag = 10;
			[alert show];
			if ( currRequestNum == 1 )
			{
			}
			//			else if ( currRequestNum == 2 )
		}
		else if ( [errMsg isEqualToString:@"not_enough_info" ] )
		{
			alert.tag = 20;
			[alert show];
		}
		else
		{
			alert.tag = 30;
			[alert show];
		}
	}
	else
	{
		arrOriginalRecords = [dicResponse objectForKey:@"jsonResult"];
		[arrOriginalRecords retain];
		dicResponse = nil;
		[self killHUD];
		[self loadAnnotations];
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	[super alertView:alertView didDismissWithButtonIndex:buttonIndex];
}


#pragma mark MKMapView Functions Start

- (void) loadAnnotations
{	
	if ( ! flagInitialSetup )
	{
		[mapViewFlok removeAnnotations:arrAnnos];
		[arrAnnos removeAllObjects];
		[arrAnnos retain];
		[arrRecords removeAllObjects];
		[arrRecords retain];
	}
	[self addUserLocation];
	NSLog(@"currZoomLevel is '%d' ", currZoomLevel);

	//	NSLog(@"currZoomLevel is '%d' \n initial array is \n%@", currZoomLevel, arrOriginalRecords);
	arrRecords = [self clusterMarkers:[NSMutableArray arrayWithArray:arrOriginalRecords] andDistance:60 andZoom:currZoomLevel ];
	[arrRecords retain];
	//	NSLog(@"Clustered array is \n%@", arrRecords);
	
	for ( int i=0; i<[arrRecords count]; i++ )
	{
		NSArray *clusteredRecord = [arrRecords objectAtIndex:i];
		CLLocationCoordinate2D coordinate;
		NSString *title = nil;
		int count = [clusteredRecord count];
		if ( count > 1 )
		{
			float newLat = 0.0;
			float newLong = 0.0;
			
			NSMutableString *newTitle = [[[NSMutableString alloc] init] retain];
			for (NSDictionary *dicRecord in clusteredRecord) 
			{
				newLat += [[dicRecord valueForKey:kLat] floatValue] / count;
				newLong += [[dicRecord valueForKey:kLong] floatValue] / count;
				if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
				{
					[newTitle appendFormat:@", %@", [dicRecord valueForKey:@"username"]];
				}
				else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
				{
					[newTitle appendFormat:@", %@", [dicRecord valueForKey:@"placename"]];
				}
			}
			coordinate.latitude = newLat;
			coordinate.longitude = newLong;
			title = [newTitle substringFromIndex:2];
			[title retain];
			[newTitle release];
		}
		else
		{
			NSDictionary *dicRecord = [clusteredRecord objectAtIndex:0];
			coordinate.latitude = [[dicRecord valueForKey:@"latitude"] floatValue];
			coordinate.longitude = [[dicRecord valueForKey:@"longitude"] floatValue];
			if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
			{
				title = [dicRecord valueForKey:@"username"];
			}
			else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
			{
				title = [dicRecord valueForKey:@"placename"];
			}
			[title retain];
		}
		newAnnotation = [[[AnnotationController alloc] initWithCoordinate:coordinate] retain];
		newAnnotation.annTag = i+1;
		newAnnotation.annTitle = [NSString stringWithFormat:@"Number of matches: %d ", count ];
//		if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
//		{
//			newAnnotation.annTitle = [NSString stringWithFormat:@"No.of Persons: %d ", count ];
//		}
//		else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
//		{
//			newAnnotation.annTitle = [NSString stringWithFormat:@"No.of Places: %d ", count ];
//		}
		[newAnnotation.annTitle retain];
		newAnnotation.annSubTitle = [NSString stringWithString: title];
		[newAnnotation.annSubTitle retain];
		if ( count < 6 )
		{
			newAnnotation.annType = AnnBlue;
			newAnnotation.annImage = kPinBlue;
		}
		else if ( count < 10 )
		{
			newAnnotation.annType = AnnGreen;
			newAnnotation.annImage = kPinGreen;
		}
		else if ( count < 20 )
		{
			newAnnotation.annType = AnnYellow;
			newAnnotation.annImage = kPinYellow;
		}
		else if ( count < 50 )
		{
			newAnnotation.annType = AnnOrange;
			newAnnotation.annImage = kPinOrange;
		}
		else
		{
			newAnnotation.annType = AnnRed;
			newAnnotation.annImage = kPinRed;
		}
		[newAnnotation.annImage retain];
		[arrAnnos addObject: newAnnotation];
		[arrAnnos retain];
		[newAnnotation release];	
		newAnnotation = nil;
		[title release];
		//		[clusteredRecord release];
	}
	[mapViewFlok addAnnotations:arrAnnos];	
	//	[self killHUD];
	flagInitialSetup = NO;
}


#pragma mark Map Clustering

- (int) getZoomLevel
{
	return 21 - (int ) log2(mapViewFlok.region.span.longitudeDelta * RADIUS * M_PI / (180.0 * mapViewFlok.bounds.size.width));
}

- (float) lonToX: (float) lon 
{
	return round( OFFSET  + RADIUS * lon * M_PI / 180);        
}

- (float) latToY: (float) lat 
{
	return round(OFFSET - RADIUS * log ( (1 + sin(lat * M_PI / 180) ) / (1 - sin(lat * M_PI / 180) ) ) / 2);
}

- (int) pixelDistanceOfLat1: (float)lat1 andLon1: (float) lon1 andLat2: (float) lat2 andLon2: (float) lon2 andZoom: (int) zoom
{
	float x1 = [self lonToX:lon1];
	float y1 = [self latToY: lat1];
	float x2 = [self lonToX:lon2];
	float y2 = [self latToY: lat2];	
	return   (int) sqrt(pow((x1-x2),2) + pow((y1-y2),2))  >> (21 - zoom);
}

- (NSMutableArray *)  clusterMarkers: (NSMutableArray *) unClusteredMarkers andDistance:(int) distance andZoom: (int) zoom 
{
	NSMutableArray *arrClusteredMarkers = [[[NSMutableArray alloc] init] autorelease];
	
	//	Loop until all markers have been compared. 
	while ([unClusteredMarkers count]) 
	{
		NSDictionary *currMarker = [unClusteredMarkers lastObject];
		[unClusteredMarkers removeLastObject];
		NSMutableArray *newCluster = [[[NSMutableArray alloc] init] autorelease];
		
		//	Compare against all markers which are left. 
		for ( int i=0; i < [unClusteredMarkers count]; i++ )
		{
			NSDictionary *target = [unClusteredMarkers objectAtIndex:i];
			int pixels = [self pixelDistanceOfLat1:[[currMarker objectForKey:kLat] floatValue] andLon1:[[currMarker objectForKey:kLong] floatValue] andLat2:[[target objectForKey:kLat] floatValue] andLon2:[[target objectForKey:kLong] floatValue] andZoom:zoom];
			
			//	 If two markers are closer than given distance remove target marker from array and add it to cluster.   
//			NSLog(@"Distance between '%@','%@' and '%@','%@' is '%d' pixels.\n", 
//				  [currMarker objectForKey:kLat], [currMarker objectForKey:kLong], [target objectForKey:kLat], [target objectForKey:kLong], pixels) ;
			if (distance > pixels) 
			{
				[unClusteredMarkers removeObjectAtIndex:i--];
				[newCluster addObject:[NSDictionary dictionaryWithDictionary: target]];
			}
		}
		
		//	If a marker has been added to cluster, add also the one  we were comparing to
		if ( [newCluster count] ) 
		{
			[newCluster addObject:[NSDictionary dictionaryWithDictionary: currMarker]];
			[arrClusteredMarkers addObject:[NSArray arrayWithArray: newCluster]];
		}
		else 
		{
			[arrClusteredMarkers addObject:[NSArray arrayWithObject:currMarker]];
		}
	}
	return arrClusteredMarkers;
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
	if ( ! flagInitialSetup )
	{
		//		[self showHUDWithTitle:@"Refreshing Map"];
		//		[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(loadAnnotations) userInfo:nil repeats:NO];	
		//		[mapViewFlok removeAnnotations: [mapViewFlok annotations]];
		int newZoomLevel = [self getZoomLevel];
		if ( newZoomLevel != currZoomLevel )
		{
			currZoomLevel = newZoomLevel;
			[self loadAnnotations];
		}
//		NSLog(@"currZoomLevel is '%d' ", currZoomLevel);
	}
}

//- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
//{
//}


- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{	
	
	AnnotationController *currAnnotation = (AnnotationController *) annotation;
	MKAnnotationView *annotationView = nil;
	static NSString *AnnotationIdentifier;// = [NSString stringWithFormat:@"%@", annotation.annImage];
	switch ( currAnnotation.annType ) 
	{
		case AnnUser:
			AnnotationIdentifier = kPinUser;
			break;
		case AnnBlue:
			AnnotationIdentifier = kPinBlue;
			break;
		case AnnGreen:
			AnnotationIdentifier = kPinGreen;
			break;
		case AnnYellow:
			AnnotationIdentifier = kPinYellow;
			break;
		case AnnOrange:
			AnnotationIdentifier = kPinOrange;
			break;
		case AnnRed:
			AnnotationIdentifier = kPinRed;
			break;
		default:
			break;
	}
	
	annotationView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationIdentifier];
	if (! annotationView)
	{
		annotationView = [[[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier] autorelease];
		annotationView.enabled = YES;
		annotationView.canShowCallout = YES;
		annotationView.centerOffset = CGPointMake( 0,-13);
		annotationView.calloutOffset = CGPointMake( 0, 0);	
//		annotationView.alpha = 0.75;
		annotationView.image = [UIImage imageNamed:currAnnotation.annImage];
	}
	annotationView.tag = currAnnotation.annTag;
	if ( currAnnotation.annType == AnnUser )
	{
		annotationView.rightCalloutAccessoryView = nil;
		annotationView.frame = CGRectMake(0, 0, 50, 35);
	}
	else
	{
		annotationView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];	
		annotationView.frame = CGRectMake(0, 0, 50, 35);
	}
	//	else
	//		annotationView.annotation=annotation;
	return annotationView;
	
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
	//	AnnotationController *currAnnotation = (AnnotationController *) view.annotation;
	int index = view.tag - 1;
	MapDetailViewController *mapDetailViewController = [[MapDetailViewController alloc] initWithNibName:@"MapDetailView" bundle:nil];
	if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
		mapDetailViewController.flagPlaces = NO;
	else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
		mapDetailViewController.flagPlaces = YES;
	mapDetailViewController.arrTableData = [arrRecords objectAtIndex:index];
	[mapDetailViewController.arrTableData retain];
	[self.navigationController pushViewController:mapDetailViewController animated:YES];
	[mapDetailViewController release];
	mapDetailViewController = nil;
}
/*
 //	Old code for map detail view
 AnnotationController *currAnnotation = view.annotation;	
 NSDictionary *dicRecord;
 BOOL flagNeedToBreak = NO;
 for ( dicRecord in arrRecords )
 {
 if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
 {
 //			addAnnotation.annTitle = [dicRecord valueForKey:@"username"];
 if ( currAnnotation.annTag == [[dicRecord valueForKey:@"userid"] intValue] )
 {
 flagNeedToBreak = YES;
 }
 }
 else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
 {
 if ( currAnnotation.annTag == [[dicRecord valueForKey:@"placeid"] intValue] )
 {
 flagNeedToBreak = YES;				
 }
 }
 if ( flagNeedToBreak )
 break;
 }
 if ( flagNeedToBreak )
 {
 if ( (searchStyle == SearchPersonByTag ) || ( searchStyle == SearchPersonLikeMe ) )
 {
 PersonProfileViewController *personProfileViewController = [[PersonProfileViewController alloc] initWithNibName:@"PersonProfileView" bundle:nil ];
 personProfileViewController.dicProfileInfo = dicRecord;
 [personProfileViewController.dicProfileInfo retain];
 [self.navigationController pushViewController:personProfileViewController animated:YES];
 [personProfileViewController release];
 personProfileViewController = nil;
 }
 else if ( ( searchStyle == SearchPlacesByTag ) || ( searchStyle == SearchPlacesIdLike ) )
 {
 PlaceProfileViewController *placeProfileViewController = [[PlaceProfileViewController alloc] initWithNibName:@"PlaceProfileView" bundle:nil ];
 placeProfileViewController.dicPlaceDetails = dicRecord;
 [placeProfileViewController.dicPlaceDetails retain];
 [self.navigationController pushViewController:placeProfileViewController animated:YES];
 [placeProfileViewController release];
 placeProfileViewController = nil;
 }
 }
 else
 NSLog(@"Bug");
 */ 


#pragma mark MKMapView Functions End

#pragma mark RemoveAllAnnotations

// -(void)removeAnnos
//{
//	 NSArray *arr=[mapView.annotations filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"!(self isKindOfClass: %@)", [MKUserLocation class]]];//[[NSMutableArray alloc] init];
//	 for(id<MKAnnotation> annotation in arr)
//	 {
//	 [mapView removeAnnotation:annotation];	
//	 }
//	 
//	 [arrYards removeAllObjects];
//	 arrYards=nil;
//	 
//	 arrYards=[[[NSMutableArray alloc] init] retain];
// }
// 
// */


- (IBAction) tagNewPlaceBtnAction
{
	AcceptNewPlaceViewController *acceptNewPlaceViewController = [[AcceptNewPlaceViewController alloc] initWithNibName:@"AcceptNewPlaceView" bundle:nil];
	[self.navigationController pushViewController:acceptNewPlaceViewController animated:YES];
	[acceptNewPlaceViewController release];
	acceptNewPlaceViewController = nil;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of MapViewController");
	[tagNewPlaceBtn release];
	[mapViewFlok release];
	[strTagCsv release];
	if (strPlaceTypeId)
		[strPlaceTypeId release];
	arrOriginalRecords = nil;
	if ( newAnnotation )
		[newAnnotation release];
	[arrAnnos release];
	[arrRecords release];
	[arrButtons release];
	[imgViewTheme release];
	
    [super dealloc];
	NSLog(@"Completed dealloc of MapViewController");
}

@end

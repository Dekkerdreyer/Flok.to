//
//  PlaceProfileViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 05/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PlaceProfileViewController.h"
#import "FacebookLoginViewController.h"


@implementation PlaceProfileViewController

@synthesize dicPlaceDetails;//, userName, passWord;
@synthesize flagUpdatedFacebook, flagUpdatedTwitter, strMessageToTweet;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
//	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];

	[webViewTags setBackgroundColor:[UIColor whiteColor]];

	flagUpdatedFacebook = YES;
	flagUpdatedTwitter = YES;
	strMessageToTweet = @"";
	[strMessageToTweet retain];
	strPreSelectedTags = @"";
	[strPreSelectedTags retain];
	
	lblName.text = [dicPlaceDetails valueForKey:@"placename"];
	lblAddress.text = [NSString stringWithFormat:@"%@, %@, %@" ,[dicPlaceDetails valueForKey:@"address1"] ,[dicPlaceDetails valueForKey:@"address2"] ,[dicPlaceDetails valueForKey:@"address3"] ];
	lblCity.text = [dicPlaceDetails valueForKey:@"city"];
	lblState.text = [dicPlaceDetails valueForKey:@"state"];
	lblCountry.text = [dicPlaceDetails valueForKey:@"country"];
	lblWebsite.text = [dicPlaceDetails valueForKey:@"website"];
	
	strPlaceId = [dicPlaceDetails valueForKey:@"placeid"];
	[strPlaceId retain];
	strTagCsv = @"4,5,6";
	[strTagCsv retain];
	dicPlaceDetails = nil;
	currRequestNum = 1;
	
	[self showHUDWithTitle:@"Getting Tag Info"];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTagInfo) userInfo:nil repeats:NO];
	
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	if ( flagSelectionDone )
	{
		flagSelectionDone = NO;
		if (currRequestNum == 2)
		{
			NSMutableString *msg = [[[NSMutableString alloc] init] retain];
			NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
			BOOL flagPluralTags = NO;
			int count = [arrSelectedItems count];
			if ( count > 1 )
				flagPluralTags = YES;
			for ( int i=0, j=0; i < [arrSelectedItems count]; i++, j++ )
			{
				[tagcsv appendFormat:@",%@",  [[arrSelectedItems objectAtIndex:i] objectAtIndex:1]];
				if ( flagPluralTags && (j == count - 1) )
					[msg appendFormat:@" and %@", [[arrSelectedItems objectAtIndex:i] objectAtIndex:0]];
				else
					[msg appendFormat:@", %@", [[arrSelectedItems objectAtIndex:i] objectAtIndex:0]];
			}
			strTagCsv = [tagcsv substringFromIndex:1];
			[strTagCsv retain];
			strMessageToTweet = [msg substringFromIndex:1];
			[strMessageToTweet retain];
			[tagcsv release];
			tagcsv = nil;
			
			currRequestNum = 3;
			[self showHUDWithTitle:@"Updating Tag Info"];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
	}
//	if ( ![strMessageToTweet isEqualToString:@"" ] )
//	{
//		if ( !flagUpdatedFacebook || ! flagUpdatedTwitter )
//			[self statusUpdation];
//	}
}

/*
- (void) statusUpdation
{
	if ( ! flagUpdatedFacebook )
	{
		if ( kNeedsUpdationForFB )
		{
			if ( kNeedsAlertForFB )
			{
				[self showFacebookUpdateAlert:strMessageToTweet];
				flagUpdatedFacebook = YES;
				return;
			}
			else
			{
				NSString *responseId = nil;
				if ( kFacebookToken ) 
				{
					responseId = [self updateOnFacebook: strMessageToTweet ];
					flagUpdatedFacebook = YES;
				}
				if ( !responseId )
				{
					FacebookLoginViewController *facebookLoginViewController = [[FacebookLoginViewController alloc] initWithNibName:@"FacebookLoginView" bundle:nil];
					facebookLoginViewController.strMessage = strMessageToTweet;
					[facebookLoginViewController.strMessage retain];
					[self.navigationController pushViewController:facebookLoginViewController animated:YES];
					[facebookLoginViewController release];
					facebookLoginViewController = nil;
					flagUpdatedFacebook = YES;
					return;
				}
				
			}
		}
		else
		{
			flagUpdatedFacebook = YES;
		}
	}
	if ( flagUpdatedFacebook )
	{
		if ( !flagUpdatedTwitter )
		{
			flagUpdatedTwitter = YES;
			if ( kNeedsUpdationForTW )
				if ( kNeedsAlertForTW )
					[self showTwitterUpdateAlert:strMessageToTweet];
				else
					[self updateOnTwitter:strMessageToTweet];
			strMessageToTweet = @"";
			[strMessageToTweet retain];
		}
	}
}
*/

- (void) statusUpdation
{
	if ( kFacebookToken ) 
	{
		NSString *responseId = [self updateOnFacebook: strMessageToTweet ];
		NSLog(@"Facebook update response is %@", responseId);
	}
	if ( kTwitterAuthorized ) 
	{
		int responseId = [self postTweet: strMessageToTweet ];
		NSLog(@"Twitter update response is %d", responseId);
	}
}


- (void) loadTagInfo
{
	NSString *strRequestUrl = [NSString stringWithFormat:@"%@placetag/getplacetagshtml?username=%@&password=%@&placeid=%@" 
							   , SESSION_URL, strPlaceId ]; 
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSString *strTagInfo = [NSString stringWithContentsOfURL:[NSURL URLWithString: [strRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] encoding:NSUTF8StringEncoding error:nil];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
	[webViewTags loadHTMLString:strTagInfo baseURL:nil];
	
	//	NSURLRequest *requestObj = [NSURLRequest requestWithURL: [NSURL URLWithString: [strRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] ];
	//	[webViewTags loadRequest:requestObj];	
	
	if (currRequestNum == 3)
	{
		strMessageToTweet = [NSString stringWithFormat:@"%@ has just tagged %@ as %@ using http://flok.to", kUsername, lblName.text, strMessageToTweet ] ;
		[strMessageToTweet retain];
		NSLog(@"strMessageToTweet is '%@' ", strMessageToTweet);
		flagUpdatedFacebook = NO;
		flagUpdatedTwitter = NO;
		[self statusUpdation];
	}
	[self killHUD];
}


- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/getplacetags?username=%@&password=%@&placeid=%@" 
						 , SESSION_URL, strPlaceId ]; 
	else if ( currRequestNum == 2 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/gettags?username=%@&password=%@"
						 , SESSION_URL ];
	else if ( currRequestNum == 3 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/updateplacetag?username=%@&password=%@&placeid=%@&tagcsv=%@"
						 , SESSION_URL , strPlaceId, strTagCsv ]; 
	else if ( currRequestNum == 4 )
		strRequestUrl = [NSString stringWithFormat:@"%@placetag/getplacetagsbyuser?username=%@&password=%@&placeid=%@"
						 , SESSION_URL , strPlaceId ]; 
	
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"nodata" ] )
		{
			if ( currRequestNum == 1 )
			{
//				txtViewTags.text = @"No tags at this moment";
			}
			else if ( currRequestNum == 2 )
			{
			}
			else if ( currRequestNum == 4 )
			{
				strPreSelectedTags = @"";
				[strPreSelectedTags retain];
				currRequestNum = 2;
				[self fetchJsonData];
			}
		}
	}
	else
	{
		if ( currRequestNum == 1 || currRequestNum == 3 )
		{
//			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
//			dicResponse = nil;
//			NSMutableString *strTags = [[[NSMutableString alloc] init] retain];
//			for ( NSDictionary *dicRecord in arrRecords )
//			{
//				[strTags appendFormat:@",  %@", [dicRecord valueForKey:@"placetagname"] ];
//			}
//			txtViewTags.text = [strTags substringFromIndex:3];
//			[strTags release];
//			arrRecords = nil;
//			[self killHUD];
			if (currRequestNum == 3)
			{
				if ( [[dicResponse valueForKey:@"unlockedtags"] isEqualToString:@""] )
				{
					[self loadTagInfo];
				}
				else
				{
					[self killHUD];
					NSString *msg = [NSString stringWithFormat:@"You've unlocked the '%@' tag!  Now you can tag yourself and others as '%@'.  Keep tagging more people and places to unlock more hidden tags", [dicResponse valueForKey:@"unlockedtags"] , [dicResponse valueForKey:@"unlockedtags"]];
					UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:nil message: msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
					alert.tag = 95;
					[alert show];
				}
//				strMessageToTweet = [NSString stringWithFormat:@"%@ has just tagged %@ as %@ using http://flok.to", kUsername, lblName.text, strMessageToTweet ] ;
//				[strMessageToTweet retain];
//				flagUpdatedFacebook = NO;
//				flagUpdatedTwitter = NO;
//				[self statusUpdation];
			}
		}
		else if ( currRequestNum == 2 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			[arrRecords retain];
			dicResponse = nil;
			NSMutableArray *arrTags = [[[NSMutableArray alloc] init] retain];
			[self killHUD];
			
			SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
			selectionViewController.strInstructions = @"Select between 1 and 5 tags";
			[selectionViewController.strInstructions retain];
			selectionViewController.noOfSelectionsNeeded = 5;
			if ( ![strPreSelectedTags isEqualToString:@""] )
			{
				selectionViewController.flagPreselectionReqd = YES;
				
				NSMutableArray *arrTemp = [[[NSMutableArray alloc] initWithArray:[strPreSelectedTags componentsSeparatedByString:@","]] retain];
				[arrTemp retain];
				for ( NSDictionary *dicRecord in arrRecords )
				{
					BOOL flagFound = NO;
					if ( [arrTemp count] )
					{
						int i=0;
						for ( NSString *tagID in arrTemp )
						{
							if ( [tagID isEqualToString:[dicRecord valueForKey:@"placetagid" ]] )
							{
								flagFound = YES;
								[arrTags addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"placetagname"] ,  tagID, @"1", nil] ];
								[arrTags retain];
								
								[arrTemp removeObjectAtIndex:i];
								[arrTemp retain];
								break;
							}
							i++;
						}
					}
					if ( !flagFound )
					{
						[arrTags addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"placetagname"] , [dicRecord valueForKey:@"placetagid"], nil] ];
						[arrTags retain];
					}
				}
				[arrTemp release];
			}
			else
			{
				for ( NSDictionary *dicRecord in arrRecords )
					[arrTags addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"placetagname"] , [dicRecord valueForKey:@"placetagid"], nil] ];
			}
			[arrRecords release];
			selectionViewController.arrRecords = [NSArray arrayWithArray:arrTags];
			[selectionViewController.arrRecords retain];
			selectionViewController.choiceViewController = self;
			[selectionViewController.choiceViewController retain];
			[self.navigationController pushViewController:selectionViewController animated:YES];
			[selectionViewController release];
			selectionViewController = nil;
			[arrTags release];
		}
		if ( currRequestNum == 4 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableString *strTagIds = [[[NSMutableString alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[strTagIds appendFormat:@",%@", [dicRecord valueForKey:@"placetagid"]];
			}
			if ( [strTagIds length] > 1 )
				strPreSelectedTags = [strTagIds substringFromIndex:1];
			else
				strPreSelectedTags = @"";
			[strPreSelectedTags retain];			
			[strTagIds release];
			arrRecords = nil;
			currRequestNum = 2;
			[self fetchJsonData];
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	[super alertView:alertView didDismissWithButtonIndex:buttonIndex];
	if ( alertView.tag == kAlertFacebooUpdate )
	{
		flagUpdatedFacebook = YES;
		[self statusUpdation];
	}
	else if ( alertView.tag == 95 )
	{
		[self showHUDWithTitle:@"Updating Profile"];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector (loadTagInfo) userInfo:nil repeats:NO];
	}
}

- (IBAction) tagBtnAction
{
	currRequestNum = 4;
	[self showHUDWithTitle:@"Getting Tag Info"];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of PlaceProfileViewController");
	[lblName release];
	[lblAddress release];
	[lblCity release];
	[lblState release];
	[lblCountry release];
	[lblWebsite release];
	[strPlaceId release];
	[strTagCsv release];
	dicPlaceDetails = nil;
	[strMessageToTweet release];
	if ( [webViewTags isLoading] )
		[webViewTags stopLoading];
	[webViewTags release];
	[strPreSelectedTags release];
	[imgViewTheme release];

    [super dealloc];
	NSLog(@"Completed dealloc of PlaceProfileViewController");
}

@end

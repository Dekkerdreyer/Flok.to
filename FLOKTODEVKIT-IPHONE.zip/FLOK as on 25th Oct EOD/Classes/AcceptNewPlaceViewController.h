//
//  AcceptNewPlaceViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 19/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AcceptNewPlaceViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
{
//	IBOutlet UIImageView *imgViewTheme;
	UITextField *txtName, *txtAddress1, *txtAddress2, *txtAddress3, *txtCity, *txtState, *txtCountry, *txtWebsite;
	IBOutlet UITableView *tableFlok;
	NSMutableArray *dataSourceArray, *arrFieldParams;//, *arrPlaceTypes, *arrPlaceTags;
	NSString *strParameters;//,*strPlaceTypeId,  *strTagCsv, *strPlaceId;//*userName, *passWord, 
	int currRequestNum;
	NSMutableDictionary *dicPlaceDetails;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) UITextField *txtName, *txtAddress1, *txtAddress2, *txtAddress3, *txtCity, *txtState, *txtCountry, *txtWebsite;
@property (nonatomic, retain) NSMutableArray *dataSourceArray;
//@property (nonatomic, retain) NSString *userName, *passWord;

- (void) setTextField : (UITextField *) currTextField;

@end

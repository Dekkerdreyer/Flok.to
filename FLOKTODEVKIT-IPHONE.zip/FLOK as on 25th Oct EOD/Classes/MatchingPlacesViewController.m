//
//  MatchingPlacesViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 19/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MatchingPlacesViewController.h"
#import "PlaceProfileViewController.h"
#import "AddNewPlaceViewController.h"

@implementation MatchingPlacesViewController

@synthesize arrFieldParams, arrTableData;

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/

- (void)viewDidLoad {
    [super viewDidLoad];
	
	tableFlok.backgroundColor = [UIColor clearColor];	
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if (section)
		return 1;
	else
		return [arrTableData count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier;
	UITableViewCell *cell = nil;
	if ( indexPath.section )
	{
		CellIdentifier = @"Cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
		}
		// Set up the cell...
		cell.textLabel.text = @"Continue with adding new place";
	}
	else
	{
		CellIdentifier = @"Place Cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		}
		// Set up the cell...
		NSDictionary *dicRecord = [arrTableData objectAtIndex:indexPath.row];
		cell.textLabel.text = [dicRecord valueForKey:@"placename"];
		cell.detailTextLabel.text = [dicRecord valueForKey:@"address1"];
		dicRecord = nil;
	}
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	if ( indexPath.section )
	{
		AddNewPlaceViewController *addNewPlaceViewController = [[AddNewPlaceViewController alloc] initWithNibName:@"AddNewPlaceView" bundle:nil];
		addNewPlaceViewController.arrFieldParams = [NSArray arrayWithArray:arrFieldParams];
		[addNewPlaceViewController.arrFieldParams retain];
		[self.navigationController pushViewController:addNewPlaceViewController animated:YES];
		[addNewPlaceViewController release];
		addNewPlaceViewController = nil;
	}
	else
	{
		PlaceProfileViewController *placeProfileViewController = [[PlaceProfileViewController alloc] initWithNibName:@"PlaceProfileView" bundle:nil ];
		placeProfileViewController.dicPlaceDetails = [arrTableData objectAtIndex:indexPath.row];
		[placeProfileViewController.dicPlaceDetails retain];
		[self.navigationController pushViewController:placeProfileViewController animated:YES];
		[placeProfileViewController release];
		placeProfileViewController = nil;
	}
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of MatchingPlacesViewController");
	arrTableData = nil;
	arrFieldParams = nil;
	[tableFlok release];
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of MatchingPlacesViewController");
}

@end


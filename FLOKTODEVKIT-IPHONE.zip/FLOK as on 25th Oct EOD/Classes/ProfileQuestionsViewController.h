//
//  ProfileQuestionsViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"
#import "SelectionViewController.h"

@interface ProfileQuestionsViewController : ChoiceViewController 
{
	NSMutableDictionary *dicCredentials;
	NSDictionary *dicUserInfo;
	NSMutableArray *arrTableData, *arrTagData, *arrSelections, *arrPreSelections;
	NSArray *arrSectionHeaders;
	NSString *strSelectedItems;
	NSString *userId;
	int currRequestNum, currCatgNum;
	IBOutlet UITableView *tableFlok;
	BOOL flagTagDataIsReady;
	NSString *strMessageToTweet;
	NSString *strPreSelectedTags;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSMutableDictionary *dicCredentials;
@property (nonatomic, retain) NSString *strSelectedItems, *strPreSelectedTags ;

- (void) loadPreselections;

@end

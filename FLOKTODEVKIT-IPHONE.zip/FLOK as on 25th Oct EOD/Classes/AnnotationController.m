//
//  AnnotationController.m
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AnnotationController.h"


@implementation AnnotationController

@synthesize coordinate;
@synthesize annTitle, annTag, annSubTitle, annImage, annType;

- (NSString *) subtitle
{
	return annSubTitle;
}

- (NSString *) title
{
	return annTitle;
}

- (NSString *) imgurl
{
	return annImage;
}

- (int) tag
{
	return annTag;
}

- (AnnotationStyle) type
{
	return annType;
}

//-(id)initWithLatitude: (CLLocationDegrees) latitude andLongitude: (CLLocationDegrees) longitude
//{
//	self.coordinate
//}

-(id)initWithCoordinate: (CLLocationCoordinate2D) point
{
	coordinate = point;
//	NSLog(@"%f,%f",point.latitude,point.longitude);
	return self;
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of AnnotationController");
	[annTitle release];
	[annSubTitle release];
	[annImage release];
    [super dealloc];
	NSLog(@"Completed dealloc of AnnotationController");
}

@end

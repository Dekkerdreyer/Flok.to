//
//  Tab1ViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Tab1ViewController.h"
#import "MapViewController.h"
#import "PlacesByTagViewController.h"
#import "PersonProfileViewController.h"
#import "MapDetailViewController.h"

@implementation Tab1ViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	flagNeedToShowMPDView = NO;
	txtUsername = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 40.0, 260.0, 25.0)];
	[txtUsername retain];
}


- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];

	if ( flagSelectionDone )
	{
		flagSelectionDone = NO;
		NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
		for ( NSArray *arrTagData in arrSelectedItems )
			[tagcsv appendFormat:@",%@",[arrTagData objectAtIndex:1] ];
		if ( currRequestNum == 4 )
		{
			strTagCsv = [tagcsv substringFromIndex: 1];
			[strTagCsv retain];
			flagNeedToShowMPDView = YES;			
		}
		else
		{
			MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
			if (currRequestNum == 1)
				mapViewController.searchStyle = SearchPlacesByTag;
			else
				mapViewController.searchStyle = SearchPersonByTag;
			mapViewController.strTagCsv = [tagcsv substringFromIndex:1];
			[mapViewController.strTagCsv retain];
			[self.navigationController pushViewController: mapViewController animated:YES];
			[mapViewController release];
			mapViewController = nil;
		}
		[tagcsv release];
		[arrSelectedItems removeAllObjects];
		[arrSelectedItems retain];
	}
}
 

- (void)viewDidAppear:(BOOL)animated 
{
	[super viewDidAppear:animated];	
	if ( flagNeedToShowMPDView )
	{
		flagNeedToShowMPDView = NO;
		currRequestNum = 5;
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
	}
		
}
 

- (IBAction) pplLikeMeBtnAction
{
	MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
	mapViewController.searchStyle = SearchPersonLikeMe;
	[self.navigationController pushViewController: mapViewController animated:YES];
	[mapViewController release];
	mapViewController = nil;
}

- (IBAction) pplByTagBtnAction
{
	currRequestNum = 2;
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

- (IBAction) placesIdLikeBtnAction
{
/*	
	currRequestNum = 4;
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
*/	
	
	MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
	mapViewController.searchStyle = SearchPlacesIdLike;
	mapViewController.strPlaceTypeId = @"0";
	[mapViewController.strPlaceTypeId retain];
	[self.navigationController pushViewController: mapViewController animated:YES];
	[mapViewController release];
	mapViewController = nil;

}

- (IBAction) placesByTagBtnAction
{
	PlacesByTagViewController *placesByTagViewController = [[PlacesByTagViewController alloc] initWithNibName:@"PlacesByTagView" bundle:nil];
	[self.navigationController pushViewController:placesByTagViewController animated:YES];
	[placesByTagViewController release];
	placesByTagViewController = nil;
/*
	currRequestNum = 1;
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
*/ 
}

- (IBAction) searchUserBtnAction
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Enter Username to be searched\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Search", nil];
	CGAffineTransform myTransform = CGAffineTransformMakeTranslation(0.0, 75.0);
	[alert setTransform:myTransform];
	[txtUsername setBackgroundColor:[UIColor whiteColor]];
	txtUsername.keyboardType = UIKeyboardTypeAlphabet;
	txtUsername.keyboardAppearance = UIKeyboardAppearanceAlert;
	txtUsername.autocorrectionType = UITextAutocorrectionTypeNo;
	txtUsername.clearButtonMode = UITextFieldViewModeWhileEditing;
//	txtUsername.borderStyle = UITextBorderStyleRoundedRect;
	
	[alert addSubview:txtUsername];
	alert.tag = 75;
	[alert show];
	[txtUsername becomeFirstResponder];
	[alert release];	
}

- (void) fetchJsonData
{
	NSString *strUrl;
	if ( currRequestNum == 1 )
		strUrl = [NSString stringWithFormat:@"%@placetag/gettags?username=%@&password=%@"
				  , SESSION_URL ];
	else if ( currRequestNum == 2 )
		strUrl = [NSString stringWithFormat:@"%@usertag/gettagcategories?username=%@&password=%@"
					, SESSION_URL ];
	else if ( currRequestNum == 3 )
		strUrl = [NSString stringWithFormat:@"%@user/searchbyusername?username=%@&password=%@&searchusername=%@"
					, SESSION_URL, txtUsername.text ];
	else if ( currRequestNum == 4 )
		strUrl = [NSString stringWithFormat:@"%@placetag/getplacearchetypes?username=%@&password=%@"
				  , SESSION_URL ];
	else if ( currRequestNum == 5 )
		strUrl = [NSString stringWithFormat:@"%@placetag/searchplacebytag?username=%@&password=%@&tagcsv=%@"
						 , SESSION_URL, strTagCsv]; 
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
//			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
//			[alert show];
		}
		else
			alert.tag = 20;
		[alert show];
	}
	else
	{
		if ( currRequestNum == 1 || currRequestNum == 2 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableArray *arrTemp = [[[NSMutableArray alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				if ( currRequestNum == 1 )
					[arrTemp addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"placetagname"], [dicRecord valueForKey:@"placetagid"], nil] ];
				else
					[arrTemp addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"tagname"], [dicRecord valueForKey:@"tagid"], nil] ];
				[arrTemp retain];
			}
			arrRecords = nil;
			[self killHUD];
			
			SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
			selectionViewController.arrRecords = [NSArray arrayWithArray:arrTemp];
			[selectionViewController.arrRecords retain];
			selectionViewController.strInstructions = @"Select between 1 and 4 tags";
			[selectionViewController.strInstructions retain];
			selectionViewController.noOfSelectionsNeeded = 4;
			selectionViewController.choiceViewController = self;
			[selectionViewController.choiceViewController retain];
			[self.navigationController pushViewController:selectionViewController animated:YES];
			[selectionViewController release];
			selectionViewController = nil;
		}
		else if ( currRequestNum == 3 )
		{
			[self killHUD];
			PersonProfileViewController *personProfileViewController = [[PersonProfileViewController alloc] initWithNibName:@"PersonProfileView" bundle:nil ];
			personProfileViewController.dicProfileInfo = dicResponse;
			[personProfileViewController.dicProfileInfo retain];
			[self.navigationController pushViewController:personProfileViewController animated:YES];
			[personProfileViewController release];
			personProfileViewController = nil;
		}
		else if ( currRequestNum == 4 )
		{
			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
			dicResponse = nil;
			NSMutableArray *arrTemp = [[[NSMutableArray alloc] init] retain];
			for ( NSDictionary *dicRecord in arrRecords )
			{
				[arrTemp addObject:[NSArray arrayWithObjects:[dicRecord valueForKey:@"arche_type"], [dicRecord valueForKey:@"placetagid"], nil] ];
				[arrTemp retain];
			}
			arrRecords = nil;
			[self killHUD];
			
			SelectionViewController *selectionViewController = [[SelectionViewController alloc] initWithNibName:@"SelectionView" bundle:nil];
			selectionViewController.arrRecords = [NSArray arrayWithArray:arrTemp];
			[selectionViewController.arrRecords retain];
			selectionViewController.strInstructions = @"Select a place type you like the most";
			[selectionViewController.strInstructions retain];
			selectionViewController.noOfSelectionsNeeded = 1;
			selectionViewController.choiceViewController = self;
			[selectionViewController.choiceViewController retain];
			[self.navigationController pushViewController:selectionViewController animated:YES];
			[selectionViewController release];
			selectionViewController = nil;
		}
		else if ( currRequestNum == 5 )
		{
			[self killHUD];
			MapDetailViewController *mapDetailViewController = [[MapDetailViewController alloc] initWithNibName:@"MapDetailView" bundle:nil];
			mapDetailViewController.flagPlaces = YES;
			mapDetailViewController.arrTableData = [dicResponse objectForKey:@"jsonResult"];
			[mapDetailViewController.arrTableData retain];
			[self.navigationController pushViewController:mapDetailViewController animated:YES];
			[mapDetailViewController release];
			mapDetailViewController = nil;
		}
			/*		else if ( currRequestNum == 2 )
		{
			userId = [dicResponse objectForKey:@"userid"];
			[userId retain];
			//			dicUserInfo = [NSDictionary dictionaryWithDictionary:dicResponse];
			//			[dicUserInfo retain];
			NSMutableString *tagcsv = [[[NSMutableString alloc] init] retain];
			for ( int i = 0; i < 3; i++ )
			{
				for ( int j=0; j < [[arrTagData objectAtIndex:i] count]; j++ )
					if ( [[[arrSelections objectAtIndex:i] objectAtIndex:j] intValue] )
						[tagcsv appendFormat:@",%@",[[arrSelections objectAtIndex:i] objectAtIndex:j]];
			}
			strSelectedItems = [tagcsv substringFromIndex:1];
			[strSelectedItems retain];
			[tagcsv release];
			currRequestNum = 3;
			[self fetchJsonData];			
		}
		else if ( currRequestNum == 3 )
		{
			[dicCredentials setObject:@"1" forKey:@"tagsStatus"];
			[self saveCredentials:dicCredentials toFile:kProfileCreationFile];
			NSString *pwd = [dicCredentials objectForKey:@"password"];
			dicCredentials = [NSMutableDictionary dictionaryWithDictionary:dicResponse];
			[dicCredentials setObject:pwd forKey:@"password"];
			[self saveCredentials:dicCredentials toFile:kLoginFile];
			[self killHUD];
			[self.navigationController popViewControllerAnimated:YES];
		}
*/		
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if ( alertView.tag == 75 )
	{
		if ( buttonIndex )
		{
			NSLog(@"text is %@", txtUsername.text);
			//![txtUsername.text isEqualToString:@""] &&
			if (  ![[txtUsername.text capitalizedString] isEqualToString:[kUsername capitalizedString]] )
			{
				currRequestNum = 3;
				[self showHUD];
				[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
			}
			else
			{
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"You are not supposed to search yourself" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
				[alert show];
				[alert release];
			}
		}
	}
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of Tab1ViewController");
	if ( txtUsername )
		[txtUsername release];
   	[imgViewTheme release];
 [super dealloc];
	NSLog(@"Completed dealloc of Tab1ViewController");
}


@end

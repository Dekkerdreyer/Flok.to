//
//  MyProfileViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyProfileViewController : UIViewController 
{
	IBOutlet UILabel *lblSince, *lblName, *lblTweet;
	IBOutlet UITextView *txtViewSelf;
	IBOutlet UIImageView *imgViewAvatar;
	int currRequestNum;
	NSMutableDictionary *dicCredentials;
	BOOL flagReloadProfile, flagEditTags;
	IBOutlet UIWebView *webViewTags;
	NSString *strSelfTags;
	IBOutlet UIImageView *imgViewTheme;
}

- (IBAction) clearTagsBtnAction;
- (IBAction) avatarBtnAction;
- (IBAction) editBtnAction;

- (void) loadBackGround;
- (void) continueSelfTagging;
- (void) continueAvatarUpdation;
- (void) reloadTagInfo;
- (NSString *) getLatestTweet;

@end

//
//  ChangePasswordViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChangePasswordViewController : UIViewController 
{
	IBOutlet UITextField *txtOld, *txtNew, *txtConfirm;
	NSString *strRequestUrl;
	IBOutlet UIImageView *imgViewTheme;
}

- (IBAction) submitBtnAction;

@end

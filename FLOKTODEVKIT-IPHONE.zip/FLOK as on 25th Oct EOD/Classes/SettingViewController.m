//
//  SettingViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SettingViewController.h"
#import "ChangePasswordViewController.h"
#import "ProfileQuestionsViewController.h"
#import "FacebookLoginViewController.h"
#import "TwitterUpdateViewController.h"
#import "ThemeSelectionViewController.h"
#import "MailidViewController.h"

@implementation SettingViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	tableFlok.backgroundColor = [UIColor clearColor];
	currRequestNum = 0;
	dicCredentials = [NSMutableDictionary dictionaryWithDictionary: [self retrieveCredentials:kLoginFile ]];
	[dicCredentials retain];
	arrTableData = [[[NSMutableArray alloc] init] retain];
	[arrTableData addObject:[[[NSMutableArray alloc] initWithObjects:@"Change Background Image", @"Update Password", @"Update Email ID", nil] autorelease]];
	[arrTableData addObject:[[[NSMutableArray alloc] initWithObjects:@"Twitter", @"Facebook", nil] autorelease]];
	[arrTableData addObject:[[[NSMutableArray alloc] initWithObjects:@"Reset all my profile tags!", @"Delete my account!", @"Update My Location", nil] autorelease]];
	//	[arrTableData addObject:[[[NSMutableArray alloc] initWithObjects:@"Update My Location", nil] autorelease]];
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	
}
- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/getselftags?username=%@&password=%@"
						 , SESSION_URL ];
	else if ( currRequestNum == 2 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/gettagsbyother?username=%@&password=%@"
						 , SESSION_URL ]; 
	else if ( currRequestNum == 3 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/clearalltags?username=%@&password=%@&tags=%@"
						 , SESSION_URL, @"all" ]; 
	else if ( currRequestNum == 4 )
		strRequestUrl = [NSString stringWithFormat:@"%@usertag/deleteprofile?username=%@&password=%@"
						 , SESSION_URL ]; 
	
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"nodata" ] )
		{
//			if ( currRequestNum == 1 )
//			{
//			}
//			else if ( currRequestNum == 2 )
		}
		else
		{
			[alert show];
		}
	}
	else
	{
		if ( currRequestNum == 1 || currRequestNum == 2 )
		{
//			NSArray *arrRecords = [dicResponse objectForKey:@"jsonResult"];
//			dicResponse = nil;
//			NSMutableString *strTags = [[[NSMutableString alloc] init] retain];
//			for ( NSDictionary *dicRecord in arrRecords )
//			{
//				[strTags appendFormat:@",  %@", [dicRecord valueForKey:@"tagname"] ];
//			}
//			if ( currRequestNum == 1 )
//				txtViewSelf.text = [strTags substringFromIndex:3];
//			
//			else
//				txtViewOthers.text = [strTags substringFromIndex:3];
//			[strTags release];
//			arrRecords = nil;
//			if ( currRequestNum == 1 )
//			{
//				currRequestNum = 2;
//				[self fetchJsonData];
//			}
//			else
//				[self killHUD];
		}
		else if ( currRequestNum == 3 )
		{
			if ( [dicResponse objectForKey:@"successmsg"] )
			{
				[self killHUD];
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_ClearedTags object:nil];
				[self continueSelfTagging];
			}
		}
		else if ( currRequestNum == 4 )
		{
			if ( [dicResponse objectForKey:@"successmsg"] )
			{
				[self killHUD];
				[self.tabBarController.view removeFromSuperview];
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_AccDeleted object:nil];
			}
			//			[dicCredentials setObject:@"1" forKey:@"tagsStatus"];
			//			[self saveCredentials:dicCredentials toFile:kProfileCreationFile];
			//			NSString *pwd = [dicCredentials objectForKey:@"password"];
			//			dicCredentials = [NSMutableDictionary dictionaryWithDictionary:dicResponse];
			//			[dicCredentials setObject:pwd forKey:@"password"];
			//			[self saveCredentials:dicCredentials toFile:kLoginFile];
			//			[self killHUD];
			//			[self.navigationController popViewControllerAnimated:YES];
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if ( alertView.tag == 75 )
	{
		if ( buttonIndex )
		{
			[self showHUDWithTitle:@"Deleting Account"];
			currRequestNum = 4;
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
	}
	else if ( alertView.tag == 25 )
	{
		if (buttonIndex)
		{
			[self showHUDWithTitle:@"Deleting Tags" ];
			currRequestNum = 3;		
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
	}
}

- (void) continueSelfTagging
{
	ProfileQuestionsViewController *profileQuestionsViewController = [[ProfileQuestionsViewController alloc] initWithNibName:@"ProfileQuestionsView" bundle:nil];
	profileQuestionsViewController.dicCredentials = dicCredentials;
	[profileQuestionsViewController.dicCredentials retain];
	profileQuestionsViewController.view.frame = self.view.frame;
	[self.navigationController pushViewController:profileQuestionsViewController animated:YES];
	[profileQuestionsViewController release];
	profileQuestionsViewController = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [arrTableData count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 35;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[arrTableData objectAtIndex:section] count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier;// = @"Cell";
    
    UITableViewCell *cell;
    // Set up the cell...
	if ( indexPath.section == 1 )
	{
		CellIdentifier = @"Feed cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) 
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//			cell.accessoryView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"RssFeed.png"]] autorelease];
		}
	}
	else
	{
		CellIdentifier = @"Default cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) 
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		}
	}    
	cell.textLabel.text = [[arrTableData objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int secID = indexPath.section;
	int rowID = indexPath.row;
	switch ( secID ) {
		case 0:
			if ( rowID == 1)
			{
				ChangePasswordViewController *changePasswordViewController = [[ChangePasswordViewController alloc] initWithNibName:@"ChangePasswordView" bundle:nil];
				[self.navigationController pushViewController:changePasswordViewController animated:YES];
				[changePasswordViewController release];
				changePasswordViewController = nil;
			}
			else if ( rowID == 0)
			{
				ThemeSelectionViewController *themeSelectionViewController = [[ThemeSelectionViewController alloc] initWithNibName:@"ThemeSelectionView" bundle:nil];
				[self.navigationController pushViewController:themeSelectionViewController animated:YES];
				[themeSelectionViewController release];
				themeSelectionViewController = nil;
			}
			else if ( rowID == 2 )
			{
				MailidViewController *mailidViewController = [[MailidViewController alloc] initWithNibName:@"MailidView" bundle:nil];
//				mailidViewController.dicCredentials = dicCredentials;
//				[mailidViewController.dicCredentials retain];
				mailidViewController.flagUpdatingProfile = YES;
				[self.navigationController pushViewController:mailidViewController animated:YES];
				[mailidViewController release];
				mailidViewController = nil;				
			}
			break;
		case 1:
			if ( rowID )
			{
/*				
				FacebookLoginViewController *oauth2TestViewController = [[FacebookLoginViewController alloc] initWithNibName:@"oAuth2TestView" bundle:nil];
				[self.navigationController pushViewController:oauth2TestViewController animated:YES];
				[oauth2TestViewController release];
				oauth2TestViewController = nil;
*/
//				NSString *responseId = [self updateOnFacebook:[NSString stringWithFormat:@"%@", [NSDate date] ]];
//				if ( !responseId )
//				{
					FacebookLoginViewController *facebookLoginViewController = [[FacebookLoginViewController alloc] initWithNibName:@"FacebookLoginView" bundle:nil];
					[self.navigationController pushViewController:facebookLoginViewController animated:YES];
					[facebookLoginViewController release];
					facebookLoginViewController = nil;
//				}
			}
			else
			{
/*				
				TwitterPostViewController *twitterPostViewController = [[TwitterPostViewController alloc] initWithNibName:@"TwitterPostView" bundle:nil];
				[self.navigationController pushViewController:twitterPostViewController animated:YES];
				[twitterPostViewController release];
				twitterPostViewController = nil;
*/				
/*				
				TwitterUpdate *twitterUpdate = [[TwitterUpdate alloc] init] ;
				NSString *strTweet = [NSString stringWithFormat:@"%@", [NSDate date] ];
				if ( [twitterUpdate updateTweet:strTweet] == 200 )
				{
					[twitterUpdate release];
					twitterUpdate = nil;
				}
				else
				{
					//[twitterUpdate autorelease];
				}
*/ 
///*
//				OAuth *oAuth = [self readyToTweet];
				
				
//				NSString *strTweet = [NSString stringWithFormat:@"%@", [NSDate date] ];
//				NSLog(@"strTweet is '%@' ", strTweet);
//				if ( kTwitterAuthorized )
//				{
//					if ( [self postTweet:strTweet] == 200 )
//						NSLog(@"Success");
//					else
//						NSLog(@"What to do");
//				}
//				else
//				{
					TwitterUpdateViewController *twitterUpdateViewController = [[TwitterUpdateViewController alloc] initWithNibName:@"TwitterUpdateView" bundle:nil];
//					twitterUpdateViewController.tweetMsg = strTweet;
//					[twitterUpdateViewController.tweetMsg retain];
					[self.navigationController pushViewController:twitterUpdateViewController animated:YES];
					[twitterUpdateViewController release];
					twitterUpdateViewController = nil;
//				}
//*/ 
			}
			break;
		case 2:
			if ( rowID == 0 )
			{
				UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"You have opted to clear your tags. This will clear all tags, including your own self-selected profile tags, from this profile" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Proceed", nil] autorelease];
				alert.tag = 25;
				[alert show];				
			}
			else if ( rowID == 1 )
			{
				UIAlertView *alert = [[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Do you really want to Delete your Flok Account?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil] autorelease];
				alert.tag = 75;
				[alert show];
			}
			else if ( rowID == 2 )
			{
//				[self showHUDWithTitle:@"Updating Location" ];
				[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_UpdateLocation object:nil];
			}
			break;
		default:
			break;
	}
	
}

/*
- (IBAction)didPressLatestTweets:(id)sender {
    NSString *getUrl = @"http://api.twitter.com/1/statuses/user_timeline.json";
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:@"5", @"count", nil];
    
    // Note how the URL is without parameters here...
    // (this is how OAuth works, you always give it a "normalized" URL without parameters
    // since you give parameters separately to it, even for GET)
    NSString *oAuthValue = [oAuth oAuthHeaderForMethod:@"GET" andUrl:getUrl andParams:params];
    
    // ... but the actual request URL contains normal GET parameters.
    ASIHTTPRequest *request = [[ASIHTTPRequest alloc]
                               initWithURL:[NSURL URLWithString:[NSString
                                                                 stringWithFormat:@"%@?count=%@",
                                                                 getUrl,
                                                                 [params valueForKey:@"count"]]]];
    [request addRequestHeader:@"Authorization" value:oAuthValue];
    [request startSynchronous];
    
    NSLog(@"Got statuses. HTTP result code: %d", request.responseStatusCode);
    
    tweets.text = @"";
    
    NSArray *gotTweets = [[request responseString] JSONValue];
    
    for (NSDictionary *tweet in gotTweets) {
        tweets.text = [NSString stringWithFormat:@"%@\n%@", tweets.text, [tweet valueForKey:@"text"]];
    } 
    
    [request release];
    
    [statusText resignFirstResponder];
}

*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of SettingViewController");
	[tableFlok release];
	[arrTableData release];
	dicCredentials = nil;
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of SettingViewController");
}


@end

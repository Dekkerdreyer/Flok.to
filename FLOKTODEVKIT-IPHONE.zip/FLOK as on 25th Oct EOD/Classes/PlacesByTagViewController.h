//
//  PlacesByTagViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 01/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"
#import "SelectionViewController.h"

@interface PlacesByTagViewController : ChoiceViewController 
{
	NSMutableArray *arrTableData, *arrTagData, *arrSelectedTypes;
	int currRequestNum, currCatgNum;
//	BOOL ;
	IBOutlet UITableView *tableFlok;
	IBOutlet UIImageView *imgViewTheme;
}

@end

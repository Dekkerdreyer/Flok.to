//
//  FLOKAppDelegate.m
//  FLOK
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "FLOKAppDelegate.h"
#import "RootViewController.h"


@implementation FLOKAppDelegate

@synthesize window;
@synthesize navigationController;
@synthesize HUD;

//@synthesize gUserName, gPassword;

#pragma mark -
#pragma mark Application lifecycle

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
//    NSString *str = nil;
//	NSLog(@"kUser_Theme is '%@', str is '%@' ", kUser_Theme, str);
    // Override point for customization after app launch    
	//window.backgroundColor = [UIColor groupTableViewBackgroundColor];
				
	[window addSubview:[navigationController view]];
         [window makeKeyAndVisible];
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc 
{
	NSLog(@"Entered dealloc of FLOKAppDelegate");
	[navigationController release];
	[window release];
    [super dealloc];
	NSLog(@"Completed dealloc of FLOKAppDelegate");
}

@end


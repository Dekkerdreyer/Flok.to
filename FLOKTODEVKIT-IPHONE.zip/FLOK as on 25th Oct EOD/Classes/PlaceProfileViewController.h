//
//  PlaceProfileViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 05/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"
#import "SelectionViewController.h"

@interface PlaceProfileViewController : ChoiceViewController
{
//	IBOutlet UIImageView *imgViewTheme;
	IBOutlet UILabel *lblName, *lblAddress, *lblCity, *lblState, *lblCountry, *lblWebsite;
//	IBOutlet UITextView *txtViewTags;
	int currRequestNum;
	NSString *strPlaceId, *strTagCsv;
	NSDictionary *dicPlaceDetails;
	NSString *strMessageToTweet;
	BOOL flagUpdatedTwitter, flagUpdatedFacebook;
	IBOutlet UIWebView *webViewTags;
	NSString *strPreSelectedTags;
	IBOutlet UIImageView *imgViewTheme;
}

@property BOOL flagUpdatedFacebook, flagUpdatedTwitter;
@property (nonatomic, retain) NSString *strMessageToTweet;
@property (nonatomic, retain) NSDictionary *dicPlaceDetails;

- (IBAction) tagBtnAction;
- (void) statusUpdation;
- (void) loadTagInfo;

@end

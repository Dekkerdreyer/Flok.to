//
//  ThemeSelectionViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 13/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ThemeSelectionViewController : UIViewController 
{
	NSArray *arrTableData;
	IBOutlet UITableView *tableFlok;
	IBOutlet UIImageView *imgViewTheme;
}

- (IBAction) defaultBtnAction;

@end

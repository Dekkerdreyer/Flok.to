//
//  AvatarViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 27/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"
#import "ASIFormDataRequest.h"

@interface AvatarViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
	IBOutlet UIImageView *imgView;
	IBOutlet UIButton *btnDone;
	UIImage *imgAvatar;
	NSString *strFileToUpload;
	ASIFormDataRequest *uploadRequest;
	
	BOOL flagFirstTime;
	NSMutableDictionary *dicCredentials;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSMutableDictionary *dicCredentials;
@property (nonatomic, retain) UIImage *imgAvatar;
@property BOOL flagFirstTime;

- (IBAction) genericBtnAction;
- (IBAction) libraryBtnAction;
- (IBAction) doneBtnAction;

- (void) continueSelfTagging;
- (void) uploadPhoto;
- (void) writeImageToFile : (UIImage *) selectedImage;
//- (void)viewDidAppear:(BOOL)animated;
@end

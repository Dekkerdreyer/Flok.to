//
//  SelectionViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 05/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SelectionViewController.h"
#import "Category.h"

@implementation SelectionViewController

@synthesize arrRecords, noOfSelectionsNeeded;
@synthesize choiceViewController;
@synthesize strInstructions;
@synthesize flagNeedResize, flagPreselectionReqd;
/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];	
	
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	tableFlok.backgroundColor = [UIColor clearColor];
	if (flagNeedResize)
	{
		self.view.frame = CGRectMake( 0, 0, 320, 460 );
		tableFlok.frame = CGRectMake( 0, 0, 320, 460 );
//		imgViewTheme.frame = CGRectMake( 0, 0, 320, 460 );
	}

	flagDataReady = NO;
	selectedCount = 0;
	[choiceViewController.arrSelectedItems removeAllObjects];
	[choiceViewController.arrSelectedItems retain];
	choiceViewController.flagSelectionDone = NO;
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(prepareTableData) userInfo:nil repeats:NO];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

- (void) prepareTableData
{
	[self sortArray];
	arrSelectionStatus = [[[NSMutableArray alloc] init] retain];
	for ( int i=0; i < [arrRecords count] ; i++ )
	{
		if ( flagPreselectionReqd )
		{
			if ( [[arrRecords objectAtIndex:i] count] > 2 )
			{
				[arrSelectionStatus addObject:@"1"];
				selectedCount++;
			}
			else
				[arrSelectionStatus addObject:@"0"];
		}
		else
			[arrSelectionStatus addObject:@"0" ];
	}
	[arrSelectionStatus count];
	flagDataReady = YES;
	[tableFlok reloadData];
	[self killHUD];
}

- (void) sortArray
{
	NSMutableArray *listContent = [[[NSMutableArray alloc] init] retain];
	for ( int i=0; i < [arrRecords count]; i ++ )
	{
		[listContent addObject: [Category categoryNamed:[[arrRecords objectAtIndex:i] objectAtIndex:0] withDetails:[arrRecords objectAtIndex:i]  ] ]; 
	}
	[listContent retain];
	arrRecords = nil;
	NSSortDescriptor *firstDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)] autorelease];
	
	NSArray * descriptors = [NSArray arrayWithObjects:firstDescriptor, nil];
	NSArray * sortedArray = [listContent sortedArrayUsingDescriptors:descriptors];
	[listContent removeAllObjects];
	[listContent retain];
//	[arrRecords removeAllObjects];
	for ( Category *catg in sortedArray )
	{
		[listContent addObject:catg.arrDtls];
	}
	sortedArray = nil;
	arrRecords = [NSArray arrayWithArray:listContent];
	[arrRecords retain];
	[listContent release];
	listContent = nil;
	//	NSLog(@"Sorted arr is %@", arrTableData);
}

//- (void) createSectionList:(NSMutableArray *) dataArray 
//{	
//	sectionArray = [[NSMutableArray alloc] init];
//	for ( int i = 0; i < 26; i++) {
//		[sectionArray addObject:[[NSMutableArray alloc] init]];
//	}
//	
//	for (Category *catg in dataArray) 
//	{
//		NSString * word = catg.name;		
//		if ( 0 == [word length] ) 
//			continue;		
//		NSRange range = [ALPHA rangeOfString: [ [word substringToIndex:1] uppercaseString]];
//		[[sectionArray objectAtIndex:range.location] addObject:catg];
//	}
//}
//

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	if ( flagDataReady )
		return 2;
	else
		return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
//	if ( flagDataReady )
	return strInstructions;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if ( section )
		return 1;
	else
		return [arrRecords count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int rowID = indexPath.row;
	int secID = indexPath.section;
    UITableViewCell *cell;
    static NSString *CellIdentifier;// = @"Cell";
	if ( secID )
	{
		CellIdentifier = @"Submit Cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			cell.textLabel.text = @"Next";
		}
	}
	else
	{
		CellIdentifier = @"Cell";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//			cell.accessoryView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"UnChecked.png"]] autorelease];
			cell.backgroundColor = [UIColor clearColor];
		}
		cell.textLabel.text = [[arrRecords objectAtIndex:rowID] objectAtIndex:0] ;
		if ( [[arrSelectionStatus objectAtIndex:rowID] intValue] )
//			cell.accessoryType = UITableViewCellAccessoryCheckmark;
			cell.accessoryView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Checked.png"]] autorelease];
		else
//			cell.accessoryType = UITableViewCellAccessoryNone;
			cell.accessoryView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"UnChecked.png"]] autorelease];
	}
    
    // Set up the cell...
	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int rowID = indexPath.row;
	if ( indexPath.section )
	{
		BOOL invalidSelections = NO;
		if ( !selectedCount || (selectedCount > noOfSelectionsNeeded ) )
			invalidSelections = YES;
		if ( ! invalidSelections )
		{
			for ( int i =0; i < [arrSelectionStatus count]; i++ )
			{
				if ( [[arrSelectionStatus objectAtIndex:i] intValue] )
					[choiceViewController.arrSelectedItems addObject:[arrRecords objectAtIndex:i]  ];
			}
			[choiceViewController.arrSelectedItems retain];
			choiceViewController.flagSelectionDone = YES;
			[self.navigationController popViewControllerAnimated:YES];
		}
		else
		{
			NSLog(@"Invalid selection");
//[NSString stringWithFormat: @"You need to select upto %d choices ", noOfSelectionsNeeded]
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Invalid Selection" message:strInstructions delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			alert.tag = 20;
			[alert show];
		}
	}
	else
	{
		if ( [[arrSelectionStatus objectAtIndex:rowID] intValue] )
		{
			[arrSelectionStatus replaceObjectAtIndex:rowID withObject:@"0"];
			selectedCount --;
		}
		else if ( selectedCount < noOfSelectionsNeeded )
		{
			[arrSelectionStatus replaceObjectAtIndex:rowID withObject:@"1"];
			selectedCount ++;
		}
		[arrSelectionStatus retain];
		[tableView reloadData];
	}
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of SelectionViewController");
	arrRecords = nil;
	[arrSelectionStatus release];
	[choiceViewController release];
	[tableFlok release];
	[strInstructions release];
  	[imgViewTheme release];
  [super dealloc];
	NSLog(@"Completed dealloc of SelectionViewController");
}

@end


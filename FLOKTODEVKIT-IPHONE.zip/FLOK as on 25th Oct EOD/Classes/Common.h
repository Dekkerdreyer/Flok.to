//
//  Common.h
//  FLOK
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIViewController-Custom.h"
#define	TESTING		0
#define	FREE_VERSION	1
#define	kGPS_Timeout	60.0	//in secs

#if TESTING
		#define	BASE_FLOK_URL	@"http://staging.teks.co.in/Flok/index.php/"
	//	Testing app's Keys
		#define	kAdWhirlAppKey	@"ff8e0c76e48f473f92e56d6fa0feb4ee"
	// Twitter
		#define	TWITTER_OAUTH_CONSUMER_KEY		@"tlcOUtyhcpKdadK3K6YvFQ"
		#define	TWITTER_OAUTH_CONSUMER_SECRET		@"W0v8cVZY6uENV1JUUxpCki61Ku485ovHQOEDnX5Jo"
	//Facebook Application ID
		#define	client_id			@"144278595599966"
#else
		#define	BASE_FLOK_URL	@"http://www.flok.to/api/index.php/"
	//	Clients app's Keys
		#define	kAdWhirlAppKey	@"c28f9dd0face44db869735d25df59ce6"//@"0a1fe11936fc4f708600ed7aed3d3f9d"

	// Twitter
		#define	TWITTER_OAUTH_CONSUMER_KEY		@"0JeCZS35CO3yGL55saARA"
		#define	TWITTER_OAUTH_CONSUMER_SECRET		@"9DmSwfoJ2l8LmzPd9jPCciOdE6M7E2U8tSmy680qqg"
	//Facebook Application ID
		#define	client_id			@"144779625567124"
#endif


#define	SESSION_URL	BASE_FLOK_URL, kUsername, kPassword 


#define	kViewTag		1	// for tagging our embedded controls for removal at cell recycle time
#define	kSectionTitleKey	@"sectionTitleKey"
#define	kLabelKey		@"labelKey"
#define	kSourceKey		@"sourceKey"
#define	kViewKey		@"viewKey"


#define	kProfileCreationFile		@"UserInfo.xml"
#define	kLoginFile			@"Credentials.xml"
#define	kAvatarFile			@"Avatar.png"

#define	NOTF_AccDeleted		@"AccountDeleted"
#define	NOTF_PwdChanged		@"PasswordChanged"
#define	NOTF_UpdateLocation	@"UpdateLocation"
#define	NOTF_ClearedTags		@"AllTagsResetOccured"

// User Info (Stored in NSUserDefaults)
#define	kUsername		[[NSUserDefaults standardUserDefaults] stringForKey:@"username" ]
#define	kPassword		[[NSUserDefaults standardUserDefaults] stringForKey:@"password" ]
#define	kUserID		[[NSUserDefaults standardUserDefaults] stringForKey:@"userid" ]
#define	kUser_Longitude	[[NSUserDefaults standardUserDefaults] stringForKey:@"longitude" ]
#define	kUser_Latitude	[[NSUserDefaults standardUserDefaults] stringForKey:@"latitude" ]
#define	kUser_Theme	[[NSUserDefaults standardUserDefaults] stringForKey:@"theme" ]
#define	kUser_Avatar	[[NSUserDefaults standardUserDefaults] stringForKey:@"avatar" ]
#define	kUser_EmailID	[[NSUserDefaults standardUserDefaults] stringForKey:@"email" ]

#define	kTwitterAuthorized [[NSUserDefaults standardUserDefaults] integerForKey:@"twitter_oauth_token_authorized"]
#define	kFacebookToken	[[NSUserDefaults standardUserDefaults] stringForKey:@"facebook_accessToken"]

#define	kNeedsAlertForFB		[[NSUserDefaults standardUserDefaults] integerForKey:@"fb_AlertReqd"]
#define	kNeedsAlertForTW		[[NSUserDefaults standardUserDefaults] integerForKey:@"tw_AlertReqd"]
#define	kNeedsUpdationForFB	[[NSUserDefaults standardUserDefaults] integerForKey:@"fb_UpdtReqd"]
#define	kNeedsUpdationForTW	[[NSUserDefaults standardUserDefaults] integerForKey:@"tw_UpdtReqd"]

#define	kUname		@"username"
#define	kPwd			@"password"
#define	kUID			@"userid"
#define	kLong			@"longitude"
#define	kLat			@"latitude"
#define	kEmail		@"email"
#define	kTheme		@"theme"
#define	kAvatar		@"avatar"
#define	kDefaultImage	@"bg.png"

//#define ALPHA @"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
//#define ALPHA_ARRAY [NSArray arrayWithObjects: @"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K", @"L", @"M", @"N", @"O", @"P", @"Q", @"R", @"S", @"T", @"U", @"V", @"W", @"X", @"Y", @"Z", nil]

//	Map Clustering constants
#define	OFFSET	268435456
#define	RADIUS	85445659.4471 /* $offset / pi() */

//	Map Pin Images
#define	kPinBlue	@"Pin-Blue.png"
#define	kPinGray	@"Pin-Gray.png"
#define	kPinGreen	@"Pin-Green.png"
#define	kPinOrange	@"Pin-Orange.png"
#define	kPinRed	@"Pin-Red.png"
#define	kPinUser	@"Pin-User.png"
#define	kPinYellow	@"Pin-Yellow.png"

#define	kAlertLoginFail		50
#define	kAlertNetwork		100	
#define	kAlertTwitterFail		200
#define	kAlertTwitterUpdate	225
#define	kAlertFacebooUpdate	275
#define	kAlertFacebookFail		300



//#define	MyDeviceRotation		return YES;
#define	MyDeviceRotation		return (interfaceOrientation == UIDeviceOrientationPortrait);
#define	MyMemoryWarning		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Memory Warning Occured"  delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] ;[alert show];[alert release];



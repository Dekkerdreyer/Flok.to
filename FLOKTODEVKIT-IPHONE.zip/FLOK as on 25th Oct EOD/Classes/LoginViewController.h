//
//  LoginViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 28/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCLController.h"
#import "TabBarViewController.h"

#import "AdWhirlDelegateProtocol.h"
@class AdWhirlView, AdWhirlDelegate;

@interface LoginViewController : UIViewController <AdWhirlDelegate, MyCLControllerDelegate, UITabBarControllerDelegate>
{
	NSDictionary	*dicCredentials;
	MyCLController *locationController;
	double lat, lon;
	BOOL flagFirstTime, flagNeedToUpdateLocationAlone;
	TabBarViewController *tabBarViewController;
//	IBOutlet UITabBarController *tabbarController;
	NSTimer *timerGPS;

	int currRequestNum;
	IBOutlet UITextField *txtUname, *txtPwd;
	IBOutlet UIButton *btnSignIn, *btnSignUp, *btnForgotPwd;
	IBOutlet UILabel *lblUname, *lblPwd;
	IBOutlet UIImageView *imgViewRows;
	IBOutlet UIImageView *imgViewTheme;
}

#pragma mark AdWhirl Functions
- (NSString *)adWhirlApplicationKey;
- (UIViewController *)viewControllerForPresentingModalView;

#pragma mark locationController functions
- (void)locationUpdate:(CLLocation *)location;
- (void)locationError:(NSError *)error;
//- (void) locationTimeOut;

- (IBAction) signInBtnAction;
- (IBAction) signUpBtnAction;
- (IBAction) forgotPwdBtnAction;

- (void) deleteAccountInformation;
- (void) setToDefaults;
- (void) hideLoginTheme;
- (void) showLoginTheme;

- (void) whereToGo;
- (void) newProfileCreation;
- (void) continueProfileCreation;
- (void) continueSelfTagging;
- (void) continueAvatarUpdation;
- (void) updateMyLocation;
- (void) loadTabbarView;
- (void) accountDeleted;

@end

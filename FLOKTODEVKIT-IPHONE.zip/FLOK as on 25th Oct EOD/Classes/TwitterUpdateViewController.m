//
//  TwitterUpdateViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 11/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "TwitterUpdateViewController.h"
#import "CustomLoginPopup.h"
#import "OAuth.h"
#import "OAuth+UserDefaults.h"
#import "ASIHTTPRequest.h"


@implementation TwitterUpdateViewController
@synthesize tweetMsg;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	oAuth = [[[OAuth alloc] initWithConsumerKey: TWITTER_OAUTH_CONSUMER_KEY andConsumerSecret:TWITTER_OAUTH_CONSUMER_SECRET ] retain];
	[oAuth loadOAuthTwitterContextFromUserDefaults];
	
	arrFeed = [[[NSMutableArray alloc] init] retain];
	[self loginValidator];
}

- (void) loginValidator
{
	if ( !kTwitterAuthorized )
	{
		loginPopup = [[CustomLoginPopup alloc] initWithNibName:@"TwitterLoginPopup" bundle:nil];        
		loginPopup.oAuth = oAuth;
		loginPopup.delegate = self;
		loginPopup.uiDelegate = self;
		arrFeed = [[[NSMutableArray alloc] init] retain];
		UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginPopup];
		[self presentModalViewController:nav animated:YES];        
		[nav release];
	}
	else
	{
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTweets) userInfo:nil repeats:NO];
	}
}

#pragma mark TwitterLoginPopupDelegate

- (void)twitterLoginPopupDidCancel:(TwitterLoginPopup *)popup {
	[self dismissModalViewControllerAnimated:YES];        
	[loginPopup release]; loginPopup = nil; // was retained as ivar in "login"
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)twitterLoginPopupDidAuthorize:(TwitterLoginPopup *)popup {
	[self dismissModalViewControllerAnimated:YES];        
	[loginPopup release]; loginPopup = nil; // was retained as ivar in "login"
	[popup.oAuth saveOAuthTwitterContextToUserDefaults];
	if ( tweetMsg )
	{
		[self postTweet:tweetMsg ];
		[self.navigationController popViewControllerAnimated:YES];
	}
	else
	{
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTweets) userInfo:nil repeats:NO];
	}
	
}

- (int) getLatest5Tweets 
{
	ASIHTTPRequest *request = nil;
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	for ( int retryCount = 0; retryCount < 25; retryCount ++ )
	{
		NSString *getUrl = @"http://api.twitter.com/1/statuses/friends_timeline.json";
		NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:@"5", @"count", @"1", @"trim_user", nil];
	//	NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys: @"t", @"trim_user", nil];

		// Note how the URL is without parameters here...
		// (this is how OAuth works, you always give it a "normalized" URL without parameters
		// since you give parameters separately to it, even for GET)
		NSString *oAuthValue = [oAuth oAuthHeaderForMethod:@"GET" andUrl:getUrl andParams:params];

		// ... but the actual request URL contains normal GET parameters.
		request = [[[ASIHTTPRequest alloc] initWithURL:[NSURL URLWithString: 
									[NSString stringWithFormat:@"%@?count=5&trim_user=1", getUrl] ] ] autorelease];
		[request addRequestHeader:@"Authorization" value:oAuthValue];
	
		[request startSynchronous];
		NSLog(@"HTTP result code: '%d' , Retrying Count %d", request.responseStatusCode, retryCount );
		if ( request.responseStatusCode == 200 )
			break;
	}
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    
//    [request release];
	if ( request.responseStatusCode == 200 )
	{
		NSLog(@"HTTP result is: \n%@ ", [request responseString] );
		SBJSON *parser = [SBJSON new];
		NSArray *arrTemp = [parser objectWithString:[request responseString] error:nil];
		for (NSDictionary *dicRecord in arrTemp) 
		{
			[arrFeed addObject:[[[NSMutableArray alloc] initWithObjects:[NSString stringWithFormat:@"%@", [dicRecord valueForKey:@"text"]], [NSString stringWithFormat:@"%@", [dicRecord valueForKey:@"created_at"]] , nil] autorelease] ];
			[arrFeed retain];
		}
	}
	return request.responseStatusCode;
}

- (void) loadTweets
{
	int response = [self getLatest5Tweets];
	[self killHUD];
	if ( response == 200 )
	{
		tableFlok.hidden = NO;
		[tableFlok reloadData];
	}
	else
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:nil message:@"Unable to connect to twitter" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Retry", @"Reset Twitter Credentials", nil] autorelease];
		alert.tag = 150;
		[alert show];
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if (alertView.tag == 150)
	{
		NSLog(@"buttonIndex is '%d' ", buttonIndex);
		if (buttonIndex == 0)
		{
			[self.navigationController popViewControllerAnimated:YES];
		}
		else if ( buttonIndex == 1 )
		{
			[self showHUD];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadTweets) userInfo:nil repeats:NO];
		}
		else if ( buttonIndex == 2 )
		{
			oAuth.oauth_token_authorized = NO;
			[oAuth saveOAuthTwitterContextToUserDefaults];
			[self loginValidator];
		}
	}
}

#pragma mark -
#pragma mark TwitterLoginUiFeedback

- (void) tokenRequestDidStart:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"token request did start");
	[loginPopup.activityIndicator startAnimating];
}

- (void) tokenRequestDidSucceed:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"token request did succeed");    
	[loginPopup.activityIndicator stopAnimating];
}

- (void) tokenRequestDidFail:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"token request did fail");
	[loginPopup.activityIndicator stopAnimating];
}

- (void) authorizationRequestDidStart:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"authorization request did start");    
	[loginPopup.activityIndicator startAnimating];
}

- (void) authorizationRequestDidSucceed:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"authorization request did succeed");
	[loginPopup.activityIndicator stopAnimating];
}

- (void) authorizationRequestDidFail:(TwitterLoginPopup *)twitterLogin {
	NSLog(@"token request did fail");
	[loginPopup.activityIndicator stopAnimating];
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrFeed count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) 
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}	
	
    // Set up the cell...
	UILabel *primaryLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 1, 290, 50)];	
	UILabel *secondaryLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 53, 290, 15)];	
	primaryLabel.numberOfLines =3;
	primaryLabel.font =  [UIFont fontWithName:@"Verdana-Bold" size:12];
	secondaryLabel.font = [UIFont fontWithName:@"Verdana-Bold" size:10];
	secondaryLabel.textColor = [UIColor darkGrayColor];
	
	primaryLabel.text = [[arrFeed objectAtIndex:indexPath.row] objectAtIndex:0] ;
	secondaryLabel.text = [[arrFeed objectAtIndex:indexPath.row] objectAtIndex:1]; 
	
	[cell.contentView addSubview:primaryLabel];
	[cell.contentView addSubview:secondaryLabel];
	[primaryLabel release];
	[secondaryLabel release];
	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of TwitterUpdateViewController");
	[tweetMsg release];
	[oAuth release];
	oAuth = nil;
	if (loginPopup)
		[loginPopup release];
	[tableFlok release];
	[arrFeed release];
    [super dealloc];
	NSLog(@"Completed dealloc of TwitterUpdateViewController");
}


@end

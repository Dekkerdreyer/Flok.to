//
//  ThemeSelectionViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 13/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ThemeSelectionViewController.h"
#import "CustomCell.h"


@implementation ThemeSelectionViewController

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];
	tableFlok.backgroundColor = [UIColor clearColor];
	if (! [kUser_Theme isEqualToString:kDefaultImage] )
	{
		UIBarButtonItem *rightBtn=[[UIBarButtonItem alloc] initWithTitle:@"Restore to Default" style:UIBarButtonItemStylePlain target:self action:@selector(defaultBtnAction)];	
		self.navigationItem.rightBarButtonItem = rightBtn;
	}
//	arrTableData = [[NSArray arrayWithObjects:@"Evening Reflections", @"Clown Fish", @"Flowing Rock", @"Sweeping Current", @"Leaf Curl", @"Maple", nil] retain];

}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (IBAction) defaultBtnAction
{
	[[NSUserDefaults standardUserDefaults] setObject:kDefaultImage forKey:kTheme];
	[[NSUserDefaults standardUserDefaults] synchronize];
	//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	[self.navigationController popViewControllerAnimated:YES]; 
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//	if ( indexPath.section )
//		return 180;
//	else
//		return 40;
//}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier;
//	if ( indexPath.section )
//	{
		CellIdentifier = @"BG Image Cell";
		CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		}
//	if ( indexPath.section )
		cell.imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"bg-%d.png", indexPath.section] ];
//	else
//		cell.imgView.image = [UIImage imageNamed:kDefaultImage ];
		return cell;
//	}
//    // Set up the cell...
//	else
//	{
//		CellIdentifier = @"Default cell";
//		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//		if (cell == nil) 
//		{
//			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//			cell.textLabel.textAlignment = UITextAlignmentCenter;
//		}
//		cell.textLabel.text = @"Set to Default Theme";
//		return cell;
//	}    

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	[[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"bg-%d.png", indexPath.section] forKey:kTheme];
	[[NSUserDefaults standardUserDefaults] synchronize];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	[self.navigationController popViewControllerAnimated:YES]; 
}



- (void)dealloc 
{
	NSLog(@"Entered dealloc of ThemeSelectionViewController");
//	arrTableData = nil;
	[imgViewTheme release];
	[tableFlok release];
    [super dealloc];
	NSLog(@"Completed dealloc of ThemeSelectionViewController");
}


@end


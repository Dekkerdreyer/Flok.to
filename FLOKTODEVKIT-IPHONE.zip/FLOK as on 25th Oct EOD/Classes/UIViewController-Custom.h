//
//  UIViewController-Json.h
//  
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSON.h"
#import "FLOKAppDelegate.h"
#import "OAuth.h"

@interface UIViewController (Json_MBProgressHUD)



#pragma mark alertView
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex;

#pragma mark Twitter Functions
- (void) logoutFromTwitter;
- (int) postTweet: (NSString *) tweetMsg;
- (void) updateOnTwitter : (NSString *) strMessage;
- (void) showTwitterUpdateAlert: (NSString *)strMessage;

#pragma mark Facebook Functions
- (NSString *) updateOnFacebook: (NSString *) strMessage;
- (void) showFacebookUpdateAlert: (NSString *)strMessage;

#pragma mark File Functions
- (NSString *) getFullFilePath : (NSString *) filename;
- (NSDictionary *) retrieveCredentials: (NSString *) fileName;
- (BOOL) saveCredentials: (NSDictionary *) dicToSave toFile:(NSString *) fileName;

#pragma mark JSON Parsing Functions
- (void) fetchJsonData;
- (id) getJsonObjectFromUrl:(NSString *) strUrl;
- (NSString *)stringWithUrl:(NSURL *) url;

#pragma mark ProgressHUD Functions

- (void) showHUDTitled : (NSString *) title andSubTitled : (NSString *) subTitle;
- (void) showHUDWithTitle : (NSString *) title;
- (void) showHUD;
- (void) killHUD;

#pragma mark NavBar Functions

- (void) initNavBarWithTitle : (NSString *)title;
- (void) initNavBar;


@end

//
//  DateViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DateViewController : UIViewController 
{
	NSMutableDictionary *dicCredentials;
	IBOutlet UIDatePicker *myDatePicker;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSMutableDictionary *dicCredentials;

- (IBAction)doneBtnAction;
- (void) continueAvatarUpdation;

@end

//
//  MailidViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MailidViewController.h"
#import "DateViewController.h"

@implementation MailidViewController

@synthesize dicCredentials;
@synthesize flagUpdatingProfile;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	txtView.autoresizingMask = UIViewAutoresizingNone;
//	dicCredentials =  [NSMutableDictionary dictionaryWithDictionary: [self retrieveCredentials:kProfileCreationFile]];
//	[dicCredentials retain];
//	if ( [dicCredentials objectForKey:@"emailStatus"] )
//	{
//		flagUpdatingProfile = NO;
		if ( [[dicCredentials objectForKey:@"emailStatus"] intValue] )
			[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(loadDateView) userInfo:nil repeats:NO];
//	}
//	else
//	{
//		flagUpdatingProfile = YES;
//	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];

	if ( !flagUpdatingProfile )
	{
//		btnSubmit.titleLabel.text = @"Next";
		[btnSubmit setTitle:@"Next" forState:UIControlStateNormal];
	}
	else
	{
//		[self.view setFrame: CGRectMake( 0, 0, 320, 367 )];
		txtEmail.text = kUser_EmailID;
//		btnSubmit.titleLabel.text = @"I'm done!";
		[btnSubmit setTitle:@"I'm done!" forState:UIControlStateNormal];
	}

}


- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
}


- (IBAction) submitBtnAction
{
	[txtEmail resignFirstResponder];
	if ( ([txtEmail.text length] == 0 ) || ( ! [self validateEmail:txtEmail.text] ) )
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please Input Valid Email Id!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] ;
		alert.tag = 30;
		[alert show];
		[alert release];
		return;
	}
		
	if ( !flagUpdatingProfile )
	{
//		if ( txtEmail.text && ![txtEmail.text isEqualToString:@""] )
		[dicCredentials setValue:txtEmail.text forKey:@"email"];
		[dicCredentials setValue:@"1" forKey:@"emailStatus"];
		[dicCredentials retain];
		[self saveCredentials:[NSDictionary dictionaryWithDictionary:dicCredentials] toFile:kProfileCreationFile];
		[self loadDateView];
	}
	else
	{
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
	}
}

- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = [NSString stringWithFormat:@"%@user/editprofilevalues?username=%@&password=%@&email=%@", 
						SESSION_URL, txtEmail.text  ];
	[strRequestUrl retain];
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
	}
	else
	{
		[[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%@", [dicResponse valueForKey:kEmail]] forKey:kEmail];
//		[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kEmail] forKey:kEmail];
		[[NSUserDefaults standardUserDefaults] synchronize];
		[self killHUD];
		[self.navigationController popViewControllerAnimated:YES];
		//		[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_PwdChanged object:nil];
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if (alertView.tag == 30 )
		[txtEmail becomeFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	return YES;
}

- (BOOL)validateEmail:(NSString *)email 
{
	NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+[.]+[A-Za-z]{2,4}"; 
	NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex]; 
	return [emailTest evaluateWithObject:email];
}

- (void) loadDateView
{
	DateViewController *dateViewController = [[DateViewController alloc] initWithNibName:@"DateView" bundle:nil];
	dateViewController.dicCredentials = dicCredentials;
	[dateViewController.dicCredentials retain];
	[self.navigationController pushViewController:dateViewController animated:YES];
	[dateViewController release];
	dateViewController = nil;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	NSLog(@"Entered dealloc of MailidViewController");
	[txtEmail release];
//	[dicCredentials release];
	dicCredentials = nil;
 	[imgViewTheme release];
   [super dealloc];
	NSLog(@"Completed dealloc of MailidViewController");
}


@end

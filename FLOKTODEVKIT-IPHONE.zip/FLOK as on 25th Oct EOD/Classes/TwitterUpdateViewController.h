//
//  TwitterUpdateViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 11/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TwitterLoginPopupDelegate.h"
#import "TwitterLoginUiFeedback.h"

@class OAuth, CustomLoginPopup;

@interface TwitterUpdateViewController : UIViewController <TwitterLoginPopupDelegate, TwitterLoginUiFeedback> 
{
	NSString *tweetMsg;
	CustomLoginPopup *loginPopup;
	OAuth *oAuth;
	IBOutlet UITableView *tableFlok;
	NSMutableArray *arrFeed;
}

@property (nonatomic, retain) NSString *tweetMsg;

- (int) getLatest5Tweets;
- (void) loginValidator;

@end

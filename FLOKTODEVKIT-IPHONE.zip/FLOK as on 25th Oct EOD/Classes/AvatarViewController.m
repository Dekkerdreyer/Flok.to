//
//  AvatarViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 27/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AvatarViewController.h"
#import "GenericAvatarViewController.h"
#import "ProfileQuestionsViewController.h"


@implementation AvatarViewController

@synthesize flagFirstTime;
@synthesize imgAvatar;
@synthesize dicCredentials;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	[imgView setFrame: CGRectMake(110, 25, 100, 100)];
	imgView.contentMode = UIViewContentModeScaleToFill;
	imgView.autoresizingMask = 0;
	if ( ! imgAvatar )
	{
		imgAvatar = [UIImage imageNamed:@"Avatar.png"];
		[imgAvatar retain];
	}	
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	if ( [dicCredentials objectForKey:@"avatarStatus"] )
	{
		//		btnDone.titleLabel.text = @"Next";
		[btnDone setTitle: @"Next" forState:UIControlStateNormal];
//		self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
		
	}
	else
	{
		imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//		[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];	
		[btnDone setTitle: @"I'm done!" forState:UIControlStateNormal];
		//		btnDone.titleLabel.text = @"I'm done!";
	}
	
	imgView.image = imgAvatar;
}

//- (void)viewDidAppear:(BOOL)animated {
//    [super viewDidAppear:animated];
//}
//
- (IBAction) genericBtnAction
{
	GenericAvatarViewController *genericAvatarViewController = [[GenericAvatarViewController alloc] initWithNibName:@"GenericAvatarView" bundle:nil];
	genericAvatarViewController.avcObj = self;
	[genericAvatarViewController.avcObj retain];
	[self.navigationController pushViewController:genericAvatarViewController animated:YES];
	[genericAvatarViewController release];
	genericAvatarViewController = nil;
}

- (IBAction) libraryBtnAction
{
	if ( [UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary])
	{ 
		UIImagePickerController *picker = [[UIImagePickerController alloc] init]; 
		picker.delegate = self; 
		#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_3_1 
			picker.allowsImageEditing = YES;
		#else
			picker.allowsEditing = YES;
		#endif
		picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary; 
		[self.navigationController presentModalViewController:picker animated:YES];
		[picker release]; 
	} 
	else 
	{ 
		UIAlertView *alert = [[[UIAlertView alloc] 
							  initWithTitle:@"Error accessing photo library" 
							  message:@"Device does not support a photo library" 
							  delegate:self cancelButtonTitle:@"OK" 
							  otherButtonTitles:nil] autorelease ] ; 
		alert.tag = 20;
		[alert show]; 
	} 
}

- (IBAction) doneBtnAction
{
	if (strFileToUpload)
	{
		[self showHUDWithTitle:@"Uploading Avatar"];
		[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(uploadPhoto) userInfo:nil repeats:NO];
	}
	else
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Select an avatar to upload" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
		alert.tag = 10;
		[alert show];
	}
}


#pragma mark  imagePickerController Functions

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	NSLog(@"didFinishPickingMediaWithInfo ---- info is \n'%@' ", info);
	if ( [info objectForKey:@"UIImagePickerControllerEditedImage"] )
	{
		[self writeImageToFile:[info objectForKey:@"UIImagePickerControllerEditedImage"]];
		[picker dismissModalViewControllerAnimated:NO];
	}	
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[picker dismissModalViewControllerAnimated:NO]; 
} 

- (void) writeImageToFile : (UIImage *) selectedImage
{
	NSLog(@"Entered writeImageToFile");
	NSData *imgData = UIImagePNGRepresentation( selectedImage);
	NSString *filePath = [self getFullFilePath: @"TempAvatar.png"];		
	BOOL written = [imgData writeToFile:filePath atomically:YES];
	if (written)
	{
		strFileToUpload = [NSString stringWithString:filePath];
		[strFileToUpload retain];
		NSLog(@"\n\n\n\n\n\n File %@ written successfully !", strFileToUpload); 
		imgAvatar = [UIImage imageWithContentsOfFile:strFileToUpload];
		[imgAvatar retain];
	}
	else
	{
		NSLog(@"\n\n Error writing to the file TempAvatar.png "); 
	}
	NSLog(@"Completed writeImageToFile");
}

# pragma mark  Avatar upload functions

- (void) uploadPhoto	//: (NSURL *) Url
{
	NSLog(@" Entered uploadPhoto");
	ASINetworkQueue *networkQueue = [[ASINetworkQueue alloc] init];
	[networkQueue cancelAllOperations];
	//	[networkQueue setShowAccurateProgress:YES];
	//	[networkQueue setUploadProgressDelegate:progressBar];
	[networkQueue setDelegate:self];
	[networkQueue setRequestDidFinishSelector:@selector(queueComplete)];
	[networkQueue setRequestDidFailSelector: @selector(queueFailed)];
	NSString *photoUploadUrl = [NSString stringWithFormat:@"%@user/uploadavatar", BASE_FLOK_URL ];
	uploadRequest= [[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:[photoUploadUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]] ;
	[uploadRequest setPostValue:kUsername forKey:kUname];
	[uploadRequest setPostValue:kPassword forKey:kPwd];
	[uploadRequest addRequestHeader:@"User-Agent" value:@"Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16"];
	[uploadRequest setTimeOutSeconds:50];
	[uploadRequest setFile:strFileToUpload forKey:@"media" ];
	NSLog(@"strFileToUpload is: '%@' ",strFileToUpload);	
	[networkQueue addOperation:uploadRequest];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	[networkQueue go];
	NSLog(@"Completed uploadPhoto");
}

- (void) queueComplete
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	NSLog(@" Entered queueComplete");
	NSLog(@"Upload response: %@ ",[uploadRequest responseString]);

	NSString *strTemp = [self getFullFilePath:kAvatarFile ];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSError *error = nil;
	if ( [fileManager moveItemAtPath:strFileToUpload toPath:strTemp error:&error] )
		NSLog(@"Successfully Moved  %@", strFileToUpload);
	else
	{
		NSLog(@" Failed to Move %@, \n error is %@", strFileToUpload, [error description]);
		NSData *imgData = [NSData dataWithContentsOfFile:strFileToUpload];
		BOOL flagWritten = [imgData writeToFile:strTemp atomically:YES];
		if ( flagWritten )
		{
			NSLog(@"Successfully Copied  %@", strFileToUpload);
			if ( [fileManager removeItemAtPath:strFileToUpload error:nil] )
				NSLog(@"Successfully Deleted  %@", strFileToUpload);
			else
				NSLog(@"Deletion of file  '%@' failed", strFileToUpload);
		}
		else
			NSLog(@"Copying also failed  %@", strFileToUpload);
	}
	[self killHUD];	
	if ( [dicCredentials objectForKey:@"avatarStatus"] )
	{
		[dicCredentials setValue:@"1" forKey:@"avatarStatus"];
		[dicCredentials setValue: strTemp forKey:@"media"];
		[dicCredentials retain];
		[self saveCredentials:[NSDictionary dictionaryWithDictionary:dicCredentials] toFile:kProfileCreationFile];
		[self continueSelfTagging];
	}
	else
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	NSLog(@" Completed queueComplete");
}

- (void) queueFailed
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	NSLog(@"Connection failed! Error - %@", [[uploadRequest error] localizedDescription]);	 // inform the user
	//	progressBar.hidden = YES;
	//	lblUploading.hidden = YES;
	[self killHUD];
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Avatar uploading Failed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	alert.tag = 20;
	[alert show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 20 )
	{
		exit(0);
	}
}

- (void) continueSelfTagging
{
	ProfileQuestionsViewController *profileQuestionsViewController = [[ProfileQuestionsViewController alloc] initWithNibName:@"ProfileQuestionsView" bundle:nil];
	profileQuestionsViewController.dicCredentials = [NSMutableDictionary dictionaryWithDictionary: dicCredentials];
	[profileQuestionsViewController.dicCredentials retain];
	[self.navigationController pushViewController:profileQuestionsViewController animated:YES];
	[profileQuestionsViewController release];
	profileQuestionsViewController = nil;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of AvatarViewController");
	[imgViewTheme release];
	[imgAvatar release];
	[imgView release];
	[strFileToUpload release];
	[uploadRequest release];
	dicCredentials = nil;
    [super dealloc];
	NSLog(@"Completed dealloc of AvatarViewController");
}

@end

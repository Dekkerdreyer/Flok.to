//
//  DateViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DateViewController.h"
#import "AvatarViewController.h"

@implementation DateViewController

@synthesize dicCredentials;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];

//	dicCredentials =  [NSMutableDictionary dictionaryWithDictionary: [self retrieveCredentials:kProfileCreationFile]];
//	[dicCredentials retain];

	NSDate *date= [NSDate date];
	
	NSLog(@"Current Date: %@",date);
	
	NSCalendar *gregorian = [[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar] autorelease];
	// now build a NSDate object for the next day
	NSDateComponents *offsetComponents = [[[NSDateComponents alloc] init] autorelease];
	[offsetComponents setYear:-10];
	NSDate *maxDate = [gregorian dateByAddingComponents:offsetComponents toDate: date options:0];	
	NSLog(@"max Date: %@",maxDate );
	
	[offsetComponents setYear:-90];
	NSDate *minDate = [gregorian dateByAddingComponents:offsetComponents toDate: date options:0];
	
	NSLog(@"min Date: %@",minDate );
	
//	NSDate *date = [[[NSDate alloc] init] autorelease]; 
	[myDatePicker setMaximumDate:maxDate];
	[myDatePicker setMinimumDate:minDate];


	if ( [[dicCredentials objectForKey:@"dateofbirth"] isEqualToString:@""] )
		[myDatePicker setDate:maxDate animated:YES];
	else
	{	NSDateFormatter *df = [[[NSDateFormatter alloc] init] autorelease];
//			[df setDateFormat:@"yyyy-MM-dd"];
		date = [df dateFromString:[dicCredentials objectForKey:@"dateofbirth"]];
		[myDatePicker setDate:date animated:YES];
	}
// 	if ( [[dicCredentials objectForKey:@"dateStatus"] intValue])
//	{
//		[self showHUD];
//		[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
//	}
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
}


- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
}


- (IBAction)doneBtnAction;
{
	NSDateFormatter *df = [[[NSDateFormatter alloc] init] autorelease];
	[df setDateFormat:@"yyyy-MM-dd"];
	NSString *strSelectedDate=[NSString stringWithFormat:@"%@", [df stringFromDate:myDatePicker.date]];
	NSLog(@"date=%@",strSelectedDate);
	[dicCredentials setValue: strSelectedDate forKey:@"dateofbirth"];
//	[dicCredentials setValue:@"1" forKey:@"dateStatus"];
	[dicCredentials retain];
	[self showHUD];
	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}

- (void) fetchJsonData
{
	NSString *strUrl = [NSString stringWithFormat:@"%@user/addnewprofile?username=%@&password=%@&email=%@&dateofbirth=%@&latitude=0.0&longitude=0.0", 
						BASE_FLOK_URL, [dicCredentials valueForKey:@"username"], [dicCredentials valueForKey:@"password"], [dicCredentials valueForKey:@"email"], [dicCredentials valueForKey:@"dateofbirth"] ];
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	[self killHUD];
	if ( errMsg )
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
		}
		else if ( [errMsg isEqualToString:@"alreadyexist"] )
		{
			alert.tag = 10;
			[dicCredentials setValue:@"0" forKey:@"loginStatus"];
			[dicCredentials retain];
		}
		[self saveCredentials:[NSDictionary dictionaryWithDictionary:dicCredentials] toFile:kProfileCreationFile];
		[alert show];
	}
	else
	{
		[dicCredentials setValue:@"1" forKey:@"profileStatus"];
		[dicCredentials setValue:@"1" forKey:@"dateStatus"];
		[dicCredentials retain];
		[[NSUserDefaults standardUserDefaults] setObject:[dicCredentials valueForKey:kUname] forKey:kUname];
		[[NSUserDefaults standardUserDefaults] setObject:[dicCredentials valueForKey:kPwd] forKey:kPwd];
		[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kUID] forKey:kUID];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		NSLog(@"username is '%@' , pwd is '%@' \n username is '%@' , pwd is '%@' ", kUsername, kPassword, [dicCredentials valueForKey:kUname], [dicCredentials valueForKey:kPwd]);
		[self saveCredentials:[NSDictionary dictionaryWithDictionary:dicCredentials] toFile:kProfileCreationFile];
		[self continueAvatarUpdation];
		
//		NSLog(@"What to do next");
//		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}


- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if (alertView.tag == 10)
	{
		[self.navigationController popToViewController:[[self.navigationController viewControllers] objectAtIndex:1]  animated:YES];
	}
	else if (alertView.tag == 100)
		exit (0);
}


//- (IBAction) submitBtnAction
//{
//	if ( txtEmail.text && ![txtEmail.text isEqualToString:@""] )
//		[dicCredentials setValue:txtEmail.text forKey:@"email"];
//	[dicCredentials setValue:@"Completed" forKey:@"emailStatus"];
//	[self saveCredentials:dicCredentials];
//	[self loadDateView];
//}

- (void) continueAvatarUpdation
{
	AvatarViewController *avatarViewController = [[AvatarViewController alloc] initWithNibName:@"AvatarView" bundle:nil];
	avatarViewController.dicCredentials = [NSMutableDictionary dictionaryWithDictionary: dicCredentials];
	[avatarViewController.dicCredentials retain];
	[self.navigationController pushViewController:avatarViewController animated:YES];
	[avatarViewController release];
	avatarViewController = nil;
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	NSLog(@"Entered dealloc of DateViewController");
	[myDatePicker release];
	dicCredentials = nil;
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of DateViewController");
}


@end

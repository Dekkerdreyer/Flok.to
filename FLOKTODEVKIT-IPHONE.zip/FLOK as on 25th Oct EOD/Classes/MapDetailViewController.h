//
//  MapDetailViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 17/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MapDetailViewController : UIViewController 
{
	IBOutlet UITableView *tableFlok;
	BOOL flagPlaces, flagPersons;
	NSArray *arrTableData;
	NSArray *arrPlaceTypes;
	IBOutlet UIImageView *imgViewTheme;
	BOOL flagDataReady;
}

@property BOOL flagPlaces, flagPersons;
@property (nonatomic, retain) NSArray *arrTableData;

- (void) createSectionArray;

@end

//
//  GenericAvatarViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 29/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "GenericAvatarViewController.h"
#import "CustomCell.h"

@implementation GenericAvatarViewController

@synthesize avcObj;

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
//	CGRect frame = self.view.frame;
//	NSLog(@"View Frame is %@", frame);

    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 9;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if (section)
		return nil;
	else
		return @"Select any one of the Avatars Below"; 
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Avatar Image Cell";
    CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	cell.imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"Avatar-%d.png", indexPath.section] ];
	
    // Set up the cell...
	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	avcObj.imgAvatar = [UIImage imageNamed:[NSString stringWithFormat:@"Avatar-%d.png", indexPath.section]];
	[avcObj.imgAvatar retain];
	[avcObj writeImageToFile:avcObj.imgAvatar];
	[self.navigationController popViewControllerAnimated:YES];
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of GenericAvatarViewController");
	[avcObj release];
  	[imgViewTheme release];
  [super dealloc];
	NSLog(@"Completed dealloc of GenericAvatarViewController");
}


@end


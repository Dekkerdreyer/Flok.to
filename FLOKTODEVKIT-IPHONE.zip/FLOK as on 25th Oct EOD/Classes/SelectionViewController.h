//
//  SelectionViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 05/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"

@interface SelectionViewController : UIViewController 
{
	NSArray *arrRecords;
	int noOfSelectionsNeeded, selectedCount;
	NSMutableArray *arrSelectionStatus;
	ChoiceViewController *choiceViewController;
	IBOutlet UITableView *tableFlok;
//	IBOutlet UIImageView *imgViewTheme;
	BOOL flagDataReady, flagNeedResize, flagPreselectionReqd;	
	NSString *strInstructions;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSArray *arrRecords;
@property (nonatomic, assign) int noOfSelectionsNeeded;
@property (readwrite, nonatomic, retain) ChoiceViewController *choiceViewController;
@property (nonatomic, retain) NSString *strInstructions;
@property BOOL flagNeedResize, flagPreselectionReqd;

- (void) sortArray;

@end

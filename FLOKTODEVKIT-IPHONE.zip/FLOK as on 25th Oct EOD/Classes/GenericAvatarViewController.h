//
//  GenericAvatarViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 29/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AvatarViewController.h"

@interface GenericAvatarViewController : UIViewController
{
	AvatarViewController *avcObj;
	IBOutlet UITableView *tableFlok;
	IBOutlet UIImageView *imgViewTheme;
}

@property (readwrite, nonatomic, retain) AvatarViewController *avcObj;

@end

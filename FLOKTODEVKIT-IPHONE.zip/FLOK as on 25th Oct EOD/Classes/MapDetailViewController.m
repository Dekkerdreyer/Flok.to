//
//  MapDetailViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 17/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MapDetailViewController.h"
#import "PersonProfileViewController.h"
#import "PlaceProfileViewController.h"


@implementation MapDetailViewController

@synthesize flagPlaces, flagPersons;
@synthesize arrTableData;

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    if (self = [super initWithStyle:style]) {
    }
    return self;
}
*/


- (void)viewDidLoad {
    [super viewDidLoad];

	tableFlok.backgroundColor = [UIColor clearColor];	
	if ( flagPlaces )
	{
		flagDataReady = NO;
		[self createSectionArray];
	}
	else
		flagDataReady = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

- (void) createSectionArray
{
	NSSortDescriptor *aSortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"placename" ascending:YES selector:@selector(caseInsensitiveCompare:)];
	NSMutableArray *arrTemp = [[[NSMutableArray alloc] initWithArray:arrTableData] retain];
	[arrTemp sortUsingDescriptors:[NSArray arrayWithObject:aSortDescriptor]];
	arrTableData = [NSArray arrayWithArray:arrTemp];
	[arrTableData retain];
	[arrTemp release];
	[aSortDescriptor release];

	NSMutableArray *arrPlaceTypeNames = [[[NSMutableArray alloc] init] retain];
	for (NSDictionary *dicPlace in arrTableData ) 
		[arrPlaceTypeNames addObject:[dicPlace valueForKey:@"placetypename"]];
	[arrPlaceTypeNames retain];
	NSMutableSet *arrPlaces = [[[NSMutableSet alloc] init] retain];
	[arrPlaces addObjectsFromArray:arrPlaceTypeNames];
	
	//NSSortDescriptor *firstDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES selector:@selector(localizedCaseInsensitiveCompare:)] autorelease];
	
//	NSArray * descriptors = [NSArray arrayWithObjects:firstDescriptor, nil];
	arrPlaceTypes = [[arrPlaces allObjects] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:) ];
	
	[arrPlaceTypes retain];
	[arrPlaces release];
	NSMutableArray *arrTempData = [[[NSMutableArray alloc] init] retain];
	for ( int i=0; i < [arrPlaceTypes count]; i++ )
		[arrTempData addObject:[[[NSMutableArray alloc] init] autorelease] ];
	[arrTempData retain];
	for (int i=0; i < [arrTableData count]; i++ ) 
	{
		int j=0;
		for ( NSString *placeType in arrPlaceTypes )
		{
			if ( [placeType isEqualToString:[arrPlaceTypeNames objectAtIndex:i]] )
			{
				[[arrTempData objectAtIndex:j] addObject:[arrTableData objectAtIndex:i]];
				break;
			}
			j++;
		}
	}
	arrTableData = [NSArray arrayWithArray:arrTempData];
	[arrTableData retain];
	[arrTempData release];
	[arrPlaceTypeNames release];
	flagDataReady= YES;
	[tableFlok reloadData];
}

/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	if ( flagDataReady )
		return [arrTableData count];
	else
		return 0;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if ( flagDataReady )
	{
		if ( flagPlaces )
			return [[arrTableData objectAtIndex:section] count];
		else
			return 1;
	}
	else
		return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if ( flagDataReady )
	{
		if ( flagPlaces )
			return [[arrPlaceTypes objectAtIndex:section] capitalizedString];
		else
			return @"";
	}
	else
		return @"";
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier;// = @"Cell";
    
	if ( flagPlaces )
	{
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		}
		NSDictionary *dicRecord = [[arrTableData objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
		cell.textLabel.text = [dicRecord valueForKey:@"placename"];
		cell.detailTextLabel.text = [dicRecord valueForKey:@"address1"];
		return cell;
	}
	else
	{
		UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		}
		NSDictionary *dicRecord = [arrTableData objectAtIndex:indexPath.section] ;
		cell.textLabel.text = [dicRecord valueForKey:@"username"];
		return cell;
	}
	
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	if ( !flagPlaces )
	{
		NSDictionary *dicRecord = [arrTableData objectAtIndex:indexPath.section];
		PersonProfileViewController *personProfileViewController = [[PersonProfileViewController alloc] initWithNibName:@"PersonProfileView" bundle:nil ];
		personProfileViewController.dicProfileInfo = dicRecord;
		[personProfileViewController.dicProfileInfo retain];
		[self.navigationController pushViewController:personProfileViewController animated:YES];
		[personProfileViewController release];
		personProfileViewController = nil;
	}
	else
	{
		NSDictionary *dicRecord = [[arrTableData objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
		PlaceProfileViewController *placeProfileViewController = [[PlaceProfileViewController alloc] initWithNibName:@"PlaceProfileView" bundle:nil ];
		placeProfileViewController.dicPlaceDetails = dicRecord;
		[placeProfileViewController.dicPlaceDetails retain];
		[self.navigationController pushViewController:placeProfileViewController animated:YES];
		[placeProfileViewController release];
		placeProfileViewController = nil;
	}
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of MapDetailViewController");
	[tableFlok release];
	if ( arrTableData )
		[arrTableData release];
	if ( arrPlaceTypes )
		[arrPlaceTypes release];
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of MapDetailViewController");
}


@end


//
//  TabBarViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 04/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdWhirlDelegateProtocol.h"

@class AdWhirlView, AdWhirlDelegate;

@interface TabBarViewController : UIViewController <AdWhirlDelegate, UITabBarControllerDelegate>
{
	IBOutlet UITabBarController *tabbarController;
}

- (void) removeView;

@end

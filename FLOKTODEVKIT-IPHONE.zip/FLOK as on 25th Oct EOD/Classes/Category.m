//
//  Category.m
//  Piuinfo
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Category.h"


@implementation Category
@synthesize name, arrDtls;

+ (id) categoryNamed: (NSString *) catgName withDetails: (NSArray *) catgArr
{
	Category *newCatg = [[[self alloc] init] autorelease];
	newCatg.arrDtls = catgArr;
	newCatg.name = catgName;
	return newCatg;	
}

- (void)dealloc
{
//	NSLog( @"Entered dealloc of Category");
	[arrDtls release];
	[name release];
	[super dealloc];
//	NSLog( @"Completed dealloc of Category");
}

@end

//
//  Tab2ViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Tab2ViewController.h"
#import "MapViewController.h"
#import "PersonProfileViewController.h"

@implementation Tab2ViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	txtUsername = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 40.0, 260.0, 25.0)];
	[txtUsername retain];
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

- (IBAction) tagPersonBtnAction
{
	MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
	mapViewController.searchStyle = SearchPersonLikeMe;
	[self.navigationController pushViewController: mapViewController animated:YES];
	[mapViewController release];
	mapViewController = nil;
}

- (IBAction) tagPlaceBtnAction
{
	MapViewController *mapViewController = [[MapViewController alloc] initWithNibName:@"MapView" bundle:nil];
	mapViewController.searchStyle = SearchPlacesIdLike;
	mapViewController.strPlaceTypeId = @"0";
	[mapViewController.strPlaceTypeId retain];
	[self.navigationController pushViewController: mapViewController animated:YES];
	[mapViewController release];
	mapViewController = nil;
}

- (IBAction) searchUserBtnAction
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Enter Username to be searched\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Search", nil];
	CGAffineTransform myTransform = CGAffineTransformMakeTranslation(0.0, 75.0);
	[alert setTransform:myTransform];
	[txtUsername setBackgroundColor:[UIColor whiteColor]];
	txtUsername.keyboardType = UIKeyboardTypeAlphabet;
	txtUsername.keyboardAppearance = UIKeyboardAppearanceAlert;
	txtUsername.autocorrectionType = UITextAutocorrectionTypeNo;
	txtUsername.clearButtonMode = UITextFieldViewModeWhileEditing;
	//	txtUsername.borderStyle = UITextBorderStyleRoundedRect;
	
	[alert addSubview:txtUsername];
	alert.tag = 75;
	[alert show];
	[txtUsername becomeFirstResponder];
	[alert release];	
}

- (void) fetchJsonData
{
	NSString *strUrl = [NSString stringWithFormat:@"%@user/searchbyusername?username=%@&password=%@&searchusername=%@"
				  , SESSION_URL, txtUsername.text ];
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			//			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			//			[alert show];
		}
		else
			alert.tag = 20;
		[alert show];
	}
	else
	{
		[self killHUD];
		PersonProfileViewController *personProfileViewController = [[PersonProfileViewController alloc] initWithNibName:@"PersonProfileView" bundle:nil ];
		personProfileViewController.dicProfileInfo = dicResponse;
		[personProfileViewController.dicProfileInfo retain];
		[self.navigationController pushViewController:personProfileViewController animated:YES];
		[personProfileViewController release];
		personProfileViewController = nil;
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if ( alertView.tag == 75 )
	{
		if ( buttonIndex )
		{
			NSLog(@"text is %@", txtUsername.text);
			//![txtUsername.text isEqualToString:@""] &&
			if (  ![[txtUsername.text capitalizedString] isEqualToString:[kUsername capitalizedString]] )
			{
				[self showHUD];
				[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
			}
			else
			{
				UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"You are not supposed to search yourself" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
				[alert show];
				[alert release];
			}
		}
	}
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of Tab2ViewController");
	if ( txtUsername )
		[txtUsername release];
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of Tab2ViewController");
}


@end

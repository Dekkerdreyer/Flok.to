//
//  AcceptNewPlaceViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 19/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AcceptNewPlaceViewController.h"
#import "AddNewPlaceViewController.h"
#import "MatchingPlacesViewController.h"


@implementation AcceptNewPlaceViewController

@synthesize txtName, txtAddress1, txtAddress2, txtAddress3, txtCity, txtState, txtCountry, txtWebsite;
@synthesize dataSourceArray;

- (void)viewDidLoad 
{
	[super viewDidLoad];
	tableFlok.backgroundColor = [UIColor clearColor];
	arrFieldParams = [[[NSMutableArray alloc] init] retain];
	
	self.dataSourceArray = [NSMutableArray arrayWithObjects: [NSArray arrayWithObjects:							
															  [NSDictionary dictionaryWithObjectsAndKeys: @"Placename", kLabelKey, self.txtName, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"Address1", kLabelKey, self.txtAddress1, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"Address2", kLabelKey, self.txtAddress2, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"Address3", kLabelKey, self.txtAddress3, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"City", kLabelKey, self.txtCity, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"State", kLabelKey, self.txtState, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"Country", kLabelKey, self.txtCountry, kViewKey, nil]
															  , [NSDictionary dictionaryWithObjectsAndKeys: @"Website", kLabelKey, self.txtWebsite, kViewKey, nil]
															  , nil]
							, [NSArray arrayWithObject: @"Submit"]
							, nil];
	
//	currRequestNum = 1;
//	[self showHUDWithTitle:@"Getting Place Types"];
//	[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
}


- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
}

- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@place/ validateplace?username=%@&password=%@%@"
						 , SESSION_URL , strParameters ];
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl ];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"place_not_exist" ] )
		{
			AddNewPlaceViewController *addNewPlaceViewController = [[AddNewPlaceViewController alloc] initWithNibName:@"AddNewPlaceView" bundle:nil];
			addNewPlaceViewController.arrFieldParams = [NSArray arrayWithArray:arrFieldParams];
			[addNewPlaceViewController.arrFieldParams retain];
			[self.navigationController pushViewController:addNewPlaceViewController animated:YES];
			[addNewPlaceViewController release];
			addNewPlaceViewController = nil;
		}
	}
	else
	{
		[self killHUD];
		if ( currRequestNum == 1 )
		{
			MatchingPlacesViewController *matchingPlacesViewController = [[MatchingPlacesViewController alloc] initWithNibName:@"MatchingPlacesView" bundle:nil];
			matchingPlacesViewController.arrFieldParams = [NSArray arrayWithArray:arrFieldParams];
			[matchingPlacesViewController.arrFieldParams retain];
			matchingPlacesViewController.arrTableData = [dicResponse valueForKey:@"jsonResult"];
			[matchingPlacesViewController.arrTableData retain];
			[self.navigationController pushViewController:matchingPlacesViewController animated:YES];
			[matchingPlacesViewController release];
			matchingPlacesViewController = nil;
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
}



/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [dataSourceArray count];
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [[dataSourceArray objectAtIndex:section] count] ;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    static NSString *CellIdentifier;
	
	int rowID = indexPath.row;
	int secID = indexPath.section;
	UITableViewCell *cell = nil;
	
	if ( secID == 0  )
	{
		CellIdentifier = @"DisplayCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.selectionStyle = UITableViewCellSelectionStyleNone;
			//			[cell.textLabel setFrame:  CGRectMake( 5, 12.5, 90, 20)];
			cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
			//			cell.textLabel.textAlignment = UITextAlignmentRight;
			cell.textLabel.textColor = [UIColor colorWithRed:0.203754 green:0.335363 blue:0.531151 alpha:1];
		}
		else
		{
			// the cell is being recycled, remove old embedded controls
			UIView *viewToRemove = nil;
			viewToRemove = [cell.contentView viewWithTag: rowID+1];
			if (viewToRemove)
				[viewToRemove removeFromSuperview];
		}
		
		cell.textLabel.text = [[[self.dataSourceArray objectAtIndex: secID] objectAtIndex: rowID] valueForKey:kLabelKey];
		
		UIControl *control = [[[self.dataSourceArray objectAtIndex: secID] objectAtIndex: rowID] valueForKey:kViewKey];
		[cell.contentView addSubview:control];
	}
	else
	{
		CellIdentifier = @"SubmitCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			cell.textLabel.text = [[self.dataSourceArray objectAtIndex: secID] objectAtIndex:rowID];
		}
	}
	//	cell.backgroundColor = [UIColor clearColor];	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	int secID = indexPath.section;
	
	if ( secID == 0  )
	{
	}
	else if ( secID == 1 )
	{
		BOOL flagInvalidRegistration = NO;
		[arrFieldParams removeAllObjects];
		[arrFieldParams retain];
		NSMutableString *strTemp = [[[NSMutableString alloc] initWithString:@""] retain];
		for ( NSDictionary *dicRecord in [self.dataSourceArray objectAtIndex: 0] )
		{
			UITextField *currTextField = [dicRecord valueForKey:kViewKey];
			if ( !(currTextField.tag == 1) && !( currTextField.tag == 8 ) )
				[strTemp appendFormat:@"&%@=%@", [[dicRecord valueForKey:kLabelKey] lowercaseString], currTextField.text ];
			[arrFieldParams addObject:currTextField.text];
			if ( !(currTextField.tag == 3) && !(currTextField.tag == 4) && !(currTextField.tag == 8) )
				if ( [currTextField.text isEqualToString:@""] )
					flagInvalidRegistration = YES;
			if ( flagInvalidRegistration )
				break;
		}
		if ( ! flagInvalidRegistration )
		{
			[arrFieldParams retain];
			strParameters = [NSString stringWithFormat:@"%@", strTemp ];
			[strParameters retain];
			[strTemp release];
			currRequestNum = 1;
			[self showHUDWithTitle:@"Verifying Place"];
			[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
		}
		else
		{
			[strTemp release];
			NSLog(@"Invalid selection");
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Insufficient Data" message:@"You have missed some Mandatory fields" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alert show];
		}
	}
}

#pragma mark textField Methods
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	if ( textField.tag > 3 )
	{
		CGRect rc = [textField bounds];
		UITableView * v = tableFlok;
		rc = [textField convertRect:rc toView:v];
		CGPoint pt = rc.origin ;
		pt.x = 0 ;
	//	pt.y = 20;
		[v setContentOffset:pt animated:YES];
	}
}

//- (void)textFieldDidEndEditing:(UITextField *)textField
//{
//}


#pragma mark Text Filed Functions
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	if ( textField.tag > 3 )
	{
		CGRect rc = [textField bounds];
		UITableView * v = tableFlok;
		rc = [textField convertRect:rc toView:v];
		CGPoint pt = rc.origin ;
		pt.x = 0 ;
		pt.y = 0;
		[v setContentOffset:pt animated:YES];
	}
	[textField resignFirstResponder];
	return YES;
}

- (void) setTextField : (UITextField *) currTextField
{
	[currTextField setFrame:CGRectMake( 100, 7, 190, 31)];
	if ( !(currTextField.tag == 3) && !(currTextField.tag == 4) && !(currTextField.tag == 8) )
		currTextField.placeholder = @"This is a Mandatory Field";
	currTextField.delegate = self;
	currTextField.borderStyle = UITextBorderStyleRoundedRect;
	currTextField.clearsOnBeginEditing = NO;
	currTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
	currTextField.font = [UIFont systemFontOfSize:14];
	currTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
	currTextField.text = @"";
	currTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
}

#pragma mark Lazy creation of controls

- (UITextField *) txtName
{
	if (txtName == nil)
	{
		txtName = [[UITextField alloc] init];
		txtName.tag = 1;
		[self setTextField:txtName];
	}
	return txtName;
}

- (UITextField *) txtAddress1
{
	if (txtAddress1 == nil)
	{
		txtAddress1 = [[UITextField alloc] init];
		txtAddress1.tag = 2;
		[self setTextField:txtAddress1];
	}
	return txtAddress1;
}

- (UITextField *) txtAddress2
{
	if (txtAddress2 == nil)
	{
		txtAddress2 = [[UITextField alloc] init];
		txtAddress2.tag = 3;
		[self setTextField:txtAddress2];
	}
	return txtAddress2;
}

- (UITextField *) txtAddress3
{
	if (txtAddress3 == nil)
	{
		txtAddress3 = [[UITextField alloc] init];
		txtAddress3.tag = 4;
		[self setTextField:txtAddress3];
	}
	return txtAddress3;
}

- (UITextField *) txtCity
{
	if (txtCity == nil)
	{
		txtCity = [[UITextField alloc] init];
		txtCity.tag = 5;
		[self setTextField:txtCity];
	}
	return txtCity;
}

- (UITextField *) txtState
{
	if (txtState == nil)
	{
		txtState = [[UITextField alloc] init];
		txtState.tag = 6;
		[self setTextField:txtState];
	}
	return txtState;
}

- (UITextField *) txtCountry
{
	if (txtCountry == nil)
	{
		txtCountry = [[UITextField alloc] init];
		txtCountry.tag = 7;
		[self setTextField:txtCountry];
	}
	return txtCountry;
}

- (UITextField *) txtWebsite
{
	if (txtWebsite == nil)
	{
		txtWebsite = [[UITextField alloc] init];
		txtWebsite.tag = 8;
		[self setTextField:txtWebsite];
	}
	return txtWebsite;
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of AcceptNewPlaceViewController");
	[txtName release];
	[txtAddress1 release];
	[txtAddress2 release];
	[txtAddress3 release];
	[txtCity release];
	[txtState release];
	[txtCountry release];
	[txtWebsite release];
	[tableFlok release];
	[dataSourceArray release];
	[arrFieldParams release];
	[strParameters release];
	dicPlaceDetails = nil;
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of AcceptNewPlaceViewController");
}

@end


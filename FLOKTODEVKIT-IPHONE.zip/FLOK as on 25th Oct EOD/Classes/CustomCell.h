//
//  CustomCell.h
//  
//
//  Created by Rajesh Tamada on 29/01/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCell : UITableViewCell 
{
	UIImageView *imgView;
}

@property (nonatomic, retain) UIImageView *imgView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier ;

@end

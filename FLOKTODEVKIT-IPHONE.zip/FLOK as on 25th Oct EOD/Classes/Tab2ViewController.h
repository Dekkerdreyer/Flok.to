//
//  Tab2ViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Tab2ViewController : UIViewController <UITextFieldDelegate>
{
	IBOutlet UIImageView *imgViewTheme;
	UITextField *txtUsername;
}

- (IBAction) tagPersonBtnAction;
- (IBAction) tagPlaceBtnAction;
- (IBAction) searchUserBtnAction;

@end

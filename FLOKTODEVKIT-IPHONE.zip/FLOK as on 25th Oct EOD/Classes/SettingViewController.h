//
//  SettingViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SettingViewController : UIViewController 
{
	IBOutlet UITableView *tableFlok;
	NSMutableArray *arrTableData;
	int currRequestNum;
	NSMutableDictionary *dicCredentials;
	IBOutlet UIImageView *imgViewTheme;
}

- (void) continueSelfTagging;

@end

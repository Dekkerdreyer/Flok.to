//
//  Tab1ViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"
#import "SelectionViewController.h"

@interface Tab1ViewController : ChoiceViewController 
{
	int currRequestNum;
	UITextField *txtUsername;
	NSString *strTagCsv;
	BOOL flagNeedToShowMPDView;
	IBOutlet UIImageView *imgViewTheme;
}

- (IBAction) pplLikeMeBtnAction;
- (IBAction) pplByTagBtnAction;
- (IBAction) searchUserBtnAction;
- (IBAction) placesIdLikeBtnAction;
- (IBAction) placesByTagBtnAction;

@end

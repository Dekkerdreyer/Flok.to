//
//  FbGraphResponse.m
//  oAuth2Test
//
//  Created by dominic dimarco (ddimarco@room214.com @dominicdimarco) on 6/5/10.
//  Copyright 2010 Room 214. All rights reserved.
//

#import "FbGraphResponse.h"


@implementation FbGraphResponse

@synthesize htmlResponse;
@synthesize imageResponse;
@synthesize error;

@end

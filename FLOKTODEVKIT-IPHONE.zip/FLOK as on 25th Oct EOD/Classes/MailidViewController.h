//
//  MailidViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 26/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MailidViewController : UIViewController 
{
	IBOutlet UITextField *txtEmail;
	IBOutlet UIButton *btnSubmit;
	IBOutlet UITextView *txtView;
	NSMutableDictionary	*dicCredentials;
	BOOL				flagStepCompleted;
	BOOL flagUpdatingProfile;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSMutableDictionary *dicCredentials;
@property (nonatomic) BOOL flagUpdatingProfile;

- (IBAction) submitBtnAction;
- (void) loadDateView;
- (BOOL)validateEmail:(NSString *)email;

@end

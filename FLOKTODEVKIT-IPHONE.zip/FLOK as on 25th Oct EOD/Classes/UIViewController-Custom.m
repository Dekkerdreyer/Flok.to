//
//  UIViewController-Json.m
//  
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "UIViewController-Custom.h"
#import "OAuth.h"
#import "OAuth+UserDefaults.h"
#import "ASIFormDataRequest.h"
#import "JSON.h"
#import "CustomLoginPopup.h"
#import "FbGraph.h"
#import "FbGraphResponse.h"
#import "TwitterUpdateViewController.h"
#import "FacebookLoginViewController.h"

@implementation UIViewController (Json_MBProgressHUD)



 - (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == kAlertNetwork )
	{
		exit(0);
	}
	else if ( alertView.tag == kAlertLoginFail )
	{
		exit(0);
	}
	else if ( alertView.tag == kAlertFacebooUpdate )
	{
		switch (buttonIndex) 
		{
			case 0:	
				[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey: @"fb_AlertReqd"];
				[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"fb_UpdtReqd"];
				[[NSUserDefaults standardUserDefaults] synchronize];
			case 1:
				NSLog(@"");
				NSString *responseId = nil;
				if ( kFacebookToken ) 
				{
					responseId = [self updateOnFacebook: alertView.message ];
				}
				if ( !responseId )
				{
					FacebookLoginViewController *facebookLoginViewController = [[FacebookLoginViewController alloc] initWithNibName:@"FacebookLoginView" bundle:nil];
					facebookLoginViewController.strMessage = alertView.message;
					[facebookLoginViewController.strMessage retain];
					[self.navigationController pushViewController:facebookLoginViewController animated:YES];
					[facebookLoginViewController release];
					facebookLoginViewController = nil;
				}
				else
				{
//					UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Facebook Updation Successfull" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
//					alert.tag = 400;
//					[alert show];
				}
				break;
			case 2:				
				break;
			case 3:				
				[[NSUserDefaults standardUserDefaults] setInteger:0 forKey: @"fb_AlertReqd"];
				[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey:@"fb_UpdtReqd"];
				[[NSUserDefaults standardUserDefaults] synchronize];
				break;
			default:
				break;
		}
	}
	else if ( alertView.tag == kAlertTwitterUpdate )
	{
		switch (buttonIndex) 
		{
			case 0:	
				[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey: @"tw_AlertReqd"];
				[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"tw_UpdtReqd"];
				[[NSUserDefaults standardUserDefaults] synchronize];
			case 1:
				[self updateOnTwitter:alertView.message];
				break;
			case 2:				
				break;
			case 3:				
				[[NSUserDefaults standardUserDefaults] setInteger:0 forKey: @"tw_AlertReqd"];
				[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey:@"tw_UpdtReqd"];
				[[NSUserDefaults standardUserDefaults] synchronize];
				break;
			default:
				break;
		}
	}
	else if ( alertView.tag == kAlertTwitterFail )
	{
		switch (buttonIndex) {
			case 0:
				[self updateOnTwitter:alertView.message];
				break;
			case 1:
				[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey:@"twitter_oauth_token_authorized"];
				[[NSUserDefaults standardUserDefaults] synchronize];
				[self updateOnTwitter:alertView.message];
				break;
			case 2:
				break;
			default:
				break;
		}
	}
}

- (void) updateOnTwitter : (NSString *) strMessage
{
	int responseId = 0;
	if ( kTwitterAuthorized ) 
	{
		responseId = [self postTweet: strMessage ];
	}
	else
	{
		TwitterUpdateViewController *twitterUpdateViewController = [[TwitterUpdateViewController alloc] initWithNibName:@"TwitterUpdateView" bundle:nil];
		twitterUpdateViewController.tweetMsg = strMessage;
		[twitterUpdateViewController.tweetMsg retain];
		[self.navigationController pushViewController:twitterUpdateViewController animated:YES];
		[twitterUpdateViewController release];
		twitterUpdateViewController = nil;
	}
	if ( !(responseId == 200) && kTwitterAuthorized )
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Unable to Connect/Post to twitter" message:strMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"Retry", @"Reset Twitter Credentials", @"Cancel", nil] autorelease];
		alert.tag = kAlertTwitterFail ;
		[alert show];
	}
}

- (void) showTwitterUpdateAlert: (NSString *)strMessage
{
	UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Update on twitter?" message:strMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"Always", @"Only this time", @"Not this time", @"Never", nil] autorelease];
	alertView.tag = kAlertTwitterUpdate;
	[alertView show];
}

- (void) showFacebookUpdateAlert: (NSString *)strMessage
{
	UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Update on Facebook?" message:strMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"Always", @"Only this time", @"Not this time", @"Never", nil] autorelease];
	alertView.tag = kAlertFacebooUpdate;
	[alertView show];
}

#pragma mark NavBar Functions

- (void) initNavBarWithTitle : (NSString *)title
{
	self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
	UILabel *lblNavTitle = [[UILabel alloc] initWithFrame:CGRectMake( 50, 2.0, 220, 40)] ;
	lblNavTitle.textColor = [UIColor whiteColor];
	lblNavTitle.textAlignment = UITextAlignmentCenter;
	lblNavTitle.backgroundColor = [UIColor clearColor];
	lblNavTitle.font = [UIFont fontWithName:@"Verdana-Bold" size: 18 ];
	lblNavTitle.text = title;
	self.navigationItem.titleView = lblNavTitle;
	[lblNavTitle release];
}

- (void) initNavBar
{
	self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
}

#pragma mark Facebook functions

- (NSString *) updateOnFacebook: (NSString *) strMessage
{
	//alloc and initalize our FbGraph instance
	FbGraph *fbGraph = [[[FbGraph alloc] initWithFbClientID:client_id] autorelease];
	fbGraph.accessToken = kFacebookToken;
	NSMutableDictionary *variables = [NSMutableDictionary dictionaryWithCapacity:4];
	
	[variables setObject:strMessage forKey:@"message"];
	// 	[variables setObject:@"http://bit.ly/bFTnqd" forKey:@"link"];
	// 	[variables setObject:@"This is the bolded copy next to the image" forKey:@"name"];
	// 	[variables setObject:@"This is the plain text copy next to the image.  All work and no play makes Jack a dull boy." forKey:@"description"];
	
	FbGraphResponse *fb_graph_response = [fbGraph doGraphPost:@"me/feed" withPostVars:variables];
	NSLog(@"fb_graph_response:  %@", fb_graph_response.htmlResponse);
	
	//parse our json
	SBJSON *parser = [[SBJSON alloc] init];
	NSDictionary *facebook_response = [parser objectWithString:fb_graph_response.htmlResponse error:nil];	
	[parser release];
	
//	NSLog(@"Now log into Facebook and look at your profile...");
	return [facebook_response objectForKey:@"id"];
}


#pragma mark  twitter Functions
- (OAuth *) readyToTweet
{
	OAuth *oAuth = [[[OAuth alloc] initWithConsumerKey:TWITTER_OAUTH_CONSUMER_KEY andConsumerSecret:TWITTER_OAUTH_CONSUMER_SECRET ] autorelease];
	[oAuth loadOAuthTwitterContextFromUserDefaults];
	if (oAuth.oauth_token_authorized)
		return oAuth;
	else
		return nil;
}

- (int) postTweet: (NSString *) tweetMsg
{
    // We assume that the user is authenticated by this point and we have a valid OAuth context,
    // thus no need to do context checking.
    
	OAuth *oAuth = [[[OAuth alloc] initWithConsumerKey:TWITTER_OAUTH_CONSUMER_KEY andConsumerSecret:TWITTER_OAUTH_CONSUMER_SECRET ] retain];
	[oAuth loadOAuthTwitterContextFromUserDefaults];
	if (oAuth.oauth_token_authorized)
		NSLog(@"authorized ");
	else
		NSLog(@"Not authorized ");
	//	NSLog(@"Logged in as %@.", oAuth.screen_name);
	ASIFormDataRequest *request = nil;
	NSString *postUrl = @"https://api.twitter.com/1/statuses/update.json";
	[postUrl retain];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	for ( int retryCount = 0; retryCount < 3; retryCount ++ )
	{
		request = [[[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:postUrl]] retain];
		[request setPostValue: tweetMsg	forKey: @"status"];
		NSDictionary *dicParams = [NSDictionary dictionaryWithObject:tweetMsg forKey:@"status"];
		NSString *headerValue = [oAuth oAuthHeaderForMethod:@"POST" andUrl:postUrl  andParams:  dicParams]; //andTokenSecret:oAuth.oauth_token_secret
		NSLog(@"headerValue is '%@' ", headerValue);
		[request addRequestHeader:@"Authorization" value:headerValue ];
	//	[request addRequestHeader: @"Authorization"	value: [oAuth oAuthHeaderForMethod:@"POST"   andUrl:postUrl
	//					 andParams:[NSDictionary dictionaryWithObject:tweetMsg forKey:@"status"]  ] ];
		[request startSynchronous];
		NSLog(@"HTTP result code: '%d' ,Retrying Count %d", request.responseStatusCode, retryCount );
		if ( request.responseStatusCode == 200 )
			break;
	}
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	NSLog(@"Status posted. response message:%@, HTTP result code: %d", request.responseStatusMessage, request.responseStatusCode);
	int responseCode = request.responseStatusCode;
	[request release];
	[oAuth release];
	[postUrl release];
	return responseCode;
}

- (void) logoutFromTwitter
{
    // We assume that the user is authenticated by this point and we have a valid OAuth context,
    // thus no need to do context checking.
    
	OAuth *oAuth = [[[OAuth alloc] initWithConsumerKey:TWITTER_OAUTH_CONSUMER_KEY andConsumerSecret:TWITTER_OAUTH_CONSUMER_SECRET ] retain];
	[oAuth loadOAuthTwitterContextFromUserDefaults];
	if (oAuth.oauth_token_authorized)
		NSLog(@"authorized ");
	else
		NSLog(@"Not authorized ");
	//	NSLog(@"Logged in as %@.", oAuth.screen_name);
	ASIFormDataRequest *request = nil;
	NSString *postUrl = @"https://api.twitter.com/1/account/end_session.json";
	[postUrl retain];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	for ( int retryCount = 0; retryCount < 3; retryCount ++ )
	{
		request = [[[ASIFormDataRequest alloc] initWithURL:[NSURL URLWithString:postUrl]] retain];
		NSString *headerValue = [oAuth oAuthHeaderForMethod:@"POST" andUrl:postUrl  andParams:  nil]; //andTokenSecret:oAuth.oauth_token_secret
		NSLog(@"headerValue is '%@' ", headerValue);
		[request addRequestHeader:@"Authorization" value:headerValue ];
		[request startSynchronous];
		NSLog(@"HTTP result code: '%d' ,Retrying Count %d", request.responseStatusCode, retryCount );
		if ( request.responseStatusCode == 200 )
			break;
	}
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	NSLog(@"Logout Status . response message:%@, HTTP result code: %d", request.responseStatusMessage, request.responseStatusCode);
	[request release];
	[oAuth release];
	[postUrl release];
}

#pragma mark File Functions
- (NSString *) getFullFilePath : (NSString *) filename
{	
	//Search for standard documents using NSSearchPathForDirectoriesInDomains
	//First Param = Searching the documents directory
	//Second Param = Searching the Users directory and not the System
	//Expand any tildes and identify home directories.
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
	NSString *documentsDir = [paths objectAtIndex:0];
	return [documentsDir stringByAppendingPathComponent: filename];
}

- (NSDictionary *) retrieveCredentials: (NSString *) fileName
{
	NSString *filePath = [self getFullFilePath: fileName] ;
	return [NSDictionary dictionaryWithContentsOfFile:filePath] ;
}

- (BOOL) saveCredentials: (NSDictionary *) dicToSave toFile:(NSString *) fileName
{
	NSString *filePath = [self getFullFilePath: fileName];
	BOOL success = [dicToSave writeToFile:filePath atomically:YES];
	if (success)
		NSLog(@"Writing to file %@ was successful", filePath);
	else
		NSLog(@"Writing to file %@ was failed", filePath);
	return success;
}

#pragma mark JSON Parsing Functions
- (void) fetchJsonData
{		
}

- (id) getJsonObjectFromUrl:(NSString *) strUrl
{
	NSLog(@"getting json data from Url : \n%@", strUrl);	
	NSURL *url = [NSURL URLWithString: [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
	
	SBJSON *jsonParser = [SBJSON new];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSString *jsonString = [self stringWithUrl:url];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
	// Parse the JSON into an Object
	return [jsonParser objectWithString:jsonString error:NULL];
}

- (NSString *)stringWithUrl:(NSURL *)url
{
	NSURLRequest *urlRequest = [NSURLRequest		requestWithURL:url		cachePolicy:NSURLRequestReturnCacheDataElseLoad	timeoutInterval:30];
	// Fetch the JSON response
	NSData *urlData;
	NSURLResponse *response;
	NSError *error;
	NSString *jsonResponse;
	// Make synchronous request
	urlData = [NSURLConnection	sendSynchronousRequest:urlRequest	returningResponse:&response	error:&error];
	
 	// Construct a String around the Data from the response
	if ( [urlData bytes] )
	{
		jsonResponse = [[[NSString alloc] initWithData:urlData encoding:NSUTF8StringEncoding] autorelease];		
		if ( !jsonResponse)
		{
			NSLog(@"NSUTF8StringEncoding returned nil so trying NSASCIIStringEncoding");
			jsonResponse = [[[NSString alloc] initWithData:urlData encoding:NSASCIIStringEncoding] autorelease];	
		}
		if ( [jsonResponse length] )
		{
			if ( ! [[jsonResponse substringToIndex:1] isEqualToString: @"{" ] )
			{
				jsonResponse = @"{\"errmsg\":\"PHP Error\",\"errdesc\":\"Retry Later. Reported the error\"}";
			}
		}
		else
		{
			jsonResponse = @"{\"errmsg\":\"PHP Encoding Error\",\"errdesc\":\"Retry Later. Reported the error\"}";
		}
		//		NSLog(@"JSON data is \n%@\n", jsonResponse);
	}
	else
	{
		NSLog(@"Error is \n %@", error);
		jsonResponse = @"{\"errmsg\":\"Network Error\",\"errdesc\":\"No network connection found. You are about to Quit the App.\"}";
	}
	return jsonResponse;
}


#pragma mark ProgressHUD Functions

- (void) showHUDTitled : (NSString *) title andSubTitled : (NSString *) subTitle
{
	//	NSLog(@"Entered showHUD");
	// Should be initialized with the windows frame so the HUD disables all user input by covering the entire screen
	FLOKAppDelegate *appDelgObj = [[UIApplication sharedApplication] delegate];
	appDelgObj.HUD = [[MBProgressHUD alloc] initWithWindow:appDelgObj.window] ;
	[appDelgObj.window addSubview:appDelgObj.HUD];	
	if ( title )
		appDelgObj.HUD.labelText = title;
	if ( subTitle )
		appDelgObj.HUD.detailsLabelText = subTitle;
	[appDelgObj.HUD show:YES];
	//	NSLog(@"Completed showHUD");
}

- (void) showHUDWithTitle : (NSString *) title
{
	[self showHUDTitled:title andSubTitled:nil];
}

- (void) showHUD 
{
	[self showHUDTitled:nil andSubTitled:nil];
}

- (void) killHUD
{
	NSLog(@"Entered killHUD");
	FLOKAppDelegate *appDelgObj = [[UIApplication sharedApplication] delegate];
	if ( appDelgObj.HUD )
	{
		[appDelgObj.HUD hide:YES];
		[appDelgObj.HUD release];
		appDelgObj.HUD = nil;
	}
	NSLog(@"Completed killHUD");
}

@end

//
//  FacebookLoginViewController.m
//  oAuth2Test
//
//  Created by dominic dimarco (ddimarco@room214.com @dominicdimarco) on 5/22/10.
//  Copyright Room 214 2010. All rights reserved.
//

#import "FacebookLoginViewController.h"
#import "SBJSON.h"
#import "FbGraphFile.h"

@implementation FacebookLoginViewController

@synthesize fbGraph;
@synthesize strMessage;

- (void)viewDidLoad {
    [super viewDidLoad];
	/*Facebook Application ID*/
	//	NSString *client_id = @"123145257717248";
	
	//alloc and initalize our FbGraph instance
	self.fbGraph = [[FbGraph alloc] initWithFbClientID:client_id];
	arrFeed = [[[NSMutableArray alloc] init] retain];
//	self.navigationController.navigationBarHidden = YES;
	
	if ( !kFacebookToken || strMessage ) 
	{
		self.tabBarController.tabBar.userInteractionEnabled = NO;
		//begin the authentication process.....
		//	[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) andExtendedPermissions:@"publish_stream,offline_access"];	//	user_photos,user_videos,
		
		/**
		 * OR you may wish to 'anchor' the login UIWebView to a window not at the root of your application...
		 * for example you may wish it to render/display inside a UITabBar view....
		 *
		 * Feel free to try both methods here, simply (un)comment out the appropriate one.....
		 **/
		[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) andExtendedPermissions:@"publish_stream,offline_access" andSuperView:self.view];
	}
	else
	{
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadFeed) userInfo:nil repeats:NO];
	}
}

- (void) loadFeed
{
	[arrFeed addObjectsFromArray: [self getLast5FacebookMessages]];
	[arrFeed retain];
	if ( [arrFeed count] )
	{
		labelPost.hidden = NO;
//		tableFlok.hidden = NO;
		[tableFlok reloadData];
		[self killHUD];
	}
}

- (NSArray *) getLast5FacebookMessages 
{
	fbGraph.accessToken = kFacebookToken;
	NSMutableDictionary *variables = [NSMutableDictionary dictionaryWithCapacity:2];	
	[variables setObject:@"5" forKey:@"limit"];
	[variables setObject:@"message" forKey:@"fields"];
	
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	FbGraphResponse *fb_graph_response = [fbGraph doGraphGet:@"me/feed" withGetVars:variables];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	NSLog(@"\ngetLast5FacebookMessages:  \n*****\n%@\n*****", fb_graph_response.htmlResponse);
	
	//parse our json
	SBJSON *parser = [[SBJSON alloc] init];
	NSDictionary *facebook_response = [parser objectWithString:fb_graph_response.htmlResponse error:nil];	
	[parser release];
	
	NSLog(@"Now log into Facebook and look at your profile...");
	return [facebook_response objectForKey:@"data"];
}

/**
 * DOC:  http://developers.facebook.com/docs/api#selection
 * DOC:  http://developers.facebook.com/docs/reference/api/user
 **/

#pragma mark -
#pragma mark FbGraph Callback Function
/**
 * This function is called by FbGraph after it's finished the authentication process
 **/
- (void)fbGraphCallback:(id)sender {
	
	//pop a message letting them know most of the info will be dumped in the log
	NSLog(@"------------>CONGRATULATIONS<------------, You're logged into Facebook...  Your oAuth token is:  %@", fbGraph.accessToken);
	[[NSUserDefaults standardUserDefaults] setObject:fbGraph.accessToken forKey:@"facebook_accessToken"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	self.tabBarController.tabBar.userInteractionEnabled = YES;
	if ( strMessage )
	{
		NSString *responseId = [self updateOnFacebook:strMessage];
		if ( responseId )
		{
			[self.navigationController popViewControllerAnimated:YES];
		}
	}
	else
	{
		[self showHUD];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(loadFeed) userInfo:nil repeats:NO];
	}
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrFeed count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) 
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}	

    // Set up the cell...
	UILabel *primaryLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 1, 290, 50)];	
	UILabel *secondaryLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 53, 290, 15)];	
	primaryLabel.numberOfLines =3;
	primaryLabel.font =  [UIFont fontWithName:@"Verdana-Bold" size:12];
	secondaryLabel.font = [UIFont fontWithName:@"Verdana-Bold" size:10];
	secondaryLabel.textColor = [UIColor darkGrayColor];

	NSDictionary *dicRecord = [arrFeed objectAtIndex:indexPath.row];
	primaryLabel.text = [NSString stringWithFormat:@"%@", [dicRecord valueForKey:@"message"] ];
	secondaryLabel.text = [[dicRecord valueForKey:@"created_time"] substringToIndex:10 ]; 
	
	[cell.contentView addSubview:primaryLabel];
	[cell.contentView addSubview:secondaryLabel];
	[primaryLabel release];
	[secondaryLabel release];
	
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of FacebookLoginViewController");
	if (strMessage != nil) {
		[strMessage release];
	}
	[fbGraph release];
	[labelPost release];
	[tableFlok release];
	[arrFeed release];
    [super dealloc];
	NSLog(@"Completed dealloc of FacebookLoginViewController");
}

@end

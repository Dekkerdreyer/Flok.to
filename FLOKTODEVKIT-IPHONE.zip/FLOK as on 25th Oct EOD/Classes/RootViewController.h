//
//  RootViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface RootViewController : UIViewController <UITextFieldDelegate>
{
//	UITableView			*tableFlok;
	NSMutableArray		*dataSourceArray;
	UITextField			*txtUser, *txtPwd;	
	NSMutableDictionary	*dicCredentials;
	BOOL				flagStepCompleted;
	IBOutlet UIImageView *imgViewTheme;
}

//@property (nonatomic, retain) IBOutlet UITableView *tableFlok;
@property (nonatomic, retain) NSMutableArray *dataSourceArray;
@property (nonatomic, retain) UITextField *txtUser, *txtPwd;
@property (nonatomic, retain) NSMutableDictionary *dicCredentials;

- (void) loadMailView;

@end

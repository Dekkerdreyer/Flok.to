//
//  Category.h
//  Piuinfo
//
//  Created by Rajesh Tamada on 30/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Category : NSObject 
{
	NSString *name;
	NSArray *arrDtls;
}

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSArray *arrDtls;

+ (id) categoryNamed: (NSString *) catgName withDetails: (NSArray *) catgArr;

@end

//
//  TwitterWebViewController.h
//  Plain2
//
//  Created by Jaanus Kase on 03.05.10.
//  Copyright 2010. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TwitterWebViewController : UIViewController {
    UIViewController *managingVc;
}

@property (nonatomic, retain) UIViewController *managingVc;

@end

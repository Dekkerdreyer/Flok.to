//
//  PersonProfileViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 03/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"

@interface PersonProfileViewController : ChoiceViewController 
{
	IBOutlet UILabel *lblSince, *lblName;
	IBOutlet UIWebView *webViewTags;
	IBOutlet UIImageView *imgViewAvatar;
	int currRequestNum;
	NSDictionary *dicProfileInfo;
	NSString *strTagCsv;
	NSString *strMessageToTweet;
	BOOL flagUpdatedFacebook;
	BOOL flagUpdatedTwitter, flagUpdatedTags;
	IBOutlet UIImageView *imgViewTheme;
}

@property BOOL flagUpdatedFacebook, flagUpdatedTwitter;
@property (nonatomic, retain) NSString *strMessageToTweet;
@property (nonatomic, retain) NSDictionary *dicProfileInfo;
//@property (nonatomic, retain) UIWebView *webViewTags;

- (IBAction) tagBtnAction;
- (void) loadAatar;
- (void) loadTagInfo;
- (void) statusUpdation;

@end

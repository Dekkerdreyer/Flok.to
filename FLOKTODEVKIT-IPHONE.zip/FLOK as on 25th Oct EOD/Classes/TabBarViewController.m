//
//  TabBarViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 04/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "TabBarViewController.h"
#import "AdWhirlView.h"

@implementation TabBarViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
//	tabbarController.view.frame = CGRectMake(0, 0, 320, 460);
//	[self.view addSubview:[tabbarController view]];
	
	
//	[self setView:[tabbarController view]];
	FLOKAppDelegate *appDelgObj = [[UIApplication sharedApplication] delegate];
	[appDelgObj.window addSubview:[tabbarController view]];	

	if ( FREE_VERSION )
	{
		AdWhirlView *awView = [AdWhirlView requestAdWhirlViewWithDelegate:self]; 
		awView.frame = CGRectMake(0, 381, 320, 50);
		[[tabbarController view] addSubview:awView]; 
	}
}

#pragma mark AdWhirl Functions
- (void)adWhirlDidDismissFullScreenModal
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

//// your Publisher ID from Admob.
//- (NSString *)admobPublisherID
//{
//	return kAdMobKey;
//}
//
//// your publisher ID from Google AdSense
//- (NSString *)googleAdSenseClientID
//{
//	return kGAdSenseKey;
//}

- (NSString *)adWhirlApplicationKey
{
	return kAdWhirlAppKey;
}

- (UIViewController *)viewControllerForPresentingModalView
{
	return tabbarController;
}

- (void) removeView
{
	[[tabbarController view] removeFromSuperview];
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void)dealloc 
{
	NSLog(@"Entered dealloc of TabBarViewController");
	[tabbarController release];
   [super dealloc];
	NSLog(@"Completed dealloc of TabBarViewController");
}

@end

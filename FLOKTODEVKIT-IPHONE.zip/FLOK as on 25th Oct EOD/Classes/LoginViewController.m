//
//  LoginViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 28/07/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "RootViewController.h"
#import "AvatarViewController.h"
#import "ProfileQuestionsViewController.h"
#import "TabBarViewController.h"

#import "FLOKAppDelegate.h"
#import "AdWhirlView.h"

@implementation LoginViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	if ( ! TESTING )
	{
		NSString *deviceType = [UIDevice currentDevice].model;
		NSLog(@"device model is '%@'", deviceType);
		if ( [deviceType rangeOfString:@"iPod"].length >0 )
		{
//			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Flok is unable to connect at this time due to poor gps reception. Please try again later." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"We can not determine your GPS location at this time.  Please try again in a few moments." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			alert.tag = 500;
			[alert show];			 
		}
	}
	
	if ( ! (kUser_Theme) )
		[[NSUserDefaults standardUserDefaults] setObject:kDefaultImage forKey:kTheme];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountDeleted)	name:NOTF_AccDeleted object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateMyLocation)	name:NOTF_UpdateLocation object:nil];
	
	//	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	flagFirstTime = NO;
	flagNeedToUpdateLocationAlone = NO;
	currRequestNum = 0;
	
	if ( FREE_VERSION )
	{
		AdWhirlView *awView = [AdWhirlView requestAdWhirlViewWithDelegate:self]; 
		awView.frame = CGRectMake(0, 430, 320, 50);
		[self.navigationController.view addSubview:awView]; 
	}
}

#pragma mark AdWhirl Functions

- (void) adWhirlDidReceiveAd:(AdWhirlView *)adView
{
	/*
	[UIView beginAnimations:@"AdResize" context:nil];
	[UIView setAnimationDuration:0.7];
	CGSize adSize = [adView actualAdSize];
	CGRect newFrame = adView.frame;
	newFrame.size.height = adSize.height; // fit the ad 
	newFrame.size.width = adSize.width; 
	newFrame.origin.x = (self.view.bounds.size.width - adSize.width)/2; 
	adView.frame = newFrame;
	// ... adjust surrounding views here ... 
	[UIView commitAnimations];
	 */
//	[adView setFrame:CGRectMake(0, 430, 320, 50)];
}

- (void)adWhirlDidDismissFullScreenModal
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

//// your Publisher ID from Admob.
//- (NSString *)admobPublisherID
//{
//	return kAdMobKey;
//}
//
//// your publisher ID from Google AdSense
//- (NSString *)googleAdSenseClientID
//{
//	return kGAdSenseKey;
//}

- (NSString *)adWhirlApplicationKey
{
	return kAdWhirlAppKey;
}

- (UIViewController *)viewControllerForPresentingModalView
{
	return [((FLOKAppDelegate *) [[UIApplication sharedApplication] delegate] ) navigationController];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	//	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];	
	[self whereToGo];
} 

- (void) whereToGo
{
//	if ( tabBarViewController )
//	{
//		[tabBarViewController release];
//		tabBarViewController = nil;
//	}
	NSDictionary *dicTemp = [self retrieveCredentials:kLoginFile];
	if ( [dicTemp count] )
	{
		txtUname.text = kUsername;
		txtPwd.text = kPassword;
	}
	else
	{
		txtUname.text = @"";
		txtPwd.text = @"";
	}
}

- (void) continueProfileCreation
{
	RootViewController *rootViewController = [[RootViewController alloc] initWithNibName:@"RootView" bundle:nil];
	rootViewController.dicCredentials = [NSMutableDictionary dictionaryWithDictionary: dicCredentials];
	[rootViewController.dicCredentials retain];
	[self.navigationController pushViewController:rootViewController animated:YES];
	[rootViewController release];
	rootViewController = nil;
}

- (void) continueSelfTagging
{
	ProfileQuestionsViewController *profileQuestionsViewController = [[ProfileQuestionsViewController alloc] initWithNibName:@"ProfileQuestionsView" bundle:nil];
	profileQuestionsViewController.dicCredentials = [NSMutableDictionary dictionaryWithDictionary: dicCredentials];
	[profileQuestionsViewController.dicCredentials retain];
	[self.navigationController pushViewController:profileQuestionsViewController animated:YES];
	[profileQuestionsViewController release];
	profileQuestionsViewController = nil;
}

- (void) continueAvatarUpdation
{
	AvatarViewController *avatarViewController = [[AvatarViewController alloc] initWithNibName:@"AvatarView" bundle:nil];
	avatarViewController.dicCredentials = [NSMutableDictionary dictionaryWithDictionary: dicCredentials];
	[avatarViewController.dicCredentials retain];
	[self.navigationController pushViewController:avatarViewController animated:YES];
	[avatarViewController release];
	avatarViewController = nil;
}

- (void) loadTabbarView
{
	
//	if ( tabBarViewController )
//	{
//		[tabBarViewController release];
//		tabBarViewController = nil;
////		dicCredentials =  [NSDictionary dictionaryWithDictionary: [self retrieveCredentials:kLoginFile]];
////		[dicCredentials retain];
//	}
	
	tabBarViewController = [[[TabBarViewController alloc] initWithNibName:@"TabBarView" bundle:nil] retain];
	//	[self.view addSubview:[tabBarViewController view]];
	//	tabbarController.view.frame = CGRectMake(0, 0, 320, 460);
	[self.navigationController pushViewController:tabBarViewController animated:YES];
//	[tabBarViewController release];
//	tabBarViewController = nil;	
}

- (void) updateMyLocation
{
	NSLog(@"Called startUpdatingLocation");
	[self showHUDWithTitle:@"Updating Location" ];
	if ( TESTING )
	{
		[self fetchJsonData];
	}
	else
	{
		if ( flagNeedToUpdateLocationAlone )
		{
			[locationController release];
			locationController = nil;
		}
		locationController = [[[MyCLController alloc] init] retain];
		locationController.delegate = self;
		[locationController.locationManager setDesiredAccuracy:kCLLocationAccuracyNearestTenMeters];
		timerGPS = [NSTimer scheduledTimerWithTimeInterval:kGPS_Timeout target:self selector:@selector(locationTimeOut) userInfo:nil repeats:NO];
		[timerGPS retain];
		[locationController.locationManager startUpdatingLocation];
	}
}

- (void) fetchJsonData
{
	if ( TESTING )
	{
		//		lat = 22.575812;
		//		lon = 88.364581;
		lat = 22.571235;
		lon = 88.346972;
		
		
		//		lat = 37.331689;
		//		lon = -122.030731;
	}
	NSString *strRequestUrl = nil;
	if ( currRequestNum == 1 )
		strRequestUrl = [NSString stringWithFormat:@"%@user/getuserdetails?username=%@&password=%@"
						 , BASE_FLOK_URL, txtUname.text, txtPwd.text ];
	else if ( currRequestNum == 2 )
		strRequestUrl = [NSString stringWithFormat:@"%@user/updategps?username=%@&password=%@&longitude=%f&latitude=%f"
						 ,  BASE_FLOK_URL, txtUname.text, txtPwd.text, lon, lat ];
	else if ( currRequestNum == 3 )
		strRequestUrl = [NSString stringWithFormat:@"%@user/forgotpassword?username=%@"
						 , BASE_FLOK_URL, txtUname.text];
	NSDictionary *dicResponse = [self getJsonObjectFromUrl:strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
		}
		else if ( [errMsg isEqualToString:@"loginfail"] )
		{
			alert.tag = 30;
			alert.delegate = nil;
		}
		[alert show];
	}
	else
	{
		if ( currRequestNum == 1 )
		{
//			need to reset everything here itself
			
			[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kUname] forKey:kUname];
			[[NSUserDefaults standardUserDefaults] setObject:txtPwd.text forKey:kPwd];
			[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kUID] forKey:kUID];
			[[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%@", [dicResponse valueForKey:kEmail]] forKey:kEmail];
			[[NSUserDefaults standardUserDefaults] setObject:kDefaultImage forKey:kTheme]; 
			[[NSUserDefaults standardUserDefaults] synchronize];
			[self setToDefaults];
			
			
			[self saveCredentials:dicResponse toFile:kLoginFile];
			// Resetting Avatar file
			NSString *strAvatarUrl = [[dicResponse objectForKey:@"avatarflink"] stringByReplacingOccurrencesOfString:@"\\" withString:@""];
			[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
			NSData *imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:strAvatarUrl]];
			[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;	
			if ( ! [imgData bytes] )
			{
				NSString *fileSrc = [[NSBundle mainBundle] pathForResource:@"Avatar" ofType:@"png"];
				imgData = [NSData dataWithContentsOfFile:fileSrc];
			}
			BOOL written = [imgData writeToFile:[self getFullFilePath:kAvatarFile] atomically:YES];
			if (written)
				NSLog(@"Successfully changed avatar,  %@",strAvatarUrl );
			else
				NSLog(@" Failed to change avatar %@", strAvatarUrl);
			
			currRequestNum = 2;
			[self fetchJsonData];
		}
		else if ( currRequestNum == 2 )
		{
			[self killHUD];
			[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kLat] forKey:kLat];
			[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kLong] forKey:kLong];
			[[NSUserDefaults standardUserDefaults] synchronize];
			
			if ( ! flagNeedToUpdateLocationAlone )
			{
				flagNeedToUpdateLocationAlone = YES;
				[self loadTabbarView];
			}
		}
		else if ( currRequestNum == 3 )
		{
			[self killHUD];
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Your password has been mailed to your registered email address" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];
		}
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
	else if ( alertView.tag == 500 )
	{
//		exit(0);
	}
	else if ( alertView.tag == 65 )
	{
		if ( buttonIndex )
		{
			if ( ! [[dicCredentials valueForKey:@"profileStatus"] intValue] )
				[self continueProfileCreation];
			else if ( ! [[dicCredentials valueForKey:@"avatarStatus"] intValue] )
				[self continueAvatarUpdation];
			else if ( ! [[dicCredentials valueForKey:@"tagsStatus"] intValue] )
				[self continueSelfTagging];
		}
		else
		{
			[self newProfileCreation];
		}
	}
}

#pragma mark GPS Fuctions
- (void)locationUpdate:(CLLocation *)location 
{
	NSLog(@"Entered locationUpdate");
	if ( timerGPS && [timerGPS isValid] )
	{
		[timerGPS invalidate];
		timerGPS = nil;
	}
	lat = location.coordinate.latitude;
	lon = location.coordinate.longitude;
	[locationController.locationManager stopUpdatingLocation];
	currRequestNum = 2;
	[self fetchJsonData];
	NSLog(@"Completed locationUpdate");
}

- (void)locationError:(NSError *)error 
{
	NSLog(@"Entered locationError");
	if ( timerGPS && [timerGPS isValid] )
	{
		[timerGPS invalidate];
		timerGPS = nil;
	}
	[self killHUD];
	[locationController.locationManager stopUpdatingLocation];
	NSLog(@"Location error is %@", [error description]);
//	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Flok is unable to connect at this time due to poor gps reception. Please try again later." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"We can not determine your GPS location at this time.  Please try again in a few moments." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	alert.tag = 500;
	[alert show];
	NSLog(@"Exiting locationError");
}


- (void) locationTimeOut
{
	NSLog(@"Entered locationTimeOut");
	timerGPS = nil;	
	[self killHUD];
	[locationController.locationManager stopUpdatingLocation];
//	NSLog(@"Location error is %@", [error description]);
//	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Flok is unable to connect at this time due to poor gps reception. Please try again later." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"We can not determine your GPS location at this time.  Please try again in a few moments." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	alert.tag = 500;
	[alert show];
	NSLog(@"Exiting locationTimeOut");
}

- (void) setToDefaults
{
	// reset twitter and facebook
	if ( kTwitterAuthorized ) 
		[self logoutFromTwitter];
	[[NSUserDefaults standardUserDefaults] removeObjectForKey: @"facebook_accessToken"];
	[[NSUserDefaults standardUserDefaults] setInteger: 0 forKey:@"twitter_oauth_token_authorized"];
	[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"fb_AlertReqd"];
	[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"tw_AlertReqd"];
	[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"fb_UpdtReqd"];
	[[NSUserDefaults standardUserDefaults] setInteger: 1 forKey:@"tw_UpdtReqd"];
	
	[[NSUserDefaults standardUserDefaults] synchronize];	
}

- (void) deleteAccountInformation
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;

	NSString *filePath = nil;	
	filePath = [self getFullFilePath:kProfileCreationFile];
	if ( [[NSFileManager defaultManager] removeItemAtPath:filePath error:NULL] )
		NSLog(@"Successfully deleted  %@", filePath);
	else
		NSLog(@" Failed to delete %@", filePath);
	
	
	filePath = [self getFullFilePath:kLoginFile];
	if ( [[NSFileManager defaultManager] removeItemAtPath:filePath error:NULL] )
		NSLog(@"Successfully deleted  %@", filePath);
	else
	{
		NSLog(@" Failed to delete %@", filePath);
		[[NSDictionary dictionaryWithDictionary:nil] writeToFile:filePath atomically:YES];
	}
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void) accountDeleted
{
	[self setToDefaults];
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUname]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kPwd]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kLat]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kLong]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUID];
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kEmail];
	[[NSUserDefaults standardUserDefaults] setObject:kDefaultImage forKey:kTheme]; 
	[[NSUserDefaults standardUserDefaults] synchronize];	
	[self deleteAccountInformation];
	if ( tabBarViewController )
	{
		[tabBarViewController removeView];
		[tabBarViewController release];
		tabBarViewController = nil;
	}
	[self whereToGo];
	flagNeedToUpdateLocationAlone = NO;
}

- (IBAction) forgotPwdBtnAction
{
	[txtUname resignFirstResponder];
	[txtPwd resignFirstResponder];
	if ( txtUname.text && ![txtUname.text isEqualToString:@""] )
	{
		currRequestNum = 3;
		[self showHUDWithTitle:@"Recovering Password" ];
		[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
	}
	else
		[txtUname becomeFirstResponder];
}


- (IBAction) signInBtnAction
{
	[txtUname resignFirstResponder];
	[txtPwd resignFirstResponder];
	if ( txtUname.text && ![txtUname.text isEqualToString:@""] )
	{
		if ( txtPwd.text && ![txtPwd.text isEqualToString:@""] ) 
		{
			if ( [txtUname.text isEqualToString:kUsername] && [txtPwd.text isEqualToString:kPassword] )
			{
				if ( TESTING )
				{
					currRequestNum = 2;
					[self showHUDWithTitle:@"Updating Location" ];
					[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
				}
				else
				{
					[self updateMyLocation];
				}
			}
			else
			{
				currRequestNum = 1;
				[self showHUDWithTitle:@"Getting User details" ];
				[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
			}
		}
		else
			[txtPwd becomeFirstResponder];
	}
	else
		[txtUname becomeFirstResponder];
}

- (IBAction) signUpBtnAction
{
	[txtUname resignFirstResponder];
	[txtPwd resignFirstResponder];
	dicCredentials =  [NSDictionary dictionaryWithDictionary: [self retrieveCredentials:kProfileCreationFile]] ;
	[dicCredentials retain];
	if ( [dicCredentials count] )
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"A Profile creation is in progress. Would you like to continue with that?" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Create new", @"Yes", nil] ;
		alert.tag = 65;
		[alert show];
		[alert release];
	}
	else
	{
		[self newProfileCreation];
	}
}

- (void) newProfileCreation
{
	dicCredentials = [NSDictionary dictionaryWithObjectsAndKeys: @"", @"username", @"", @"password", @"0", @"loginStatus", @"", @"email", @"0", @"emailStatus", @"", @"dateofbirth", @"0", @"dateStatus", @"", @"media", @"0", @"avatarStatus", @"0", @"profileStatus", @"0", @"tagsStatus", nil] ;
	[dicCredentials retain];	
	[self saveCredentials:dicCredentials toFile:kProfileCreationFile];
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUname]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kPwd]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kLat]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kLong]; 
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUID];
	[[NSUserDefaults standardUserDefaults] removeObjectForKey:kEmail];
	[[NSUserDefaults standardUserDefaults] synchronize];	
	[self continueProfileCreation];
}

- (void) hideLoginTheme
{
	lblUname.hidden = YES;
	lblPwd.hidden = YES;
	txtUname.hidden = YES;
	txtUname.userInteractionEnabled = NO;
	txtPwd.hidden = YES;
	txtPwd.userInteractionEnabled = NO;
	btnSignIn.hidden = YES;
	btnSignIn.userInteractionEnabled = NO;
	btnSignUp.hidden = YES;
	btnSignUp.userInteractionEnabled = NO;
	imgViewRows.hidden = YES;
}

- (void) showLoginTheme
{
	lblUname.hidden = NO;
	lblPwd.hidden = NO;
	txtUname.hidden = NO;
	txtUname.userInteractionEnabled = YES;
	txtPwd.hidden = NO;
	txtPwd.userInteractionEnabled = YES;
	btnSignIn.hidden = NO;
	btnSignIn.userInteractionEnabled = YES;
	btnSignUp.hidden = NO;
	btnSignUp.userInteractionEnabled = YES;
	imgViewRows.hidden = NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of LoginViewController");
	dicCredentials = nil;
	if (tabBarViewController)
		[tabBarViewController release];
	[txtUname release];
	[txtPwd release];
	[btnSignIn release];
	[btnSignUp release];
	[lblUname release];
	[lblPwd release];
	[imgViewRows release];
   	[imgViewTheme release];
 [super dealloc];
	NSLog(@"Completed dealloc of LoginViewController");
}


@end

//
//  RootViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 23/07/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "RootViewController.h"
//#import "LoginViewController.h"
#import "MailidViewController.h"

@implementation RootViewController

@synthesize dataSourceArray;
//@synthesize tableFlok;
@synthesize txtUser, txtPwd;
@synthesize dicCredentials;

- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.navigationController.navigationBarHidden = YES;
	
	/* Device Checking Code
	
	NSString *deviceType = [UIDevice currentDevice].model;
	NSLog(@"deviceType is '%@' ", deviceType);
	if ( [deviceType rangeOfString:@"Simulator"].length >0 )
	{
		if ( TESTING )
		{
		}
		else
		{
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Insufficient Hardware" message:@"This app needs GPS.You are about to quit the app" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			alert.tag = 100;
			[alert show];
		}
	}
	else if ( [deviceType rangeOfString:@"iPod"].length >0 )
	{
		if ( TESTING )
		{
		}
		else
		{
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Insufficient Hardware" message:@"This app needs GPS.You are about to quit the app" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			alert.tag = 100;
			[alert show];
		}
	}
	else if ( [deviceType rangeOfString:@"iPhone"].length >0 )
	{
	}
	
	*/

	flagStepCompleted = NO;
	
	
	if ( [[dicCredentials objectForKey:@"loginStatus"] intValue] )
	{
//		flagStepCompleted = YES;
		if ( [[dicCredentials objectForKey:@"profileStatus"] intValue] )
			[self.navigationController popToRootViewControllerAnimated:YES];
//			[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(loadLoginView) userInfo:nil repeats:NO];
		else
			[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(loadMailView) userInfo:nil repeats:NO];

	}
	else
	{
		flagStepCompleted = NO;
	}
	if ( !flagStepCompleted )
	{
		self.dataSourceArray = [NSMutableArray arrayWithObjects:
								
								[NSMutableDictionary dictionaryWithObjectsAndKeys:
								 @"What would you like your Username and Password to be?", kSectionTitleKey,
								 @"Username", kLabelKey,
								 //							 @"", kSourceKey,
								 self.txtUser, kViewKey,
								 nil],
								
								[NSMutableDictionary dictionaryWithObjectsAndKeys:
								 //							 @"", kSectionTitleKey,
								 @"Password", kLabelKey,
								 //							 @"", kSourceKey,
								 self.txtPwd, kViewKey,
								 nil],
								
								[NSMutableDictionary dictionaryWithObjectsAndKeys:
								 @"Check Availability", kSectionTitleKey,
								 @"Submit", kLabelKey,
								 //							 @"", kSourceKey,
								 //							 nil, kViewKey,
								 nil],
								
								nil];
	}
}



 - (void)viewWillAppear:(BOOL)animated {
 [super viewWillAppear:animated];
 }


 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

- (void) loadMailView
{
	MailidViewController *mailidViewController = [[MailidViewController alloc] initWithNibName:@"MailidView" bundle:nil];
	mailidViewController.dicCredentials = dicCredentials;
	[mailidViewController.dicCredentials retain];
	mailidViewController.flagUpdatingProfile = NO;
	[self.navigationController pushViewController:mailidViewController animated:YES];
	[mailidViewController release];
	mailidViewController = nil;
}

//- (void) loadLoginView
//{
//	LoginViewController *loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginView" bundle:nil];
//	[self.navigationController pushViewController:loginViewController animated:YES];
//	[loginViewController release];
//	loginViewController = nil;
//}

- (void) submitAction
{
	NSString *strUrl = [NSString stringWithFormat:@"%@user/validateusername?username=%@", BASE_FLOK_URL, txtUser.text];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSString *response = [NSString stringWithContentsOfURL:[NSURL URLWithString:[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] encoding:NSUTF8StringEncoding error:nil];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	[self killHUD];
	if ( [response rangeOfString:@"alreadyexist"].length > 0 )
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Username already exists!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
		alert.tag = 20;
		[alert show];
	}
	else if ( [response rangeOfString:@"successmsg"].length > 0 )
	{
		[dicCredentials setValue:txtUser.text forKey:@"username"];
		[dicCredentials setValue:txtPwd.text forKey:@"password"];
		[dicCredentials setValue:@"1" forKey:@"loginStatus"];
		[dicCredentials retain];
		[self saveCredentials:[NSDictionary dictionaryWithDictionary:dicCredentials] toFile:kProfileCreationFile];
		[self loadMailView];
//		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Alert" message:@"User ID is available" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
//		alert.tag = 10;
//		[alert show];
	}
	else
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Alert" message:@"Network connection error" delegate:self cancelButtonTitle:@"Retry" otherButtonTitles:@"Quit the App", nil] autorelease];
		alert.tag = 50;
		[alert show];
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
		exit(0);
	else if ( alertView.tag == 50 )
	{
		if (buttonIndex)
			exit(0);
	}
	else if ( alertView.tag == 20 )
	{
		[txtUser becomeFirstResponder];
	}
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release anything that can be recreated in viewDidLoad or on demand.
	// e.g. self.myOutlet = nil;
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	if ( flagStepCompleted )
		return 0;
	else
		return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	if ( flagStepCompleted )
		return 0;
	else
	{
		if (section)
			return 1;
		else
			return 2;
	}
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if ( flagStepCompleted )
		return nil;
	else
	{
		if ( section )
			return [[self.dataSourceArray objectAtIndex: 2] valueForKey:kSectionTitleKey];
		else
			return [[self.dataSourceArray objectAtIndex: 0] valueForKey:kSectionTitleKey];
	}
}



// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	UITableViewCell *cell = nil;
	
	if ( ! indexPath.section  )
	{
		static NSString *kDisplayCell_ID = @"DisplayCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:kDisplayCell_ID];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kDisplayCell_ID] autorelease];
			cell.selectionStyle = UITableViewCellSelectionStyleNone;
		}
		else
		{
			// the cell is being recycled, remove old embedded controls
			UIView *viewToRemove = nil;
			viewToRemove = [cell.contentView viewWithTag: 1+indexPath.row];
			if (viewToRemove)
				[viewToRemove removeFromSuperview];
		}
		
		cell.textLabel.text = [[self.dataSourceArray objectAtIndex: indexPath.row] valueForKey:kLabelKey];
		
		UIControl *control = [[self.dataSourceArray objectAtIndex: indexPath.row] valueForKey:kViewKey];
		[cell.contentView addSubview:control];
	}
	else
	{
		static NSString *kSourceCellID = @"SourceCellID";
		cell = [tableView dequeueReusableCellWithIdentifier:kSourceCellID];
		if (cell == nil)
		{
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kSourceCellID] autorelease];
			
			cell.textLabel.opaque = NO;
			cell.textLabel.textAlignment = UITextAlignmentCenter;
			//			cell.textLabel.textColor = [UIColor blackColor];
			//			cell.textLabel.font = [UIFont systemFontOfSize:13];	
		}
		
		cell.textLabel.text = [[self.dataSourceArray objectAtIndex: 2] valueForKey:kLabelKey];
	}
	//	cell.backgroundColor = [UIColor clearColor];
	return cell;
}




// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	if ( indexPath.section )
	{
		if ( txtUser.text && ![txtUser.text isEqualToString:@""] )
		{
			[txtUser resignFirstResponder];
			if ( txtPwd.text && ![txtPwd.text isEqualToString:@""] )
			{
				[txtPwd resignFirstResponder];
				[self showHUD];
				[NSTimer scheduledTimerWithTimeInterval: 0.1 target:self selector:@selector(submitAction) userInfo:nil repeats:NO];
			}
			else
				[txtPwd becomeFirstResponder];
		}
		else
			[txtUser becomeFirstResponder];
	}
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}


#pragma mark Lazy creation of controls

- (UITextField *) txtUser
{
	if (txtUser == nil)
	{
		txtUser = [[UITextField alloc] initWithFrame: CGRectMake( 125, 9, 150, 31.0)];
		txtUser.tag = 5;
		txtUser.delegate = self;
		txtUser.placeholder = @"Mandatory Field";
		txtUser.borderStyle = UITextBorderStyleRoundedRect;
		txtUser.autocapitalizationType = UITextAutocapitalizationTypeNone;
		txtUser.clearButtonMode = UITextFieldViewModeWhileEditing;
	}
	return txtUser;
}

- (UITextField *) txtPwd
{
	if (txtPwd == nil)
	{
		txtPwd = [[UITextField alloc] initWithFrame: CGRectMake( 125, 9, 150, 31.0)];
		txtPwd.tag = 6;
		txtPwd.delegate = self;
		txtPwd.placeholder = @"Mandatory Field";
		txtPwd.secureTextEntry = YES;
		txtPwd.borderStyle = UITextBorderStyleRoundedRect;
		txtPwd.clearsOnBeginEditing = YES;
		txtPwd.clearButtonMode = UITextFieldViewModeWhileEditing;
	}
	return txtPwd;
}

- (void)dealloc {
	NSLog(@"Entered dealloc of RootViewController");
	[txtPwd release];
	[txtUser release];
	[dataSourceArray release];
	dicCredentials = nil;
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of RootViewController");
}


@end


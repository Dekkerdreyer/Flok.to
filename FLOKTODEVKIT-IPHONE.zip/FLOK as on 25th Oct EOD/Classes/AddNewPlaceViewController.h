//
//  AddNewPlaceViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 07/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChoiceViewController.h"
#import "SelectionViewController.h"

@interface AddNewPlaceViewController : ChoiceViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
{
//	IBOutlet UIImageView *imgViewTheme;
	UITextField *txtName, *txtAddress1, *txtAddress2, *txtAddress3, *txtCity, *txtState, *txtCountry, *txtWebsite;
	IBOutlet UITableView *tableFlok;
	NSMutableArray *dataSourceArray, *arrPlaceTypes, *arrPlaceTags;
	NSString *strPlaceTypeId, *strParameters, *strTagCsv, *strPlaceId;//*userName, *passWord, 
	BOOL flagPlaceTypes;
	int currRequestNum;
	NSMutableDictionary *dicPlaceDetails;
	NSString *strMessageToTweet;
	NSArray *arrFieldParams; 
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) UITextField *txtName, *txtAddress1, *txtAddress2, *txtAddress3, *txtCity, *txtState, *txtCountry, *txtWebsite;
@property (nonatomic, retain) NSMutableArray *dataSourceArray;
@property (nonatomic, retain) NSArray *arrFieldParams;
//@property (nonatomic, retain) NSString *userName, *passWord;

- (void) setTextField : (UITextField *) currTextField;

@end

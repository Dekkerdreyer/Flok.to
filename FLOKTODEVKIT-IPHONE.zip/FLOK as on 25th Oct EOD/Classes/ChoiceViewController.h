//
//  ChoiceViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 05/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChoiceViewController : UIViewController 
{
	NSMutableArray *arrSelectedItems;
	BOOL flagSelectionDone;
}

@property (nonatomic, retain) NSMutableArray *arrSelectedItems;
@property (nonatomic) BOOL flagSelectionDone;

@end

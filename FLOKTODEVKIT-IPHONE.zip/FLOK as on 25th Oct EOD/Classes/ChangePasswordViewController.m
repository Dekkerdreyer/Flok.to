//
//  ChangePasswordViewController.m
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ChangePasswordViewController.h"


@implementation ChangePasswordViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
//	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
//	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kUser_Theme]]];
	imgViewTheme.image = [UIImage imageNamed:kUser_Theme];
	txtOld.text = kPassword;
}


- (IBAction) submitBtnAction
{
	if ( [txtOld.text isEqualToString:kPassword] ) 
	{
		if ( txtNew.text && txtConfirm.text && ![txtNew.text isEqualToString:@""] )
		{
			if ( [txtNew.text isEqualToString:txtConfirm.text] )
			{
				[txtNew resignFirstResponder];
				[txtOld resignFirstResponder];
				[txtConfirm resignFirstResponder];
				[self showHUDWithTitle:@"Changing Password"];
				[NSTimer scheduledTimerWithTimeInterval: 0.2 target:self selector:@selector(fetchJsonData) userInfo:nil repeats:NO];
			}
			else 
			{
				UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Please verify new password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
				[alert show];
			}
 		}
		else 
		{
			UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Please verify new password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
			[alert show];
		}
	}
	else 
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"" message:@"Please verify Old password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
		[alert show];
	}
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

- (void) fetchJsonData
{
	NSDictionary *dicResponse = nil;
	strRequestUrl = [NSString stringWithFormat:@"%@user/changepassword?username=%@&oldpassword=%@&newpassword=%@"
					 , SESSION_URL, txtNew.text ]; 
	[strRequestUrl retain];
	dicResponse = (NSDictionary *) [self getJsonObjectFromUrl: strRequestUrl];
	NSString *errMsg = [dicResponse objectForKey:@"errmsg"];
	if ( errMsg )
	{
		[self killHUD];
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:[dicResponse objectForKey:@"errmsg"] message:[dicResponse objectForKey:@"errdesc"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease]; 
		if ( [errMsg isEqualToString:@"Network Error"] )
		{
			alert.tag = 100;
			[alert show];
		}
		else if ( [errMsg isEqualToString:@"loginfail" ] )
		{
			alert.tag = 50;
			[alert show];
		}
	}
	else
	{
		[[NSUserDefaults standardUserDefaults] setObject:[dicResponse valueForKey:kPwd] forKey:kPwd];
		[[NSUserDefaults standardUserDefaults] synchronize];
		[self killHUD];
		[self.navigationController popViewControllerAnimated:YES];
//		[[NSNotificationCenter defaultCenter] postNotificationName:NOTF_PwdChanged object:nil];
	}
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if ( alertView.tag == 100 )
	{
		exit(0);
	}
	else if ( alertView.tag == 50 )
	{
		exit(0);
	}
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	MyDeviceRotation
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	MyMemoryWarning
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	NSLog(@"Entered dealloc of ChangePasswordViewController");
	[txtOld release];
	[txtNew release];
	[txtConfirm release];
	[strRequestUrl release];
	[imgViewTheme release];
    [super dealloc];
	NSLog(@"Completed dealloc of ChangePasswordViewController");
}


@end

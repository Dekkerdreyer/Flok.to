//
//  MatchingPlacesViewController.h
//  FLOK
//
//  Created by Rajesh Tamada on 19/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MatchingPlacesViewController : UIViewController 
{
	NSArray *arrFieldParams, *arrTableData;
//	IBOutlet UIImageView *imgViewTheme;
	IBOutlet UITableView *tableFlok;
	IBOutlet UIImageView *imgViewTheme;
}

@property (nonatomic, retain) NSArray *arrFieldParams, *arrTableData;

@end

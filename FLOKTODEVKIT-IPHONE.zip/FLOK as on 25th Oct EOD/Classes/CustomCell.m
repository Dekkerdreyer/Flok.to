//
//  CustomCell.m
//  
//
//  Created by Rajesh Tamada on 29/01/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell


@synthesize imgView;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) 
	{
		if ( [reuseIdentifier isEqualToString:@"Avatar Image Cell"]) 
		{
			imgView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 2, 100, 100)];
			[self.contentView addSubview:imgView];
			[imgView release];
			self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//			self.selectionStyle = UITableViewCellSelectionStyleGray;
		}
		else if ( [reuseIdentifier isEqualToString:@"BG Image Cell"]) 
		{	// Initialization code
			imgView = [[UIImageView alloc] initWithFrame:CGRectMake(60, 2, 175, 175)];
			[self.contentView addSubview:imgView];
			[imgView release];
			self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//			self.selectionStyle = UITableViewCellSelectionStyleGray;
		}
	}
    return self;
}

@end

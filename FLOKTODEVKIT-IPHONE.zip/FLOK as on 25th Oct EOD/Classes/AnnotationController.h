//
//  AnnotationController.h
//  FLOK
//
//  Created by Rajesh Tamada on 02/08/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

typedef enum {
	AnnUser = 0,	/* User Location*/
	AnnBlue,		/* 1 - 5 */
	AnnGreen,		/* 6 - 10 */
	AnnYellow,		/* 11 - 20 */
	AnnOrange,		/* 21 - 50 */
	AnnRed		/* 51+ */
} AnnotationStyle;

@interface AnnotationController : NSObject <MKAnnotation>
{
	CLLocationCoordinate2D coordinate;
	
	NSString *annTitle;
	NSString *annSubTitle;
	NSString *annImage;
	AnnotationStyle annType;
	int annTag;
}

@property (nonatomic, retain, readwrite) NSString *annTitle, *annImage ;
@property (nonatomic, retain, readwrite) NSString *annSubTitle;
@property (nonatomic, readwrite) int annTag;
@property (nonatomic, readwrite) AnnotationStyle annType;

//@property ( nonatomic, readonly) CLLocationCoordinate2D coordinate;

-(id)initWithCoordinate: (CLLocationCoordinate2D) point;
- (NSString *) subtitle;
- (NSString *) imgurl;
- (NSString *) title;
- (int) tag;
- (AnnotationStyle) type;

@end

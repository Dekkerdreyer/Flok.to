//
//  FacebookLoginViewController.h
//  oAuth2Test
//
//  Created by dominic dimarco (ddimarco@room214.com @dominicdimarco) on 5/22/10.
//  Copyright Room 214 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FbGraph.h"

@interface FacebookLoginViewController : UIViewController <UIWebViewDelegate> 
{
	FbGraph *fbGraph;
	NSString *strMessage;
	IBOutlet UILabel *labelPost;
	IBOutlet UITableView *tableFlok;
	NSMutableArray *arrFeed;
}

@property (nonatomic, retain) FbGraph *fbGraph;
@property (nonatomic, retain) NSString *strMessage;

- (void) loadFeed;
- (NSArray *) getLast5FacebookMessages;

@end


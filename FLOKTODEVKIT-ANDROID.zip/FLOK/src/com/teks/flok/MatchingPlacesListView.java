package com.teks.flok;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class MatchingPlacesListView extends Activity implements
		OnItemClickListener {

	String[][] arrPlaceDetails = null;
	String[] arrPlaceName = null;
	TextView txtTotalPlaces = null;
	ListView placeList = null;
	ArrayAdapter<String> placeAdapter = null;
	LinearLayout viewLast = null;
	LinearLayout current = null;
	LinearLayout background = null;
	LinearLayout adWhirlPlaceListView = null;
	GlobalValues globalObj = null;
	String backgroundImage = "", errDesc = "";
	Context myApp = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_list_view);

		myApp = SearchGroup.myContext;
		globalObj = GlobalValues.getInstance();
		adWhirlPlaceListView = (LinearLayout) findViewById(R.id.adWhirlPlaceListView); 
		txtTotalPlaces = (TextView) findViewById(R.id.txtTotalPlaces);
		placeList = (ListView) findViewById(R.id.placeList);
		background = (LinearLayout) findViewById(R.id.placeListViewBackground);
		placeList.setOnItemClickListener(this);

		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceListView.invalidate();
		}
		else{
			adWhirlPlaceListView.setVisibility(View.GONE);
		}
		
		
		parsePlaceJSONData();

		if (arrPlaceDetails != null) {
			txtTotalPlaces.setText("Number of matches: "+ arrPlaceDetails.length);
			placeAdapter = new myAdapter(this, arrPlaceName);
			placeList.setAdapter(placeAdapter);
		} else {
			new AlertDialog.Builder(myApp).setMessage(errDesc)
					.setPositiveButton(android.R.string.ok,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {
									SearchGroup.group.back();
								}
							}).setCancelable(false).create().show();
		}

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.row_view, objects);

		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.row_view, null);
			}
			TextView txtFilter = (TextView) v
					.findViewById(R.id.txtListViewPlaceName);
			txtFilter.setText(arrPlaceDetails[position][1]);
			return v;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (viewLast != null) {
			viewLast.setBackgroundColor(Color.WHITE);
			TextView place = (TextView) viewLast
					.findViewById(R.id.txtListViewPlaceName);
			place.setBackgroundColor(Color.WHITE);
			place.setTextColor(Color.parseColor("#000000"));
			viewLast.refreshDrawableState();
		}
		int c = Color.parseColor("#0275ee");
		arg1.setBackgroundColor(c);
		TextView currentplace = (TextView) arg1
				.findViewById(R.id.txtListViewPlaceName);
		currentplace.setBackgroundColor(c);
		currentplace.setTextColor(Color.WHITE);
		arg1.refreshDrawableState();
		viewLast = (LinearLayout) arg1;
		current = (LinearLayout) arg1;
		System.out.println("Place id is " + arrPlaceDetails[arg2][0]);

		Intent intentPlaceProfile = new Intent(MatchingPlacesListView.this,	PlaceProfile.class);
		intentPlaceProfile.putExtra("com.teks.flok.placeID", arrPlaceDetails[arg2][0]);
		startActivity(intentPlaceProfile);

	}

	public void parsePlaceJSONData() {
		try {
			if (!globalObj.jsonResult.equals("") && !globalObj.jsonResult.contains("errmsg")) {
				globalObj.job = new JSONObject(globalObj.jsonResult);
				globalObj.ja = globalObj.job.getJSONArray("jsonResult");
				arrPlaceDetails = new String[globalObj.ja.length()][2];
				arrPlaceName = new String[globalObj.ja.length()];
				for (int i = 0; i < globalObj.ja.length(); i++) {
					arrPlaceDetails[i][0] = globalObj.ja.getJSONObject(i).getString("placeid").toString();
					arrPlaceDetails[i][1] = globalObj.ja.getJSONObject(i).getString("placename").toString();
					arrPlaceName[i] = globalObj.ja.getJSONObject(i).getString(
							"placename").toString();
				}
				globalObj.jsonResult = null;
				globalObj.job = null;
				globalObj.ja = null;
			} else if (!globalObj.jsonResult.equals("") && globalObj.jsonResult.contains("errmsg")) {
				globalObj.job = new JSONObject(globalObj.jsonResult);
				errDesc = globalObj.job.getString("errdesc").toString();
				globalObj.job = null;
				globalObj.jsonResult = null;
			}
		} catch (Exception e) {
		}
	}
}

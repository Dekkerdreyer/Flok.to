package com.teks.flok;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;

public class Login extends Activity implements OnClickListener, LocationListener {

	EditText txtUserName = null;
	EditText txtPassword = null;
	TextView txtForgotPassword = null;
	Button btnLogin = null;
	Button btnSignUp = null;
	final Context myApp = this;
	public ProgressDialog progDialog = null;
	String userName = "", password = "";
	boolean retry = true;
	private LocationManager locationManager = null;
	Intent intent = null;
	String oldUserName = "";
	boolean gpsFlag = false;
	GlobalValues globalObj = null;
	LinearLayout adWhirlLayoutLogin = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login);

		globalObj = GlobalValues.getInstance(); // creates singleton object
		txtUserName = (EditText) findViewById(R.id.login_username);
		txtPassword = (EditText) findViewById(R.id.login_password);
		txtForgotPassword = (TextView) findViewById(R.id.txtForgotPassword);
		txtForgotPassword.setOnClickListener(this);

		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnLogin.setOnClickListener(this);

		btnSignUp = (Button) findViewById(R.id.btnSignUp);
		btnSignUp.setOnClickListener(this);
		adWhirlLayoutLogin = (LinearLayout) findViewById(R.id.adWhirlLogin); 
		SpannableString content = new SpannableString("Forgot password?");
		content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
		txtForgotPassword.setText(content);

		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || !isConnected()) {
			new AlertDialog.Builder(myApp)
			.setTitle("Error!")
			.setIcon(R.drawable.error)
			.setMessage("Flok is unable to connect at this time due to poor gps reception. Please try again later.")
			.setPositiveButton(android.R.string.ok,	new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					Login.this.finish();
				}
			})
			.setCancelable(false)
			.create()
			.show();
			return;
		}

		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlLayoutLogin.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlLayoutLogin.invalidate();
		}
		else{
			adWhirlLayoutLogin.setVisibility(View.GONE);
		}

		/*
		 * If application is running in test mode then no need to start the GPS
		 * Service
		 */

		if (!globalObj.testFlag)
			startLocationServices(); // start GPS service

		readUserInfo();
		WriteAvtarFiles(); // copy the generic avatar files if not exist in data
							// folder
		oldUserName = userName;
		if (!userName.equals("NA") && !password.equals("NA")) {
			txtUserName.setText(userName);
			txtPassword.setText(password);
			globalObj.loggedInUserName = userName;
			globalObj.loggedInUserPassword = password;
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnLogin) {
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtPassword.getWindowToken(), 0);
			if (!txtUserName.getText().toString().equals("") && !txtPassword.getText().toString().equals("")) {
				userName = txtUserName.getText().toString();
				password = txtPassword.getText().toString();
				if (globalObj.testFlag) {
					stopLocationServices();
					Intent intentTestGPSProvider = new Intent(Login.this, TestGPSProvider.class);
					intentTestGPSProvider.putExtra("com.teks.flok.calledFrom", "Login");
					startActivityForResult(intentTestGPSProvider, 200);
				} else {
					loginProgress();
				}

			} else if (txtUserName.getText().toString().equals("")) {
				new AlertDialog.Builder(myApp).setMessage("Please enter username.").setPositiveButton(android.R.string.ok, null).setCancelable(false).create().show();
				txtUserName.requestFocus();
				return;
			} else if (txtPassword.getText().toString().equals("")) {
				new AlertDialog.Builder(myApp).setMessage("Please enter password.").setPositiveButton(android.R.string.ok, null).setCancelable(false).create().show();
				txtPassword.requestFocus();
				return;
			}
		} else if (v.getId() == R.id.btnSignUp) {
			if (checkProfileStatus() == 1 || checkProfileStatus() == 0) {
				deleteAccount();
				Intent intentNewProfile = new Intent(Login.this, Main.class);
				startActivity(intentNewProfile);
				Login.this.finish();
			} else {
				AlertDialog.Builder alertbox = new AlertDialog.Builder(myApp);
				alertbox.setInverseBackgroundForced(true);
				alertbox.setMessage("A Profile creation is in progress. Would you like to continue with that?");
				alertbox.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								startActivity(intent);
								Login.this.finish();
							}
						});
				alertbox.setNegativeButton("Create New", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								deleteAccount();
								Intent intentNewProfile = new Intent(
										Login.this, Main.class);
								startActivity(intentNewProfile);
								Login.this.finish();
							}
						});
				alertbox.show();
			}
		} else if (v.getId() == R.id.txtForgotPassword) {
			Intent intentPasswordrecivery = new Intent(Login.this, ForgotPassword.class);
			startActivity(intentPasswordrecivery);
		}
	}

	public void readUserInfo() {
		SharedPreferences userPreferences = getSharedPreferences("LoginInfo", MODE_PRIVATE);
		userName = userPreferences.getString("UserName", "NA");
		password = userPreferences.getString("Password", "NA");
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 200) {
			if (data != null) {
				Bundle received = data.getExtras();
				String lng = received.getString("com.teks.flok.longitude");
				String lat = received.getString("com.teks.flok.latitude");
				if (lng.length() > 0 && lat.length() > 0) {
					globalObj.longitude = Double.parseDouble(lng);
					globalObj.latitude = Double.parseDouble(lat);
					gpsFlag = true;
					loginProgress();
				}
			}
		}

	}

	public boolean isConnected() {
		ConnectivityManager connManager = (ConnectivityManager) getSystemService(Login.CONNECTIVITY_SERVICE);
		if (connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable() || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) {
			return true;
		} else {
			return false;
		}
	}

	public void loginProgress() {
		progDialog = ProgressDialog.show(this, "Please wait...", "Retrieving GPS location.", true, true);
		new Thread() {
			public void run() {
				try {
					while (!gpsFlag) {

					}
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.userLogin(userName, password, ""+ globalObj.longitude, "" + globalObj.latitude);
				} catch (Exception e) {
					e.printStackTrace();
				}
				loginHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler loginHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("userid")) {
				if (!oldUserName.equals(userName)) {
					deleteAccount();
				}
				SharedPreferences userPreferences = getSharedPreferences("LoginInfo", MODE_PRIVATE);
				SharedPreferences.Editor editor = userPreferences.edit();
				editor.putString("UserName", userName);
				editor.putString("Password", password);
				globalObj.loggedInUserName = userName;
				globalObj.loggedInUserPassword = password;
				editor.commit();
				globalObj.jsonResult = null;
				
				Intent tabIntent = new Intent(Login.this, Host.class);
				startActivity(tabIntent);
				Login.this.finish();
			} else {
				new AlertDialog.Builder(myApp)
				.setTitle("Error!").setMessage("Username or password is incorrect.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		}
	};

	private void startLocationServices() {
		Log.d("GPS", "Location Services Started");
		locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, this);
	}

	private void stopLocationServices() {
		Log.d("GPS", "Location Services Stopped");
		if (locationManager != null) {
			locationManager.removeUpdates(this);
		}
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		if (location != null) {
			globalObj.longitude = location.getLongitude();
			globalObj.latitude = location.getLatitude();
			gpsFlag = true;
		}
		Log.d("GPS", location.toString());
		System.out.println("Longitude and Latitude from onLocation changed "+ globalObj.longitude + " " + globalObj.latitude);
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		stopLocationServices();
		super.onDestroy();
	}

	// ======================= Code to show alert dialog when GPS is not
	// available ===================
	// ======================= It lets the user to enable the GPS too
	// =======================================

	// private void createGpsDisabledAlert(){
	// AlertDialog.Builder builder = new AlertDialog.Builder(this);
	// builder.setMessage("Your GPS is disabled! Would you like to enable it?")
	// .setCancelable(false)
	// .setPositiveButton("Enable GPS",
	// new DialogInterface.OnClickListener(){
	// public void onClick(DialogInterface dialog, int id){
	// showGpsOptions();
	// }
	// });
	// builder.setNegativeButton("Do nothing",
	// new DialogInterface.OnClickListener(){
	// public void onClick(DialogInterface dialog, int id){
	// dialog.cancel();
	// }
	// });
	// AlertDialog alert = builder.create();
	// alert.show();
	// }
	//
	// private void showGpsOptions(){
	// Intent gpsOptionsIntent = new
	// Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	// startActivity(gpsOptionsIntent);
	// }

	// =======================================================================================================

	public void deleteAccount() {
		SharedPreferences preferencesFile = getSharedPreferences(
				"UserPassword", MODE_PRIVATE);
		SharedPreferences.Editor editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("EmailAddress", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("Questions", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("Avtar", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("AvtarFileStatus", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("LoginInfo", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("TwitterInfo", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("facebook-session", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.clear();
		editor.commit();

		preferencesFile = getSharedPreferences("Settings", MODE_PRIVATE);
		editor = preferencesFile.edit();
		editor.putString("BackgroundImage", "drawable/background");
		editor.commit();

	}

	public int checkProfileStatus() {

		SharedPreferences editor = getSharedPreferences("UserPassword",
				MODE_PRIVATE);
		String status = editor.getString("status", "Incomplete");
		boolean flag = false, statusFlag = false;
		;
		int step = 0;

		if (status.equals("Incomplete")) {
			intent = new Intent(Login.this, UserPassword.class);
			flag = true;
			statusFlag = true;
			step = 1;
			System.out.println("UserPassword status is " + statusFlag);
		}

		if (!flag) {
			editor = getSharedPreferences("EmailAddress", MODE_PRIVATE);
			status = editor.getString("status", "Incomplete");
			if (status.equals("Incomplete")) {
				intent = new Intent(Login.this, EmailAddress.class);
				flag = true;
				statusFlag = true;
				step = 2;
				System.out.println("EmailAddress status is " + statusFlag);
			}
		}

		if (!flag) {
			editor = getSharedPreferences("Questions", MODE_PRIVATE);
			status = editor.getString("status", "Incomplete");
			if (status.equals("Incomplete")) {
				intent = new Intent(Login.this, QuestionAnswer.class);
				flag = true;
				statusFlag = true;
				step = 3;
				System.out.println("Question status is " + statusFlag);
			}
		}

		if (!flag) {
			editor = getSharedPreferences("Avtar", MODE_PRIVATE);
			status = editor.getString("status", "Incomplete");
			if (status.equals("Incomplete")) {
				intent = new Intent(Login.this, Avtar.class);
				flag = true;
				statusFlag = true;
				step = 4;
				System.out.println("Avatart status is " + statusFlag);
			}
		}
		System.out.println("Value of step is " + step);
		return step;
	}

	public void WriteAvtarFiles() {
		SharedPreferences userPreferences = getSharedPreferences(
				"AvtarFileStatus", MODE_PRIVATE);
		int flag = userPreferences.getInt("Flag", 0);
		AssetManager mgr = getAssets();
		if (flag == 0) {
			try {
				for (int i = 1; i <= 10; i++) {

					FileOutputStream fist = openFileOutput("avatar" + i
							+ ".png", Context.MODE_PRIVATE);

					System.out.println("Avtar files are being created");
					File f = new File("/data/data/com.teks.flok/avatar" + i
							+ ".png");
					InputStream inputStream = mgr.open("avtars/avatar" + i
							+ ".png");
					OutputStream out = new FileOutputStream(f);
					byte buf[] = new byte[1024];
					int len;
					while ((len = inputStream.read(buf)) > 0) {
						out.write(buf, 0, len);
						fist.write(buf, 0, len);
					}
					fist.close();
					out.close();
					inputStream.close();
				}
				SharedPreferences.Editor editor = userPreferences.edit();
				editor.putInt("Flag", 1);
				editor.commit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} // flag if closes
	}
}

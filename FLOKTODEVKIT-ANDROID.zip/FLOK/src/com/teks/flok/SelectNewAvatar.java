package com.teks.flok;

import java.io.File;
import java.io.FileInputStream;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

public class SelectNewAvatar extends Activity implements OnClickListener {

	Button btnSelectFromGeneric = null;
	Button btnSelectFromLib = null;
	Button btnDone = null;
	ImageView imgNewAvatar = null;
	String avatarName = "";
	boolean flag = false;
	public ProgressDialog progDialog = null;
	LinearLayout adWhirlSelectNewAvatar = null;
	public Context myApp = this;
	ScrollView layoutBackground = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.select_new_avatar);

		globalObj = GlobalValues.getInstance();
		adWhirlSelectNewAvatar = (LinearLayout) findViewById(R.id.adWhirlSelectNewAvatar);
		btnSelectFromGeneric = (Button) findViewById(R.id.btnSelectNewAvtarGeneric);
		btnSelectFromLib = (Button) findViewById(R.id.btnSelectNewAvatarUser);
		btnDone = (Button) findViewById(R.id.btnSelectNewAvtarDone);

		imgNewAvatar = (ImageView) findViewById(R.id.selectNewAvatar);

		btnSelectFromGeneric.setOnClickListener(this);
		btnSelectFromLib.setOnClickListener(this);
		btnDone.setOnClickListener(this);
		imgNewAvatar.setBackgroundDrawable(globalObj.avatar);

		layoutBackground = (ScrollView) findViewById(R.id.selectNewAvatarBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			layoutBackground.setBackgroundResource(imageResource);
		}
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlSelectNewAvatar.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlSelectNewAvatar.invalidate();
		}
		else{
			adWhirlSelectNewAvatar.setVisibility(View.GONE);
		}
		
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences(
				"Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnSelectNewAvtarGeneric) {
			Intent genericAvtarIntent = new Intent(this,
					GenericAvtarGallery.class);
			startActivityForResult(genericAvtarIntent, 10);
		} else if (v.getId() == R.id.btnSelectNewAvatarUser) {
			// Intent userAvtarIntent=new Intent(this,AvtarsFromSDCard.class);
			// startActivityForResult(userAvtarIntent, 4);
			// startActivityForResult(new Intent(Intent.ACTION_PICK,
			// android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI),
			// 3);
			startActivityForResult(
					new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 4);
		} else if (v.getId() == R.id.btnSelectNewAvtarDone) {
			if (flag) {
				updateNewAvatar();
			} else {
				new AlertDialog.Builder(this)
				.setMessage("Sorry, you didn't select a new avatar. Please select one.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(true)
				.create()
				.show();
				return;
			}
		}
	}


	public void updateNewAvatar() {
		progDialog = ProgressDialog.show(this, "Info",
				"Uploading new avatar. Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.uploadNewAvatar(globalObj.loggedInUserName, globalObj.loggedInUserPassword, avatarName);
					System.out.println("Update result is " + globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				avatarHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler avatarHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("userid")) {
				Intent intent = new Intent();
				setResult(3, intent);
				SelectNewAvatar.this.finish();
			}
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 10) {
			try {
				Bundle receivedSel = data.getExtras();
				String selected_avatr = receivedSel.getString("com.teks.flok.genericAvtar");
				Drawable d;
				switch (Integer.parseInt(selected_avatr)) {
				case 1:
					d = getResources().getDrawable(R.drawable.avatar1);
					break;
				case 2:
					d = getResources().getDrawable(R.drawable.avatar2);
					break;
				case 3:
					d = getResources().getDrawable(R.drawable.avatar3);
					break;
				case 4:
					d = getResources().getDrawable(R.drawable.avatar4);
					break;
				case 5:
					d = getResources().getDrawable(R.drawable.avatar5);
					break;
				case 6:
					d = getResources().getDrawable(R.drawable.avatar6);
					break;
				case 7:
					d = getResources().getDrawable(R.drawable.avatar7);
					break;
				case 8:
					d = getResources().getDrawable(R.drawable.avatar8);
					break;
				case 9:
					d = getResources().getDrawable(R.drawable.avatar9);
					break;
				case 10:
					d = getResources().getDrawable(R.drawable.avatar10);
					break;
				default:
					d = getResources().getDrawable(R.drawable.avatar10);
					break;
				}
				flag = true;
				imgNewAvatar.setBackgroundDrawable(d);
				globalObj.avatar = null;
				globalObj.avatar = d;
				avatarName = "/data/data/com.teks.flok/avatar" + selected_avatr + ".png";
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (requestCode == 3) {
			// get image from device internal memory
		} else if (requestCode == 4) { // Phone external storage
			try {
				if(data != null){
					System.gc();
					Uri selectedImage = data.getData();
					Cursor cursor = getContentResolver().query(selectedImage, null,	null, null, null);
					cursor.moveToFirst();
					int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
					avatarName = cursor.getString(idx);
					System.out.println("Path of the image to be uploaded is "+ avatarName);
					flag = true;
					cursor.close();

					File file = new File(avatarName);
					FileInputStream fis = null;
					fis = new FileInputStream(file);
					Bitmap bitmapOrg = BitmapFactory.decodeStream(fis);

					int width = bitmapOrg.getWidth();
					int height = bitmapOrg.getHeight();
					int newWidth = globalObj.imageResizeWidth;
					int newHeight = globalObj.imageResizeHeight;

					float scaleWidth = ((float) newWidth) / width;
					float scaleHeight = ((float) newHeight) / height;

					Matrix matrix = new Matrix();
					matrix.postScale(scaleWidth, scaleHeight);
					Bitmap resizedBitmap = Bitmap.createBitmap(bitmapOrg, 0, 0,
							width, height, matrix, true);
					BitmapDrawable bmd = new BitmapDrawable(resizedBitmap);
					globalObj.avatar = bmd;

					imgNewAvatar.setBackgroundDrawable(bmd);

				}
				
				// Bundle receivedSel = data.getExtras();
				// String selected_avatr =
				// receivedSel.getString("com.teks.flok.userAvtar");
				// Drawable d=Drawable.createFromPath(selected_avatr);
				// imgNewAvatar.setBackgroundDrawable(d);
				// GlobalValues.avatar=d;
				// System.out.println("Picture returned from SD card intent "+selected_avatr);
				// avatarName=selected_avatr;
				// flag=true;

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

package com.teks.flok;

import java.util.ArrayList;
import java.util.List;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;
import com.facebook.android.Facebook;

public class PeopleLikeMeProfile extends Activity implements OnClickListener {

	TextView txtUserSince = null;
	TextView txtUserName = null;
	WebView tagsWebView = null;;
	Button btnTag = null;
	ImageView imgUserAvatar = null;
	public ProgressDialog progDialog = null;
	public final Context myApp = this;
	Drawable d = null;
	GlobalValues globalObj = null;
	LinearLayout adWhirlPeopleLikeMeProfile = null;
	ScrollView background = null;
	String userID = "", userName = "", avatarFLink = "", cd = "", tagInfo = "";
	String tagCSV = "", tagName = "", accessToken = "", tokenSecret = "";
	String backgroundImage = "";
	private Facebook mFacebook = null;
	public String PROFILE_ID = "", facebookToken = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.people_like_me_profile);

		globalObj = GlobalValues.getInstance();
		adWhirlPeopleLikeMeProfile = (LinearLayout) findViewById(R.id.adWhirlPeopleLikeMeProfile);
		txtUserSince = (TextView) findViewById(R.id.txtUserSince);
		txtUserName = (TextView) findViewById(R.id.txtUserName);
		tagsWebView = (WebView) findViewById(R.id.tagWebView);
		imgUserAvatar = (ImageView) findViewById(R.id.imgAvatarProfile);

		btnTag = (Button) findViewById(R.id.btnTag);
		btnTag.setOnClickListener(this);

		WebSettings settings = tagsWebView.getSettings();
		settings.setPluginsEnabled(true);
		settings.setJavaScriptEnabled(true);
		settings.setJavaScriptCanOpenWindowsAutomatically(true);
		settings.setLoadsImagesAutomatically(true);
		settings.setUserAgentString("Mozilla/5.0 (Linux; U; Android 1.6; en-us; Android Dev Phone 1 Build/DRC83) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1");
		tagsWebView.setWebChromeClient(new WebChromeClient());
		tagsWebView.setScrollBarStyle(2);
		tagsWebView.setHorizontalScrollBarEnabled(false);
		tagsWebView.setVerticalScrollBarEnabled(false);
		background = (ScrollView) findViewById(R.id.peopleLikeMeProfileBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPeopleLikeMeProfile.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPeopleLikeMeProfile.invalidate();
		}
		else{
			adWhirlPeopleLikeMeProfile.setVisibility(View.GONE);
		}
		
		
		
		Bundle received = getIntent().getExtras();
		String[] arrPeopleInfo = received.getStringArray("com.teks.flok.peopleInfo");
		userID = arrPeopleInfo[0];
		avatarFLink = arrPeopleInfo[1];
		userName = arrPeopleInfo[4];
		cd = arrPeopleInfo[5];

		fetchData();

		txtUserName.setText(userName);
		String[] dt = cd.split(" ");
		txtUserSince.setText("Part of the flok since " + dt[0].split("-")[2]+ "/" + dt[0].split("-")[1] + "/" + dt[0].split("-")[0]);

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences(
				"Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	Drawable drawable_from_url(String url, String src_name)throws java.net.MalformedURLException, java.io.IOException {
		return Drawable.createFromStream(((java.io.InputStream) new java.net.URL(url).getContent()), src_name);
	}

	public void fetchData() {
		progDialog = ProgressDialog.show(this, "Info", "Collecting information. Please wait....", true);
		new Thread() {
			public void run() {
				try {
					// d = drawable_from_url(avatarFLink, "userimage.png");
					HttpConnection obj = HttpConnection.getInstance();
					d = obj.getUserAvatar(avatarFLink);
					tagInfo = obj.getAllTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userID);
				} catch (Exception e) {
					e.printStackTrace();
				}
				profileInfoHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler profileInfoHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (d == null) { // set default flok avatar if image is not downloaded.
				imgUserAvatar.setBackgroundDrawable(getResources().getDrawable(R.drawable.avatar10));
			} else {
				imgUserAvatar.setBackgroundDrawable(d);
			}
			tagsWebView.loadData(tagInfo, "text/html", "UTF-8");
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnTag) {
			Intent intentAssignTag = new Intent(PeopleLikeMeProfile.this, AssignTagToOthers.class);
			startActivityForResult(intentAssignTag, 1);

		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == 1) {
			Bundle receivedSel = data.getExtras();
			tagCSV = receivedSel.getString("com.teks.flok.tagCSV");
			tagName = receivedSel.getString("com.teks.flok.tagName");
			System.out.println("Received tags are " + tagCSV);
			saveTags();
		}

		if (resultCode == 11) {
			Bundle receivedSel = data.getExtras();
			String status = receivedSel.getString("com.teks.flok.TwitterCredentials");
 
			if (status.equals("Saved")) {
				readOAuthKeys();
				updateUserStaus();
			}
		}

		else if (resultCode == 12) {
			Bundle receivedSel = data.getExtras();
			String status = receivedSel.getString("com.teks.flok.facebookCredentials");

			if (status.equals("Saved")) {
				readFacebookCredentails();
				updateFacebookWall();
			}
		}
	}

	public void saveTags() {
		progDialog = ProgressDialog.show(myApp, "Info", "Tags are being saved. Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.updateUserTag(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userID, tagCSV);
					if (globalObj.jsonResult.equals(""))
						globalObj.jsonResult = obj.updateUserTag(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userID, tagCSV);
					System.out.println("Response after tagging the people "	+ globalObj.jsonResult);
					if (!globalObj.jsonResult.contains("errmsg")) {
						tagInfo = obj.getAllTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userID);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				saveTagHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler saveTagHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String unlockedTag = "";
			if (!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")) {
				try {
					globalObj.job = new JSONObject(globalObj.jsonResult);
					unlockedTag = globalObj.job.getString("unlockedtags").toString();
					System.out.println("Unlocked tags are " + unlockedTag);
					globalObj.jsonResult = null;
					globalObj.job = null;
					// update twitter here
					readOAuthKeys();
					if (!accessToken.equals("") && !tokenSecret.equals("")) {
						updateUserStaus();
						System.out.println("updating user's twitter status");
					} else {
						Intent intentTwitter = new Intent(PeopleLikeMeProfile.this, GetTwitterToken.class);
						intentTwitter.putExtra("com.teks.flok.forTwitterCalledFrom", "PeopleLikeMeProfile");
						startActivityForResult(intentTwitter, 11);
					}

					readFacebookCredentails();
					if (facebookToken != null) { // user is already logged in so
													// update his/her wall
						updateFacebookWall();
					} else { // otherwise redirect user to login to facebook
						Intent intentFacebook = new Intent(PeopleLikeMeProfile.this, FacebookUpdate.class);
						intentFacebook.putExtra("com.teks.flok.forFacebookCalledFrom", "PeopleLikeMeProfile");
						startActivityForResult(intentFacebook, 12);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				if (!unlockedTag.equals("")) {
					new AlertDialog.Builder(myApp)
					.setTitle("Info")
					.setIcon(R.drawable.alert_info)
					.setMessage( "You've unlocked the "	+ unlockedTag + "tag(s)!  Now you can tag yourself and others as " + unlockedTag+ ".  Keep tagging more people and places to unlock more hidden tags.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false).create().show();
				} else {
					new AlertDialog.Builder(myApp)
					.setTitle("Info").setIcon(R.drawable.alert_info)
					.setMessage("Tags have been updated successfully.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false)
					.create()
					.show();
				}
				tagsWebView.loadData(tagInfo, "text/html", "UTF-8");
			}
		}
	};

	private void updateUserStaus() {
		// TODO Auto-generated method stub
		try {
			String status = globalObj.loggedInUserName + " has just tagged " + userName + " as " + tagName + " using Flok.to for android";
			OAuthConsumer consumer = new CommonsHttpOAuthConsumer(globalObj.consumerKey, globalObj.consumerSecretKey);
			consumer.setTokenWithSecret(accessToken, tokenSecret);

			HttpPost request = new HttpPost("http://api.twitter.com/1/statuses/update.xml");
			HttpClient client = new DefaultHttpClient();

			final List<NameValuePair> nvps = new ArrayList<NameValuePair>();
			// 'status' here is the update value you collect from UI
			nvps.add(new BasicNameValuePair("status", status));
			request.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
			// set this to avoid 417 error (Expectation Failed)
			request.getParams().setBooleanParameter(
					CoreProtocolPNames.USE_EXPECT_CONTINUE, false);
			consumer.sign(request);
			final HttpResponse response = client.execute(request);
			// response status should be 200 OK
			int statusCode = response.getStatusLine().getStatusCode();
			System.out.println("req:" + statusCode);

			if (statusCode == 200) {
				System.out.println("status posted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void readOAuthKeys() {
		SharedPreferences twitterPreferences = getSharedPreferences(
				"TwitterInfo", MODE_PRIVATE);
		accessToken = twitterPreferences.getString("AccessToken", "");
		tokenSecret = twitterPreferences.getString("TokenSecret", "");
	}

	public void updateFacebookWall() {
		try {
			mFacebook = new Facebook();
			SessionStore.restore(mFacebook, PeopleLikeMeProfile.this);
			Bundle values = new Bundle();
			values.putString("message",globalObj.loggedInUserName + " has just tagged " + userName + " as " + tagName + " using Flok.to for android");
			mFacebook.request(PROFILE_ID + "/feed", values, "POST");
			// mFacebook.request("100000411193558/feed", values, "POST");
		} catch (Exception e) {
			// e.printStackTrace();
		}
	}

	public void readFacebookCredentails() {
		SharedPreferences savedSession = getSharedPreferences("facebook-session", Context.MODE_PRIVATE);
		facebookToken = savedSession.getString("access_token", null);
		PROFILE_ID = savedSession.getString("PROFILE_ID", null);
	}
}

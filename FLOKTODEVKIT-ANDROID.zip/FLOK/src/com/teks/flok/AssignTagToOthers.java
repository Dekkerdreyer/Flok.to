package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

import com.adwhirl.AdWhirlLayout;

public class AssignTagToOthers extends Activity implements OnClickListener {
	
	
	ProgressDialog progDialog = null;
	
	Spinner spinnerATTO1 = null;
	Spinner spinnerATTO2 = null;
	Spinner spinnerATTO3 = null;
	Spinner spinnerATTO4 = null;
	Spinner spinnerATTO5 = null;
	Button btnSave = null;
	LinearLayout adWhirlAssignTagToOthers = null;
	public final Context myApp = this;
	public String[][] tags = null;
	public int[] selectedTags = new int[5];
	ScrollView background = null;
	String backgroundImage = "", tagCSV = "", tagName = "";
	GlobalValues globalObj = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.assign_tag_to_others);
		
		globalObj = GlobalValues.getInstance();
		adWhirlAssignTagToOthers = (LinearLayout) findViewById(R.id.adWhirlAssignTagToOthers);
		spinnerATTO1 = (Spinner) findViewById(R.id.spinnerATTO1);
		spinnerATTO2 = (Spinner) findViewById(R.id.spinnerATTO2);
		spinnerATTO3 = (Spinner) findViewById(R.id.spinnerATTO3);
		spinnerATTO4 = (Spinner) findViewById(R.id.spinnerATTO4);
		spinnerATTO5 = (Spinner) findViewById(R.id.spinnerATTO5);
		btnSave = (Button)findViewById(R.id.btnSaveTag);
		btnSave.setOnClickListener(this);
		
		
		background=(ScrollView)findViewById(R.id.assignTagBackground);
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}		
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlAssignTagToOthers.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlAssignTagToOthers.invalidate();
		}
		else{
			adWhirlAssignTagToOthers.setVisibility(View.GONE);
		}
		
		
		fetchTagInfo();
	}
	
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}	
	}
	
	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnSaveTag){
			if(tags[selectedTags[0]][0].equals("-1") && tags[selectedTags[1]][0].equals("-1") && tags[selectedTags[2]][0].equals("-1") && tags[selectedTags[3]][0].equals("-1") && tags[selectedTags[4]][0].equals("-1")){
				new AlertDialog.Builder(myApp)
				.setMessage("Sorry, you didn't select any tag.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
			else{
				tagCSV="";
				for(int i=0;i<selectedTags.length;i++){
					if(selectedTags[i]>0){
						if(tagCSV.equals("")){
							tagCSV=tags[selectedTags[i]][0]+",";
							tagName=tags[selectedTags[i]][1];
						}
						else{
							tagCSV+=tags[selectedTags[i]][0]+",";
							tagName+=", "+tags[selectedTags[i]][1];
						}
						System.out.println("tag id "+ (i+1)+"==> "+tags[selectedTags[i]][0]);
						
					}
				}
				String[] tTag = tagName.split(",");
				tagName = "";
				for(int i=0;i<tTag.length;i++){
					if(tagName.equals(""))
						tagName = tTag[i];
					else if(i == tTag.length-1)
						tagName+=" and "+tTag[i];
					else
						tagName+=", "+tTag[i];
				}
				
				System.out.println("tagging string is "+tagName);
				tagCSV=tagCSV.substring(0, tagCSV.length()-1);
				Intent intent = new Intent();
				intent.putExtra("com.teks.flok.tagCSV",tagCSV);
				intent.putExtra("com.teks.flok.tagName",tagName);
				
		        setResult(1,intent);
		        finish(); 
			}
		}
	}
	
	public void fetchTagInfo(){
    	progDialog = ProgressDialog.show(myApp,"Loading", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.fetchTagsCategory(globalObj.loggedInUserName, globalObj.loggedInUserPassword, "2");
    				if(globalObj.jsonResult.equals(""))
    					globalObj.jsonResult = obj.fetchTagsCategory(globalObj.loggedInUserName, globalObj.loggedInUserPassword, "2");  // try once again if not succeeded in one go
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			tagInfoHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
	
	private Handler tagInfoHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")){
				populateTagArr();
				try{
					populateSpinners();
				}catch(Exception e){e.printStackTrace();}
	    		
			}
			else{				
				new AlertDialog.Builder(myApp)
				.setMessage("Some error occured while fetching tag information.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
    	}
    };
    
    public void populateTagArr(){
    	try{
    		globalObj.job=new JSONObject(globalObj.jsonResult);
    		globalObj.ja=globalObj.job.getJSONArray("jsonResult");
    		tags=new String[globalObj.ja.length()+1][2];
    		tags[0][0]="-1";
    		tags[0][1]="Select Tag";
    		for(int i=0;i<globalObj.ja.length();i++){
				tags[i+1][0]=globalObj.ja.getJSONObject(i).getString("tagid").toString();
				tags[i+1][1]=globalObj.ja.getJSONObject(i).getString("tagname").toString();
    		}
    		globalObj.jsonResult = null;
    		globalObj.job = null;
    		globalObj.ja = null;
    		System.out.println("total number of tags for tagging is "+tags.length);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    
    public void populateSpinners(){  
        
    	String[] strArr=new String[tags.length];
        for(int i=0;i<tags.length;i++){
    		strArr[i]=tags[i][1];
    	}
        
        
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    
        
        spinnerATTO1.setAdapter(arrayAdapter);
        spinnerATTO1.setSelection(0);
        spinnerATTO1.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                    	selectedTags[0]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        spinnerATTO2.setAdapter(arrayAdapter);
        spinnerATTO2.setSelection(0);
        spinnerATTO2.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                    	selectedTags[1]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        spinnerATTO3.setAdapter(arrayAdapter);
        spinnerATTO3.setSelection(0);
        spinnerATTO3.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                    	selectedTags[2]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        
        spinnerATTO4.setAdapter(arrayAdapter);
        spinnerATTO4.setSelection(0);
        spinnerATTO4.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                    	selectedTags[3]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        
        spinnerATTO5.setAdapter(arrayAdapter);
        spinnerATTO5.setSelection(0);
        spinnerATTO5.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        selectedTags[4]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
    }
}

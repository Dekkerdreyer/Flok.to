package com.teks.flok;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class ForgotPassword extends Activity implements OnClickListener {

	EditText txtForgotPassword = null;
	Button btnForgotPassword = null;
	LinearLayout adWhirlForgotPassword = null;
	ProgressDialog progDialog = null;
	GlobalValues globalObj = null;
	Context myApp = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.forgot_password_layout);
		
		globalObj = GlobalValues.getInstance();
		myApp = this;
		adWhirlForgotPassword = (LinearLayout) findViewById(R.id.adWhirlForgotPassword);
		txtForgotPassword = (EditText) findViewById(R.id.txtForgotPasswordUsername);
		btnForgotPassword = (Button) findViewById(R.id.btnForgotPassword);
		btnForgotPassword.setOnClickListener(this);
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
			RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
			adWhirlForgotPassword.addView(adWhirlLayout, adWhirlLayoutParams);
			adWhirlForgotPassword.invalidate();
		}
		else{
			adWhirlForgotPassword.setVisibility(View.GONE);
		}
		
		
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.btnForgotPassword){
			if (!txtForgotPassword.getText().toString().equals("")) {
				recoverPassword();
			} else {
				new AlertDialog.Builder(myApp)
				.setMessage("Enter your username.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(true).create().show();
				txtForgotPassword.requestFocus();
				return;
			}
		}
	}
	
	
	public void recoverPassword() {
		progDialog = ProgressDialog.show(this, "", "Please wait....", true, true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.recoverPassword(txtForgotPassword.getText().toString());
				} catch (Exception e) {
					e.printStackTrace();
				}
				passwordRecoveryHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler passwordRecoveryHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.equals("") && !globalObj.jsonResult.contains("errmsg") && globalObj.jsonResult.contains("successmsg")) {
				new AlertDialog.Builder(myApp)
						.setIcon(getResources().getDrawable(R.drawable.alert_info))
						.setTitle("Password")
						.setMessage("Password has been sent to your email address.")
						.setPositiveButton(android.R.string.ok,	new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,	int whichButton) {
								ForgotPassword.this.finish();
							}
						})
						.setCancelable(true)
						.create()
						.show();
				return;
			} else {
				try {
					globalObj.job = new JSONObject(globalObj.jsonResult);
					new AlertDialog.Builder(myApp)
					.setTitle("Password")
					.setMessage(globalObj.job.getString("errdesc").toString())
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					globalObj.jsonResult = null;
					globalObj.job = null;
					txtForgotPassword.requestFocus();
					return;
				} catch (Exception e) {
				}

			}
		}
	};

	
}

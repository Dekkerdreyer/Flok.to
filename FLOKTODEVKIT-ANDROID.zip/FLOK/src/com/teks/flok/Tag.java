package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

public class Tag extends Activity implements OnClickListener {

	ScrollView tagBackgroungImage = null;
	String backgroundImage = "";
	Button btnTagAPerson = null;
	Button btnTagAPlace = null;
	LinearLayout adWhirlTag = null;
	GlobalValues globalObj =null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tag);

		globalObj = GlobalValues.getInstance();
		adWhirlTag = (LinearLayout) findViewById(R.id.adWhirlTag);
		btnTagAPerson = (Button) findViewById(R.id.btnTagAPerson);
		btnTagAPlace = (Button) findViewById(R.id.btnTagAPlace);

		btnTagAPerson.setOnClickListener(this);
		btnTagAPlace.setOnClickListener(this);

		tagBackgroungImage = (ScrollView) findViewById(R.id.tagBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			tagBackgroungImage.setBackgroundResource(imageResource);
		}
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlTag.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlTag.invalidate();
		}
		else{
			adWhirlTag.setVisibility(View.GONE);
		}
		

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			tagBackgroungImage.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnTagAPerson) {
			Intent i = new Intent(this, TagAPerson.class);
			View view = TagGroup.group.getLocalActivityManager()
			.startActivity("TagAPerson", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
			.getDecorView();
			TagGroup.group.replaceView(view);
		} else if (v.getId() == R.id.btnTagAPlace) {

			Intent i = new Intent(this, TagAPlace.class);
			View view = TagGroup.group.getLocalActivityManager().startActivity(
					"TagAPlace", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			TagGroup.group.replaceView(view);
		}
	}
}
package com.teks.flok;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Dialog extends Activity implements OnClickListener {
	Button bt_retry = null;
	Button bt_quit = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_layout);
		bt_retry = (Button) findViewById(R.id.bt_retry);
		bt_retry.setOnClickListener(this);
		bt_quit = (Button) findViewById(R.id.bt_quit);
		bt_quit.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		String choice = "";
		if (v.getId() == R.id.bt_retry) {
			choice = "retry";
		} else {
			choice = "quit";
		}
		Intent intent = new Intent();
		intent.putExtra("com.teks.flok.choice", choice);
		setResult(1, intent);
		finish();
	}
}

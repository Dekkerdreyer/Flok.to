package com.teks.flok;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

@SuppressWarnings("unchecked")
public class MapItemizedOverlay1 extends ItemizedOverlay {

	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	
	public MapItemizedOverlay1(Drawable defaultMarker) {
		super(boundCenterBottom(defaultMarker));
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected OverlayItem createItem(int i) {
		// TODO Auto-generated method stub
		return mOverlays.get(i);

	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return mOverlays.size();
	}
	
	public void addOverlay(OverlayItem overlay) {
	    mOverlays.add(overlay);
	    populate();
	}
	
	@Override
	public boolean onTap(GeoPoint p, MapView mapView) {
		// TODO Auto-generated method stub
		System.out.println("Form two argumented method and points longitude and latitude are " +p.getLongitudeE6()+ " "+p.getLatitudeE6());
		return super.onTap(p, mapView);
		
	}
	
	@Override
	protected boolean onTap(int index) {
		// TODO Auto-generated method stub
		System.out.println("Form one argumented method and index is " +index);
		this.setFocus( mOverlays.get(index) );
		System.out.println(mOverlays.get(index).getTitle());
		return true;//super.onTap(index);
	}

	

}

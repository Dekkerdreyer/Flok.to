package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

public class SearchFlok extends Activity implements OnClickListener {
	
	Button btnPeopleLikeMe = null;
	Button btnPeopleByTag = null;
	Button btnPlacesILike = null;
	Button btnPlacesByTag = null;
	Button btnSearchUser = null;
	ScrollView background = null;
	LinearLayout adWhirlSearchFlok = null;
	String backgroundImage = "";
	ProgressDialog progDialog = null;
	GlobalValues globalObj = null;
	Context myApp = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.search_flok);
		
		myApp = SearchGroup.myContext;
		globalObj = GlobalValues.getInstance();  // creates singleton object
		adWhirlSearchFlok = (LinearLayout) findViewById(R.id.adWhirlSearchFlok);
		btnPeopleLikeMe = (Button) findViewById(R.id.btnPeopleLikeMe);
		btnPeopleByTag = (Button) findViewById(R.id.btnPeopleByTag);
		btnPlacesILike = (Button) findViewById(R.id.btnPlacesILike);
		btnPlacesByTag = (Button) findViewById(R.id.btnPlacesByTag);
		btnSearchUser = (Button) findViewById(R.id.btnSearchUser);
		
		btnPeopleLikeMe.setOnClickListener(this);
		btnPeopleByTag.setOnClickListener(this);
		btnPlacesILike.setOnClickListener(this);
		btnPlacesByTag.setOnClickListener(this);
		btnSearchUser.setOnClickListener(this);
		
		background=(ScrollView)findViewById(R.id.searchFlokBackground);
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}		
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlSearchFlok.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlSearchFlok.invalidate();
		}
		else{
			adWhirlSearchFlok.setVisibility(View.GONE);
		}
		
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}	
	}
	
	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnPeopleLikeMe){
			
			Intent i = new Intent(this, PeopleLikeMe.class);
			View view = SearchGroup.group.getLocalActivityManager()
					.startActivity("PeopleLikeMe",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			SearchGroup.group.replaceView(view);
			
//			Intent intentPeopleLikeMe=new Intent(SearchFlok.this, PeopleLikeMe.class);
//			startActivity(intentPeopleLikeMe);
			
		}
		else if(v.getId()==R.id.btnPeopleByTag){
			
			Intent intentPeopleByTag=new Intent(SearchFlok.this, PeopleByTag.class);
			startActivity(intentPeopleByTag);
			
//			Intent i = new Intent(this, PeopleByTag.class);
//			View view = SearchGroup.group.getLocalActivityManager()
//					.startActivity("PeopleByTag",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
//					.getDecorView();
//			SearchGroup.group.replaceView(view);
			
		}
		else if(v.getId()==R.id.btnPlacesILike){
//			Intent i = new Intent(this, PlacesIWouldLike.class);
//			View view = SearchGroup.group.getLocalActivityManager()
//					.startActivity("PlacesIWouldLike",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
//					.getDecorView();
//			SearchGroup.group.replaceView(view);
			
			
			downloadArcheTypes();  // download archetype and then call next activity
			
			
		}
		else if(v.getId()==R.id.btnPlacesByTag){
			Intent intentPlacesByTag=new Intent(SearchFlok.this, PlacesByTag.class);
			startActivity(intentPlacesByTag);
		}
		else if(v.getId()==R.id.btnSearchUser){
//			Intent intentSearchUser = new Intent(this, SearchUserByUsername.class);
//			startActivity(intentSearchUser);
			
			Intent i = new Intent(this, SearchUserByUsername.class);
			View view = SearchGroup.group.getLocalActivityManager()
					.startActivity("SearchUser",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			SearchGroup.group.replaceView(view);
		}
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
//		SearchGroup.group.back();
	}
	
	public void downloadArcheTypes(){
		progDialog = ProgressDialog.show(myApp,"Loading", "Please wait....",true, true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.getArcheTypes(globalObj.loggedInUserName, globalObj.loggedInUserPassword);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			aecheHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
	}
	
	private Handler aecheHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(!globalObj.jsonResult.equals("")){
				Intent i = new Intent(SearchFlok.this, PlaceArchtypesList.class);
				View view = SearchGroup.group.getLocalActivityManager()
						.startActivity("PAT",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				SearchGroup.group.replaceView(view);
			}
    	}
    };

}

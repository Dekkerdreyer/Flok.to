package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;
import com.facebook.android.Facebook;

public class FacebookUpdateListView extends Activity {

	String[] arrTweets = new String[5];
	public ProgressDialog progDialog = null;
	ListView tweetList = null;
	ArrayAdapter<String> tweetAdapter = null;
	public Context myApp = null;
	LinearLayout background = null;
	LinearLayout tweetListParentLayout = null;
	LinearLayout adWhirlTweetListView = null;
	String backgroundImage = "";

	private Facebook mFacebook;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.tweet_list_view);

		globalObj = GlobalValues.getInstance();
		adWhirlTweetListView = (LinearLayout) findViewById(R.id.adWhirlTweetListView);
		tweetList = (ListView) findViewById(R.id.tweetList);
		myApp = SettingsGroup.myContext; // SettingsGroup is the main class
											// which launches sub activities.

		background = (LinearLayout) findViewById(R.id.tweetListViewBackground);
		tweetListParentLayout = (LinearLayout) findViewById(R.id.tweetListParentLayout);

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		mFacebook = new Facebook();
		SessionStore.restore(mFacebook, FacebookUpdateListView.this);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlTweetListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlTweetListView.invalidate();
		}
		else{
			adWhirlTweetListView.setVisibility(View.GONE);
		}
		
		
		fetchTweetsOfUser();

	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	public void fetchTweetsOfUser() {

		progDialog = ProgressDialog.show(myApp, "Loading", "Please wait....",
				true);
		new Thread() {
			public void run() {
				try {
					globalObj.jsonResult = mFacebook.request("me/home");
					System.out.println("feeds:" + globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				tweetHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler tweetHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.equals("")) {
				parseTweets(); // parse the json and extract required field
				populateList(); // populates tweets in list view.
			}
		}
	};

	public void parseTweets() {
		try {
			globalObj.job = new JSONObject(globalObj.jsonResult);
			globalObj.ja = globalObj.job.getJSONArray("data");
			int count = 1, i = 0;
			System.out.println("Length of facebook feed is " + globalObj.ja.length());
			while (count <= 5) {

				if (globalObj.ja.getJSONObject(i).has("message")) {
					arrTweets[count - 1] = globalObj.ja.getJSONObject(i).getString("message").toString();
					count++;
				}
				i++;
			}
			globalObj.jsonResult = null;
			globalObj.job = null;
			globalObj.ja = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public void populateList() {
		tweetListParentLayout.setVisibility(tweetListParentLayout.VISIBLE);
		tweetAdapter = new myAdapter(FacebookUpdateListView.this, arrTweets);
		tweetList.setAdapter(tweetAdapter);
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.tweet_row, objects);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.tweet_row, null);
			}
			TextView txtTweet = (TextView) v.findViewById(R.id.txtTweetRow);
			txtTweet.setText(arrTweets[position]);
			return v;
		}
	}

	@Override
	public void onBackPressed() {
		SettingsGroup.group.back();
	}
}

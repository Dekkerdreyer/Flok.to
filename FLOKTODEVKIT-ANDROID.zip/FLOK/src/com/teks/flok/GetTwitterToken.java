package com.teks.flok;

import java.net.HttpURLConnection;
import java.net.URL;

import oauth.signpost.OAuth;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.basic.DefaultOAuthProvider;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.exception.OAuthNotAuthorizedException;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import com.adwhirl.AdWhirlLayout;

public class GetTwitterToken extends Activity implements OnClickListener {

	String token = "";
	String tokenSecret = "";
	String calledFromActivity = "";
	String backgroundImage = "";
	EditText txtToken = null;
	Button btnSubmitToken = null;
	Button btnObtainToken = null;

	public final Context myApp = this;
	OAuthConsumer consumer = null;
	OAuthProvider provider = null;
	LinearLayout adWhirlGetTwitterToken = null;
	ScrollView background = null;
	GlobalValues globalObj = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.get_token_twitter_layout);

		globalObj = GlobalValues.getInstance();
		adWhirlGetTwitterToken = (LinearLayout) findViewById(R.id.adWhirlGetTwitterToken);
		background = (ScrollView) findViewById(R.id.twitterTokenBackground);
		txtToken = (EditText) findViewById(R.id.txtToken);
		btnSubmitToken = (Button) findViewById(R.id.btnTokenSubmit);
		btnObtainToken = (Button) findViewById(R.id.btnObtainToken);

		btnSubmitToken.setOnClickListener(this);
		btnObtainToken.setOnClickListener(this);

		Bundle received = getIntent().getExtras();
		calledFromActivity = received.getString("com.teks.flok.forTwitterCalledFrom");

		consumer = new DefaultOAuthConsumer(globalObj.consumerKey, globalObj.consumerSecretKey);
		provider = new DefaultOAuthProvider(
				"http://twitter.com/oauth/request_token",
				"http://twitter.com/oauth/access_token",
				"http://twitter.com/oauth/authorize");
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlGetTwitterToken.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlGetTwitterToken.invalidate();
		}
		else{
			adWhirlGetTwitterToken.setVisibility(View.GONE);	
		}
		
        
        
//        backgroundImage=getBackgroundImage();
//		if(!backgroundImage.equals("NA")){
//			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
//			 background.setBackgroundResource(imageResource);
//		}		
      

	}

	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	
	public String getAuthURL() throws OAuthMessageSignerException,
			OAuthNotAuthorizedException, OAuthExpectationFailedException,
			OAuthCommunicationException {

		// String authUrl = provider.retrieveRequestToken(OAuth.OUT_OF_BAND);

		String authUrl = provider.retrieveRequestToken(consumer, OAuth.OUT_OF_BAND);
		// String authUrl = provider.retrieveRequestToken(consumer,
		// OAuth.OAUTH_CALLBACK);
		System.out.println("Request token: " + consumer.getToken());
		System.out.println("Token secret: " + consumer.getTokenSecret());

		token = consumer.getToken();
		tokenSecret = consumer.getTokenSecret();

		System.out.println("Token is in Oncreate " + token);
		System.out.println("Token secret in onCreate" + tokenSecret);

		System.out.println(authUrl);
		return authUrl;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(txtToken.getWindowToken(), 0);
		if (v.getId() == R.id.btnTokenSubmit) {
			if (!txtToken.getText().toString().equals("")) {
				tokenManipulation(txtToken.getText().toString());
			} else {
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter a valid PIN.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				txtToken.requestFocus();
				return;
			}
		} else if (v.getId() == R.id.btnObtainToken) {
			try {

				String urlToLoad = getAuthURL();
				Intent intentURL = new Intent(GetTwitterToken.this,	GetTwitterTokenWebview.class);
				intentURL.putExtra("com.teks.flok.oauth.authURL", urlToLoad);
				startActivity(intentURL);
	
//				Intent myIntent = new Intent(Intent.ACTION_VIEW,  Uri.parse(urlToLoad));
//				startActivity(myIntent);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void tokenManipulation(String pin) {
		try {
			// provider.retrieveAccessToken(pin);
			provider.retrieveAccessToken(consumer, pin);

			token = consumer.getToken();
			tokenSecret = consumer.getTokenSecret();

			System.out.println("Access token: " + consumer.getToken());
			System.out.println("Token secret: " + consumer.getTokenSecret());

			URL url = new URL("http://twitter.com/statuses/mentions.xml");

			HttpURLConnection request = (HttpURLConnection) url.openConnection();
			consumer.sign(request);

			System.out.println("Sending request to Twitter...");
			request.connect();

			System.out.println("Response: " + request.getResponseCode() + " " + request.getResponseMessage());
			if (request.getResponseCode() == 200 && request.getResponseMessage().equals("OK")) { //  indicates  successful connection using oauth
				SharedPreferences userPreferences = getSharedPreferences("TwitterInfo", MODE_PRIVATE);
				SharedPreferences.Editor editor = userPreferences.edit();
				editor.putString("AccessToken", consumer.getToken());
				editor.putString("TokenSecret", consumer.getTokenSecret());
				editor.commit();
				System.out.println("Twitter credentials have been saved");
				System.out.println("Stored information are AccessToken --> "
						+ consumer.getToken() + " and TkenSecret --> "
						+ consumer.getTokenSecret());

				if (calledFromActivity.equals("Settings")) {
					globalObj.isTwitterCredentialsSaved = true;
				}
				Intent intent = new Intent();
				intent.putExtra("com.teks.flok.TwitterCredentials", "Saved");
				setResult(11, intent);
				GetTwitterToken.this.finish();
			} else {
				new AlertDialog.Builder(myApp)
				.setMessage("It is not a valid PIN.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				txtToken.requestFocus();
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// private void updateUserStaus(String token, String tokenSecret) {
	// // TODO Auto-generated method stub
	// try{
	// //here u can get tokens from saved file
	// String status="testing flok frm android "; //set your status
	// OAuthConsumer consumer = new
	// CommonsHttpOAuthConsumer(GlobalValues.consumerKey,GlobalValues.consumerSecretKey);
	// consumer.setTokenWithSecret(token, tokenSecret);
	//				
	// HttpPost request = new
	// HttpPost("http://api.twitter.com/1/statuses/update.xml");
	// HttpClient client = new DefaultHttpClient();
	//			
	// final List<NameValuePair> nvps = new ArrayList<NameValuePair>();
	// // 'status' here is the update value you collect from UI
	// nvps.add(new BasicNameValuePair("status", status));
	// request.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
	// // set this to avoid 417 error (Expectation Failed)
	// request.getParams().setBooleanParameter(CoreProtocolPNames.USE_EXPECT_CONTINUE,
	// false);
	// consumer.sign(request);
	// final HttpResponse response = client.execute(request);
	// // response status should be 200 OK
	// int statusCode = response.getStatusLine().getStatusCode();
	// System.out.println("req:"+statusCode);
	//       
	// if (statusCode == 200) {
	// System.out.println("status posted");
	// }
	//		
	// }
	// catch(Exception e){e.printStackTrace();}
	// }

}
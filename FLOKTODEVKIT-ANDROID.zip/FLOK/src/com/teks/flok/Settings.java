package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class Settings extends Activity implements OnClickListener, LocationListener {
	
	TextView txtChangeBackImage = null;
	TextView txtUpdatePassword = null;
	TextView txtUpdateMyLocation = null;
	TextView txtTwitterRSSFeed = null;
	TextView txtFacebookRSSFeed = null;
	TextView txtResetAllTags = null;
	TextView txtDeletAccount = null;
	TextView txtChangeEmailAddress = null;
	
	public Context myApp = null;
	ScrollView background = null;
	LinearLayout adWhirlSettings = null;
	String backgroundImage = "";
	ProgressDialog progDialog = null;
	String updateLocationResult = "", deleteAccountResult = "";
	TextView txtPreviousSelected = null;
	private LocationManager locationManager = null;
	boolean gpsFlag = false;
	String accessToken = "", tokenSecret = "";
	String userName = "", password = "";
	GlobalValues globalObj = null;

	private static final String TOKEN = "access_token";
	// private static final String EXPIRES = "expires_in";
	private static final String KEY = "facebook-session";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.settings);

		globalObj = GlobalValues.getInstance();
		adWhirlSettings = (LinearLayout) findViewById(R.id.adWhirlSettings);
		txtChangeBackImage = (TextView) findViewById(R.id.txtChangeBackgroung);
		txtChangeBackImage.setOnClickListener(this);

		txtUpdatePassword = (TextView) findViewById(R.id.txtUpdatePassword);
		txtUpdatePassword.setOnClickListener(this);

		txtChangeEmailAddress = (TextView) findViewById(R.id.txtUpdateEmailAddress);
		txtChangeEmailAddress.setOnClickListener(this);

		txtTwitterRSSFeed = (TextView) findViewById(R.id.txtTwitterFeedUrl);
		txtTwitterRSSFeed.setOnClickListener(this);

		txtFacebookRSSFeed = (TextView) findViewById(R.id.txtFacebookFeedUrl);
		txtFacebookRSSFeed.setOnClickListener(this);

		txtResetAllTags = (TextView) findViewById(R.id.txtResetAllTags);
		txtResetAllTags.setOnClickListener(this);

		txtDeletAccount = (TextView) findViewById(R.id.txtDeleteAccount);
		txtDeletAccount.setOnClickListener(this);

		txtUpdateMyLocation = (TextView) findViewById(R.id.txtUpdateMyLocation);
		txtUpdateMyLocation.setOnClickListener(this);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlSettings.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlSettings.invalidate();
		}
		else{
			adWhirlSettings.setVisibility(View.GONE);
		}
		
		
		myApp = SettingsGroup.myContext;
		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || !isConnected()) {
			new AlertDialog.Builder(myApp)
			.setTitle("Error!")
			.setIcon(R.drawable.error)
			.setMessage("Flok is unable to connect at this time due to poor gps reception. Please try again later.")
			.setPositiveButton(android.R.string.ok,	new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,	int whichButton) {
					Settings.this.finish();
				}
			})
			.setCancelable(false)
			.create()
			.show();
			return;
		}

		background = (ScrollView) findViewById(R.id.settingsBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		readUserInfo();
		myApp = SettingsGroup.myContext;
	}

	public boolean isConnected() {
		ConnectivityManager connManager = (ConnectivityManager) getSystemService(Settings.CONNECTIVITY_SERVICE);
		if (connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE)
				.isAvailable()
				|| connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
						.isAvailable()) {
			return true;
		} else {
			return false;
		}
	}

	public void readOAuthKeys() {
		SharedPreferences twitterPreferences = getSharedPreferences("TwitterInfo", MODE_PRIVATE);
		accessToken = twitterPreferences.getString("AccessToken", "");
		tokenSecret = twitterPreferences.getString("TokenSecret", "");
		System.out.println("Access Token and token secret are " + accessToken + " " + tokenSecret);
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	public void resetTags() {
		Intent intentResetTags = new Intent(this, ResetMyAllTags.class);
		startActivity(intentResetTags);
		// Intent i = new Intent(this, ResetMyAllTags.class);
		// View view = SettingsGroup.group.getLocalActivityManager()
		// .startActivity("RAMT",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
		// .getDecorView();
		// SettingsGroup.group.replaceView(view);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		if (v.getId() == R.id.txtChangeBackgroung) {
			if (txtPreviousSelected != null) {
				txtPreviousSelected.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtChangeBackImage;

			txtChangeBackImage.setBackgroundResource(R.layout.rounded_corner_selected);
			txtChangeBackImage.setTextColor(Color.WHITE);

			Intent i = new Intent(this, ChangeBackgroundImage.class);
			View view = SettingsGroup.group.getLocalActivityManager()
					// Create the view using FirstGroup's LocalActivityManager
					.startActivity("CB",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			SettingsGroup.group.replaceView(view); // Again, replace the view

		} else if (v.getId() == R.id.txtUpdateEmailAddress) {
			if (txtPreviousSelected != null) {
				txtPreviousSelected
						.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtChangeEmailAddress;

			txtChangeEmailAddress
					.setBackgroundResource(R.layout.rounded_corner_selected);
			txtChangeEmailAddress.setTextColor(Color.WHITE);

			Intent i = new Intent(this, ChangeEmailAddress.class);
			View view = SettingsGroup.group.getLocalActivityManager()
					// Create the view using FirstGroup's LocalActivityManager
					.startActivity("CEA", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			SettingsGroup.group.replaceView(view); // Again, replace the view

		} else if (v.getId() == R.id.txtUpdatePassword) {

			if (txtPreviousSelected != null) {
				txtPreviousSelected.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtUpdatePassword;

			txtUpdatePassword.setBackgroundResource(R.layout.rounded_corner_selected);
			txtUpdatePassword.setTextColor(Color.WHITE);

			Intent i = new Intent(this, UpdatePassword.class);
			View view = SettingsGroup.group.getLocalActivityManager()
					.startActivity("UP", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
					.getDecorView();
			SettingsGroup.group.replaceView(view);

		} else if (v.getId() == R.id.txtTwitterFeedUrl) {

			if (txtPreviousSelected != null) {
				txtPreviousSelected.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtTwitterRSSFeed;

			txtTwitterRSSFeed.setBackgroundResource(R.layout.rounded_corner_selected);
			txtTwitterRSSFeed.setTextColor(Color.WHITE);

			readOAuthKeys();

			if (!accessToken.equals("") && !tokenSecret.equals("")) {
				Intent i = new Intent(Settings.this, TweetListView.class);
				View view = SettingsGroup.group.getLocalActivityManager()
						.startActivity("TLV", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				SettingsGroup.group.replaceView(view);
			} else {
				Intent intentTwitter = new Intent(Settings.this,
						GetTwitterToken.class);
				intentTwitter.putExtra("com.teks.flok.forTwitterCalledFrom", "Settings");
				startActivityForResult(intentTwitter, 11);
			}

		} else if (v.getId() == R.id.txtUpdateMyLocation) {

			startLocationServices(); // start GPS service

			if (txtPreviousSelected != null) {
				txtPreviousSelected .setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtUpdateMyLocation;

			txtUpdateMyLocation.setBackgroundResource(R.layout.rounded_corner_selected);
			txtUpdateMyLocation.setTextColor(Color.WHITE);
			if (globalObj.testFlag) { // when application is running in testing mode, it will ask for GPS position from user.
				stopLocationServices();
				Intent intentTestGPSProvider = new Intent(Settings.this, TestGPSProvider.class);
				intentTestGPSProvider.putExtra("com.teks.flok.calledFrom",	"Settings");
				startActivityForResult(intentTestGPSProvider, 200);
			} else {
				updateMyLocation();
			}
		} else if (v.getId() == R.id.txtFacebookFeedUrl) {

			if (txtPreviousSelected != null) {
				txtPreviousSelected.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtFacebookRSSFeed;

			txtFacebookRSSFeed.setBackgroundResource(R.layout.rounded_corner_selected);
			txtFacebookRSSFeed.setTextColor(Color.WHITE);

			/*
			 * read facebook access token, if it is there in the preference file
			 * then redirect to FacebookUpdateListView activity otherwise
			 * redirect FacebookUpdate.java for login.
			 */

			SharedPreferences savedSession = getSharedPreferences(KEY, Context.MODE_PRIVATE);
			String facebookToken = savedSession.getString(TOKEN, null);
			if (facebookToken != null) {
				Intent i = new Intent(this, FacebookUpdateListView.class);
				View view = SettingsGroup.group.getLocalActivityManager()
						.startActivity("FULV", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				SettingsGroup.group.replaceView(view);
			} else {
				Intent intentFacebook = new Intent(Settings.this, FacebookUpdate.class);
				intentFacebook.putExtra("com.teks.flok.forFacebookCalledFrom", "Settings");
				startActivityForResult(intentFacebook, 12);
			}

			// Intent i = new Intent(this, FacebookPost.class);
			// View view = SettingsGroup.group.getLocalActivityManager()
			// .startActivity("FP",
			// i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
			// .getDecorView();
			// SettingsGroup.group.replaceView(view);
		} else if (v.getId() == R.id.txtResetAllTags) {

			if (txtPreviousSelected != null) {
				txtPreviousSelected.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtResetAllTags;

			txtResetAllTags.setBackgroundResource(R.layout.rounded_corner_selected);
			txtResetAllTags.setTextColor(Color.WHITE);

			// ================ Alert dialog to clear all profile tags including
			// by others also. ===========================

			// AlertDialog.Builder alertDialog = new AlertDialog.Builder(myApp);
			// alertDialog.setTitle("Warning!");
			// alertDialog.setMessage("You have opted to clear your tags. This will clear all tags, including your own self-selected profile tags, from this profile. Immediately upon confirming this action you will be prompted to create new profile tags for yourself.");
			//		    
			// alertDialog.setPositiveButton("All", new
			// DialogInterface.OnClickListener() {
			// public void onClick(DialogInterface dialog, int which) {
			//		    		
			// return;
			// } });
			// alertDialog.setNeutralButton("By Others", new
			// DialogInterface.OnClickListener() {
			// public void onClick(DialogInterface dialog, int which) {
			// return;
			// }});
			// alertDialog.setNegativeButton("Cancel", new
			// DialogInterface.OnClickListener() {
			// public void onClick(DialogInterface dialog, int which) {
			// return;
			// }});
			// alertDialog.show();

			AlertDialog.Builder alertbox = new AlertDialog.Builder(myApp);
			alertbox.setTitle("Warning!");
			alertbox.setInverseBackgroundForced(true);
			alertbox.setMessage("You have opted to clear your tags. This will clear all tags, including your own self-selected profile tags, from this profile. Immediately upon confirming this action you will be prompted to create new profile tags for yourself.");
			alertbox.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {
					resetTags();
				}
			});
			alertbox.setNegativeButton("Cancel",
			new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface arg0, int arg1) {

				}
			});
			alertbox.show();

		} else if (v.getId() == R.id.txtDeleteAccount) {

			if (txtPreviousSelected != null) {
				txtPreviousSelected
						.setBackgroundResource(R.layout.rounded_corner);
				txtPreviousSelected.setTextColor(Color.BLACK);
			}

			txtPreviousSelected = txtDeletAccount;

			txtDeletAccount.setBackgroundResource(R.layout.rounded_corner_selected);
			txtDeletAccount.setTextColor(Color.WHITE);

			AlertDialog.Builder alertbox = new AlertDialog.Builder(myApp);
			alertbox.setTitle("Warning!");
			alertbox.setInverseBackgroundForced(true);
			alertbox.setMessage("Do you want to delete your account?");
			alertbox.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface arg0, int arg1) {
							deleteAccount();
						}
					});
			alertbox.setNegativeButton("Cancel",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface arg0, int arg1) {

						}
					});
			alertbox.show();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		System.out.println("onActivityResult method called");
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == 12) {
			// Bundle receivedSel = data.getExtras();
			// String status =
			// receivedSel.getString("com.teks.flok.facebookCredentials");
			// if(status.equals("Saved")){
			// SharedPreferences savedSession =getSharedPreferences(KEY,
			// Context.MODE_PRIVATE);
			// String facebookToken=savedSession.getString(TOKEN, null);
			// if(facebookToken!=null){
			// Intent i = new Intent(this, FacebookUpdateListView.class);
			// View view = SettingsGroup.group.getLocalActivityManager()
			// .startActivity("FULV",i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
			// .getDecorView();
			// SettingsGroup.group.replaceView(view);
			// }
			// }
		} else if (requestCode == 11) {

		} else if (requestCode == 200) { // if app is running in testing mode
											// then supply GPS position manually
			if (data != null) {
				Bundle received = data.getExtras();
				String lng = received.getString("com.teks.flok.longitude");
				String lat = received.getString("com.teks.flok.latitude");
				if (lng.length() > 0 && lat.length() > 0) {
					globalObj.longitude = Double.parseDouble(lng);
					globalObj.latitude = Double.parseDouble(lat);
					gpsFlag = true;
					updateMyLocation();
				}
			}
		}
	};

	public void deleteAccount() {

		progDialog = ProgressDialog.show(myApp, "", "Please wait....", true,
				true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					deleteAccountResult = obj.deleteAccount(userName, password);
					System.out.println("Delete account result is "
							+ deleteAccountResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				deleteAccountHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler deleteAccountHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (deleteAccountResult.contains("Deleted")) {
				SharedPreferences preferencesFile = getSharedPreferences("UserPassword", MODE_PRIVATE);
				SharedPreferences.Editor editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("EmailAddress", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.putString("status", "Incomplete");
				editor.putString("emailAddress", "");
				editor.putString("DOB", "");
				editor.commit();

				preferencesFile = getSharedPreferences("Questions", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("Avtar", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("AvtarFileStatus", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.putInt("Flag", 0);
				editor.commit();

				preferencesFile = getSharedPreferences("LoginInfo", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("TwitterInfo", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("facebook-session", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.clear();
				editor.commit();

				preferencesFile = getSharedPreferences("Settings", MODE_PRIVATE);
				editor = preferencesFile.edit();
				editor.putString("BackgroundImage", "drawable/background");
				editor.commit();

				Intent mainIntent = new Intent(Settings.this, Login.class);
				startActivity(mainIntent);
				Settings.this.finish();
			}
		}
	};

	private void startLocationServices() {
		Log.d("GPS", "Location Services Started");
		locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
				2000, 0, this);
	}

	private void stopLocationServices() {
		Log.d("GPS", "Location Services Stopped");
		if (locationManager != null) {
			locationManager.removeUpdates(this);
		}
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		if (location != null) {
			globalObj.longitude = location.getLongitude();
			globalObj.latitude = location.getLatitude();
			gpsFlag = true;
		}
		System.out.println("Longitude and Latitude from onLocation changed "+ globalObj.longitude + " " + globalObj.latitude);
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		stopLocationServices();
		super.onDestroy();
	}

	public void readUserInfo() {
		SharedPreferences userPreferences = getSharedPreferences("LoginInfo", MODE_PRIVATE);
		userName = userPreferences.getString("UserName", "NA");
		password = userPreferences.getString("Password", "NA");
	}

	public void updateMyLocation() {
		// progDialog = ProgressDialog.show(myApp,"Please wait...",
		// "Retrieving GPS location.",true,true);
		progDialog = ProgressDialog.show(myApp, "",	"Location is being updated....", true, true);
		new Thread() {
			public void run() {
				try {
					while (!gpsFlag) {

					}
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.userLogin(userName, password, ""	+ globalObj.longitude, "" + globalObj.latitude);
					System.out.println("Update location result is "	+ updateLocationResult);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					stopLocationServices();
				}
				updateLocationHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler updateLocationHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("userid")) {
				globalObj.jsonResult = null;
				SharedPreferences userPreferences = getSharedPreferences("LoginInfo", MODE_PRIVATE);
				SharedPreferences.Editor editor = userPreferences.edit();
				editor.putString("Longitude", "" + globalObj.longitude);
				editor.putString("Latitude", "" + globalObj.latitude);
				editor.commit();
				stopLocationServices();
				
				new AlertDialog.Builder(myApp)
				.setTitle("Info!")
				.setIcon(R.drawable.alert_info)
				.setMessage("Location has been updated successfully.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
			} else {
				stopLocationServices();
			}
		}
	};

	@Override
	protected void onResume() {
		super.onResume();
		if (globalObj.isLOcationUpdated) {
			gpsFlag = true;
			updateMyLocation();
			System.out.println("on resume called");
			globalObj.isLOcationUpdated = false;
		}
//		if (globalObj.isFacebookCredentialsSaved) {
//			globalObj.isFacebookCredentialsSaved = false;
//			Intent i = new Intent(Settings.this, FacebookUpdateListView.class);
//			View view = SettingsGroup.group.getLocalActivityManager()
//					.startActivity("FULV1",	i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
//					.getDecorView();
//			SettingsGroup.group.replaceView(view);
//		}
//		if (globalObj.isTwitterCredentialsSaved) {
//			globalObj.isTwitterCredentialsSaved = false;
//			Intent i = new Intent(Settings.this, TweetListView.class);
//			View view = SettingsGroup.group.getLocalActivityManager()
//					.startActivity("TLV1", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
//					.getDecorView();
//			SettingsGroup.group.replaceView(view);
//		}
	};

	// public void readOAuthKeys(){
	// SharedPreferences twitterPreferences =
	// getSharedPreferences("TwitterInfo",MODE_PRIVATE);
	// accessToken = twitterPreferences.getString("AccessToken","");
	// tokenSecret = twitterPreferences.getString("TokenSecret", "");
	// System.out.println("Access Token and token secret are "+accessToken+" "+tokenSecret);
	// }
}

package com.teks.flok;

import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;

public class GetTwitterTokenWebview extends Activity implements OnClickListener {

	WebView webview1 = null;
	String urlToLoad = null;
	TextView txtBack = null;
	public final Context myApp = this;
	LinearLayout adWhirlTwitterWebViewLayout = null;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.webview_twitter_layout);

		globalObj = GlobalValues.getInstance();
		adWhirlTwitterWebViewLayout = (LinearLayout) findViewById(R.id.adWhirlTwitterWebViewLayout);
		
		webview1 = (WebView) findViewById(R.id.webview);

		Bundle received = getIntent().getExtras();
		urlToLoad = received.getString("com.teks.flok.oauth.authURL");

		txtBack = (TextView) findViewById(R.id.txtBackToApp);
		txtBack.setOnClickListener(this);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlTwitterWebViewLayout.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlTwitterWebViewLayout.invalidate();
		}
		else{
			adWhirlTwitterWebViewLayout.setVisibility(View.GONE);
		}
		
		clearWebViewCache(); // clear the webview cache
//		selectAndCopyText();
		
		//WebSettings settings = webview.getSettings();
//		settings.setPluginsEnabled(true);
		webview1.getSettings().setJavaScriptEnabled(true);
//		settings.setJavaScriptCanOpenWindowsAutomatically(true);
//		settings.setLoadsImagesAutomatically(true);
//		settings.setUserAgentString("Mozilla/5.0 (Linux; U; Android 1.6; en-us; Android Dev Phone 1 Build/DRC83) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1");
//		webview1.setwebview1Client(new WVClient());
//		webview1.setWebChromeClient(new WebChromeClient());
		webview1.setScrollBarStyle(2);
		webview1.setHorizontalScrollBarEnabled(false);
		webview1.setVerticalScrollBarEnabled(false);
		
		webview1.loadUrl(urlToLoad);
		System.out.println("Received url is " + urlToLoad);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && webview1.canGoBack()) {
			webview1.goBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	class WVClient extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			System.out.println("URL called:" + url);
			view.loadUrl(url);
			while (webview1.zoomOut()) {
			}
			return true;
		}

		public void onPageFinished(WebView view, String url) {
			while (webview1.zoomOut()) {
			}
		}

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.txtBackToApp) {
			GetTwitterTokenWebview.this.finish();
		}
	}
	
	public void clearWebViewCache(){
		File dir = getCacheDir();
        if(dir != null && dir.isDirectory()){
            try{
	            File[] children = dir.listFiles();
	            if (children.length >0) {
	                for (int i = 0; i < children.length; i++) {
	                    File[] temp = children[i].listFiles();
	                    for(int x = 0; x<temp.length; x++)
	                    {
	                        temp[x].delete();
	                        System.out.println("Cache file is deleted. "+i +" => "+x);
	                    }
	                }
	            }
            }catch(Exception e) {
                Log.e("Cache", "failed cache clean");
            }
        }
	}
	
	
	/**
     * Select Text in the webview and automatically sends the selected text to the clipboard
     */
    public void selectAndCopyText() {
        try {
         KeyEvent shiftPressEvent = new KeyEvent(0,0,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_SHIFT_LEFT,0,0);
         shiftPressEvent.dispatch(webview1);
        } catch (Exception e) {
            throw new AssertionError(e);
        }
    } 

}

package com.teks.flok;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ZoomButtonsController;
import android.widget.ZoomControls;
import android.widget.ZoomButtonsController.OnZoomListener;

import com.adwhirl.AdWhirlLayout;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class TagAPerson extends MapActivity implements OnZoomListener {

	List<Overlay> mapOverlays = null;
	Drawable drawable = null;
	MapItemizedOverlay itemizedOverlay = null;

	public Context myApp = null;
	private MapView myMapView = null;
	MapController mc = null;
	GeoPoint p = null;
	public ProgressDialog progDialog = null;
	String[][] arrPeopleDetails = null;
	String[] avtarURL = null;
	RelativeLayout background = null;
	String backgroundImage = "";
	double longitude = 0, latitude = 0;
	GlobalValues globalObj = null;
	LinearLayout adWhirlPeopleLikeMe = null;

	@SuppressWarnings("unchecked")
	private class MapItemizedOverlay extends ItemizedOverlay {
		@SuppressWarnings("unused")
		GeoPoint gp;
		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();

		public MapItemizedOverlay(Drawable defaultMarker) {
			super(boundCenterBottom(defaultMarker));
			// TODO Auto-generated constructor stub
		}

		public MapItemizedOverlay(Drawable defaultMarker, GeoPoint gp) {
			super(boundCenterBottom(defaultMarker));
			this.gp = gp;
		}

		@Override
		protected OverlayItem createItem(int i) {
			// TODO Auto-generated method stub
			return mOverlays.get(i);

		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return mOverlays.size();
		}

		public void addOverlay(OverlayItem overlay) {
			mOverlays.add(overlay);
			populate();
		}

		@Override
		public boolean onTap(GeoPoint p, MapView mapView) {
			// TODO Auto-generated method stub
			return super.onTap(p, mapView);

		}

		@Override
		protected boolean onTap(int index) {
			// TODO Auto-generated method stub

			String pInfo = mOverlays.get(index).getTitle();
			System.out.println("people are on this point " + pInfo);
			if (!pInfo.equals("current_user")) {
				Intent i = new Intent(TagAPerson.this, PeopleListView.class);
				i.putExtra("com.teks.flok.peopleInfo", pInfo);
				View view = TagGroup.group.getLocalActivityManager()
						.startActivity("TagAPerson",
								i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				TagGroup.group.replaceView(view);
			}

			return super.onTap(index);
		}
	}

	public void fetchPeopleData() {
		progDialog = ProgressDialog.show(myApp, "Info", "Collecting information, please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.peopleLikeMe(globalObj.loggedInUserName, globalObj.loggedInUserPassword);
					System.out.println("Details of people are "	+ globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				peopleLikeMeHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler peopleLikeMeHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("errmsg") || globalObj.jsonResult.equals("")) {
				new AlertDialog.Builder(myApp)
				.setMessage("Sorry. No results match right now.")
				.setPositiveButton(android.R.string.ok,	new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,	int whichButton) {
							showCurrentUserOnMap();

							mc.animateTo(p);
							mc.setCenter(p);
							mc.setZoom(10);
							myMapView.invalidate();

						}
					})
					.setCancelable(false)
					.create()
					.show();
			} else {
				if (!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")) {
					parsePublicData();
					populateMapwithPeopleCluster(10);
					showCurrentUserOnMap();

					mc.animateTo(p);
					mc.setCenter(p);
					mc.setZoom(10);
					myMapView.invalidate();
				}

			}
		}
	};

	public void populateMapwithPeopleCluster(int zoomLevel) {
		if (arrPeopleDetails != null) {
			Clustering objCluster = new Clustering();
			String[][][] arrPeopleCluster = objCluster.makeClusteredPointsForPeople(arrPeopleDetails, 150, zoomLevel);

			for (int i = 0; i < arrPeopleCluster.length; i++) {
				if (arrPeopleCluster[i].length >= 1 && arrPeopleCluster[i].length <= 5)
					drawable = TagAPerson.this.getResources().getDrawable(R.drawable.blue);
				else if (arrPeopleCluster[i].length >= 6 && arrPeopleCluster[i].length <= 10)
					drawable = TagAPerson.this.getResources().getDrawable(R.drawable.green);
				else if (arrPeopleCluster[i].length >= 11 && arrPeopleCluster[i].length <= 20)
					drawable = TagAPerson.this.getResources().getDrawable(R.drawable.yellow);
				else if (arrPeopleCluster[i].length >= 21 && arrPeopleCluster[i].length <= 50)
					drawable = TagAPerson.this.getResources().getDrawable(R.drawable.orange);
				else if (arrPeopleCluster[i].length > 50)
					drawable = TagAPerson.this.getResources().getDrawable(R.drawable.red);

				double[] meanPoint = objCluster.calculateMeanPointforPeople(arrPeopleCluster[i]);
				double lng = meanPoint[0];
				double lat = meanPoint[1];

				GeoPoint point = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));

				itemizedOverlay = new MapItemizedOverlay(drawable, point);

				String tagData = "";
				for (int j = 0; j < arrPeopleCluster[i].length; j++) {
					String rec = "";
					for (int k = 0; k < arrPeopleCluster[i][j].length; k++) {
						if (rec == "") {
							rec = arrPeopleCluster[i][j][k];
						} else {
							rec += "#~#" + arrPeopleCluster[i][j][k];
						}
					}
					if (tagData.length() > 0)
						tagData += "###" + rec;
					else
						tagData = rec;
				}

				OverlayItem overlayitem = new OverlayItem(point, tagData, "");

				itemizedOverlay.addOverlay(overlayitem);
				mapOverlays.add(itemizedOverlay);
			}
		}
	}

	// =============== Method to show the current user position on map  ===================
	public void showCurrentUserOnMap() {
		drawable = TagAPerson.this.getResources().getDrawable(R.drawable.current_position_of_user);
		double lat = globalObj.latitude;
		double lng = globalObj.longitude;
		System.out.println("Current user position is Long : " + lng + " Lat : "	+ lat);
		GeoPoint point = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
		itemizedOverlay = new MapItemizedOverlay(drawable, point);

		OverlayItem overlayitem = new OverlayItem(point, "current_user", "");
		itemizedOverlay.addOverlay(overlayitem);
		mapOverlays.add(itemizedOverlay);

		p = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
		mc = myMapView.getController();
	}

	// ====================================================================================

	public void parsePublicData() {
		try {
			globalObj.job = new JSONObject(globalObj.jsonResult);
			globalObj.ja = globalObj.job.getJSONArray("jsonResult");
			arrPeopleDetails = new String[globalObj.ja.length()][6];
			avtarURL = new String[globalObj.ja.length()];
			for (int i = 0; i < globalObj.ja.length(); i++) {
				arrPeopleDetails[i][0] = globalObj.ja.getJSONObject(i).getString("userid").toString();
				arrPeopleDetails[i][1] = globalObj.ja.getJSONObject(i).getString("avatarflink").toString();
				avtarURL[i] = globalObj.ja.getJSONObject(i).getString("avatarflink").toString();
				arrPeopleDetails[i][2] = globalObj.ja.getJSONObject(i).getString("longitude").toString();
				arrPeopleDetails[i][3] = globalObj.ja.getJSONObject(i).getString("latitude").toString();
				arrPeopleDetails[i][4] = globalObj.ja.getJSONObject(i).getString("username").toString();
				arrPeopleDetails[i][5] = globalObj.ja.getJSONObject(i).getString("cd").toString();

				System.out.println("People " + (i + 1) + " Details "+ arrPeopleDetails[i][0] + " " + arrPeopleDetails[i][1]	+ " " + arrPeopleDetails[i][2] + " "+ arrPeopleDetails[i][3]);
			}
			globalObj.jsonResult = null;
			globalObj.job = null;
			globalObj.ja = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle icicle) {
		// TODO Auto-generated method stub
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.people_like_me);

		globalObj = GlobalValues.getInstance();
		myApp = TagGroup.myContext;
		adWhirlPeopleLikeMe = (LinearLayout) findViewById(R.id.adWhirlPeopleLikeMe);
		myMapView = (MapView) findViewById(R.id.mapview1);

		mapOverlays = myMapView.getOverlays();

		background = (RelativeLayout) findViewById(R.id.peopleLikeMeBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPeopleLikeMe.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPeopleLikeMe.invalidate();
		}
		else{
			adWhirlPeopleLikeMe.setVisibility(View.GONE);
		}
		
		
		
		LinearLayout linearLayout;
		ZoomControls mZoom;
		linearLayout = (LinearLayout) findViewById(R.id.zoomview);
		mZoom = (ZoomControls) myMapView.getZoomControls();
		linearLayout.addView(mZoom);

		myMapView.displayZoomControls(true);
		myMapView.setStreetView(true);

		myMapView.setBuiltInZoomControls(true);

		ZoomButtonsController zoomButton = myMapView.getZoomButtonsController();
		zoomButton.setOnZoomListener(new ZoomButtonsController.OnZoomListener() {

					@Override
					public void onZoom(boolean zoomIn) {
						// TODO Auto-generated method stub
						int zl = myMapView.getZoomLevel();
						System.out.println("Current zoom level is " + zl);
						if (zoomIn && zl <= 21) {
							myMapView.getOverlays().clear();
							myMapView.invalidate();
							populateMapwithPeopleCluster(zl + 1);
							showCurrentUserOnMap();

							mc = myMapView.getController();
							mc.setZoom(zl + 1);
							myMapView.invalidate();

						} else if (!zoomIn && zl > 1) {
							myMapView.getOverlays().clear();
							myMapView.invalidate();
							populateMapwithPeopleCluster(zl - 1);
							showCurrentUserOnMap();

							mc = myMapView.getController();
							mc.setZoom(zl - 1);
							myMapView.invalidate();
						}
					}

					@Override
					public void onVisibilityChanged(boolean visible) {
						// TODO Auto-generated method stub
					}
				});

		fetchPeopleData();

	}

	
	@Override
	public void onZoom(boolean zoomIn) {
		// TODO Auto-generated method stub
		int zl = myMapView.getZoomLevel();
		System.out.println("Current zoom level is " + zl);
		if (zoomIn && zl <= 21) {
			myMapView.getOverlays().clear();
			myMapView.invalidate();
			populateMapwithPeopleCluster(zl + 1);
			showCurrentUserOnMap();

			mc = myMapView.getController();
			mc.setZoom(zl + 1);
			myMapView.invalidate();

		} else if (!zoomIn && zl > 1) {
			myMapView.getOverlays().clear();
			myMapView.invalidate();
			populateMapwithPeopleCluster(zl - 1);
			showCurrentUserOnMap();

			mc = myMapView.getController();
			mc.setZoom(zl - 1);
			myMapView.invalidate();
		}
	}

	@Override
	public void onVisibilityChanged(boolean visible) {
		// TODO Auto-generated method stub
	}
	
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
}

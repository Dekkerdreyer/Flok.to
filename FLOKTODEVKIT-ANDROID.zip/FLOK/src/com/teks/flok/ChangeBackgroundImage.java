package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.AdapterView.OnItemClickListener;

public class ChangeBackgroundImage extends Activity {
	
	LinearLayout adWhirlChangeBackground = null;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.change_background);

		globalObj = GlobalValues.getInstance();
		adWhirlChangeBackground = (LinearLayout) findViewById(R.id.adWhirlChangeBackground);
		GridView gridview = (GridView) findViewById(R.id.backgroundImageGallery);
		gridview.setAdapter(new ImageAdapter(this));
		gridview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View v,
					int position, long id) {
				String uri = "drawable/bg" + (position + 1);
				SharedPreferences userPreferences = getSharedPreferences(
						"Settings", MODE_PRIVATE);
				SharedPreferences.Editor editor = userPreferences.edit();
				editor.putString("BackgroundImage", uri);
				editor.commit();

				Intent intentRestart = new Intent(ChangeBackgroundImage.this,
						Host.class);
				startActivity(intentRestart);
				ChangeBackgroundImage.this.finish();
			}
		});
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlChangeBackground.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlChangeBackground.invalidate();
		}
		else{
			adWhirlChangeBackground.setVisibility(View.GONE);
		}
		
	}

	public class ImageAdapter extends BaseAdapter {
		private Context mContext;

		public ImageAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return mThumbIds.length;
		}

		public Object getItem(int position) {
			return null;
		}

		public long getItemId(int position) {
			return 0;
		}

		// create a new ImageView for each item referenced by the Adapter
		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView;
			if (convertView == null) { // if it's not recycled, initialize some
										// attributes
				imageView = new ImageView(mContext);
				imageView.setLayoutParams(new GridView.LayoutParams(100, 100));
				imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
				imageView.setPadding(8, 8, 8, 8);
			} else {
				imageView = (ImageView) convertView;
			}

			imageView.setImageResource(mThumbIds[position]);
			return imageView;
		}

		// references to our images
		private Integer[] mThumbIds = { R.drawable.bg1, R.drawable.bg2,
				R.drawable.bg3, R.drawable.bg4, R.drawable.bg5, R.drawable.bg6,
				R.drawable.bg7, R.drawable.bg8, R.drawable.bg9,
				R.drawable.bg10, };
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		SettingsGroup.group.back();
		super.onBackPressed();
	}

}

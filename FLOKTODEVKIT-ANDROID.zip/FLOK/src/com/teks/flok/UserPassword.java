package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class UserPassword extends Activity implements OnClickListener {
	EditText txtUsername = null;
	TextView txtPassword = null;
	TextView txtErrorMsg = null;
	Button btnSubmit = null;
	LinearLayout adWhirlLayoutUserPassword = null;
	final Context myApp = this;
	public ProgressDialog progDailog = null;
	boolean flag = false;
	boolean retry = true;
	GlobalValues globalObj = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
	    this.setContentView(R.layout.user_password);
	    
	    globalObj = GlobalValues.getInstance();
	    adWhirlLayoutUserPassword = (LinearLayout) findViewById(R.id.adWhirlUserPassword);
	    txtUsername=(EditText)findViewById(R.id.username);
	    txtPassword=(EditText)findViewById(R.id.password);
	    txtErrorMsg=(TextView)findViewById(R.id.txtErrorMsg);
	    btnSubmit=(Button)findViewById(R.id.btnUserPassSubmit);
	    btnSubmit.setOnClickListener(this);
	    
	    if(globalObj.isDemoApplication){
	    	final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlLayoutUserPassword.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlLayoutUserPassword.invalidate();
	    }
	    else{
	    	adWhirlLayoutUserPassword.setVisibility(View.GONE);
	    }
	    
	}

	@SuppressWarnings("static-access")
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnUserPassSubmit){
			InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtPassword.getWindowToken(), 0);
			imm.hideSoftInputFromWindow(txtUsername.getWindowToken(), 0);
			
			if(""+txtUsername.getText()!="" && ""+txtPassword.getText()!=""){
				txtErrorMsg.setVisibility(txtErrorMsg.INVISIBLE);
				if(!isConnected()){
					Intent intent_for_dialog = new Intent(this,Dialog.class);
					startActivityForResult(intent_for_dialog,1);
				}
				else 
					checkAvailability();
			}
			else if(""+txtUsername.getText()==""){
				
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter username.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
			else if(""+txtPassword.getText()==""){
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter password.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		}
	}
	
	 public void checkAvailability(){
	    	progDailog = ProgressDialog.show(this,"Checking for availability.", "Please wait....",true);
	    	new Thread() {
				public void run() {
	    			try{
	    				HttpConnection obj=HttpConnection.getInstance();
	    				String res=obj.userAvailable(txtUsername.getText().toString());
	    				System.out.println("Server response is "+res);
	    				if(res.contains("errmsg"))
	    					flag=false;
	    				else if(res.contains("successmsg"))
	    					flag=true;
	    			}
	    			catch (Exception e)
	    			{ 
	    				e.printStackTrace();
	    			}
	    			userPassHandler.sendEmptyMessage(0);
	    			progDailog.dismiss(); 
	    		}
	    	}.start();
	    }
	    
	    private Handler userPassHandler = new Handler() {
	    	@SuppressWarnings("static-access")
			@Override
	    	public void handleMessage(Message msg) {
	    		if(flag){
	    			SharedPreferences userPreferences = getSharedPreferences("UserPassword",MODE_PRIVATE);
	    			SharedPreferences.Editor editor = userPreferences.edit();
	    			editor.putString("userName", txtUsername.getText().toString());
	    			editor.putString("password", txtPassword.getText().toString());
	    			editor.putString("status", "Complete");	    			
	    			editor.commit();
	    			
	    			Intent emailIntent=new Intent(UserPassword.this,EmailAddress.class);
	    			startActivity(emailIntent);
	    			UserPassword.this.finish();
	    		}
	    		else{
	    			txtErrorMsg.setVisibility(txtErrorMsg.VISIBLE);
	    			txtErrorMsg.setText("Username is not available, choose another one.");
	    			txtUsername.requestFocus();
	    		}
	    	}
	    };

	    public boolean isConnected(){
			ConnectivityManager connManager =  (ConnectivityManager)getSystemService(UserPassword.CONNECTIVITY_SERVICE);
			 if(connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable()   || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) {
				return true;
			}
			else{
				return false;
			}
		}
	    
	    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			if (resultCode == 1) {
				Bundle receivedSel = data.getExtras();
				String selected_ans = receivedSel.getString("com.teks.flok.choice");
				if(selected_ans.equals("retry")){
					retry = true;
				}else{
					retry = false;
					this.finish();
				}
			}
		}

}

package com.teks.flok;

import org.apache.commons.validator.EmailValidator;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

public class ChangeEmailAddress extends Activity implements OnClickListener {

	EditText txtEmailAddress = null;
	Button btnDone = null;
	LinearLayout adWhirlChangeEmail = null;
	public Context myApp = null;
	public ProgressDialog progDialog = null;	
	ScrollView background = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
	    this.setContentView(R.layout.change_email_layout);
	    
	    
	    globalObj = GlobalValues.getInstance();
	    adWhirlChangeEmail = (LinearLayout) findViewById(R.id.adWhirlChangeEmail);
	    txtEmailAddress = (EditText) findViewById(R.id.txtChangeEmailAddress);   
	    btnDone = (Button) findViewById(R.id.btnChangeEmailAddress);
	    btnDone.setOnClickListener(this);
	    background = (ScrollView) findViewById(R.id.changeEmailAddressBackground);
	    
	    myApp = SettingsGroup.myContext;
	    
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlChangeEmail.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlChangeEmail.invalidate();
		}
		else{
			adWhirlChangeEmail.setVisibility(View.GONE);
		}
		
	}
	
	public boolean isValidEmail(String email){
		if(EmailValidator.getInstance().isValid(email))
			return true;
		else 
			return false;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnChangeEmailAddress){
			InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtEmailAddress.getWindowToken(), 0);
			if(!txtEmailAddress.getText().toString().equals("")){	
				if(isValidEmail(txtEmailAddress.getText().toString())){
					if(isConnected()){
						changeEmailAddress();
					}
					else{
						new AlertDialog.Builder(myApp)
						.setMessage("Network is not available, try agian after some time.")
						.setPositiveButton(android.R.string.ok, null)
						.setCancelable(true)
						.create()
						.show();
						SettingsGroup.group.back();
						return;
					
					}
				}
				else{
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter a valid email address.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false)
					.create()
					.show();
					txtEmailAddress.requestFocus();
					return;
				}
				
			}
			else if(txtEmailAddress.getText().toString().equals("")){
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter a valid email address.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		}
	}
	
	public boolean isConnected(){
		 ConnectivityManager connManager =  (ConnectivityManager)getSystemService(ChangeEmailAddress.CONNECTIVITY_SERVICE);
		 if(connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable()   || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) 
			return true;
		 else
			return false;
	 }
	
	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	
	public void changeEmailAddress(){
		progDialog = ProgressDialog.show(myApp,"Info", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.changeEmailAddress(globalObj.loggedInUserName, globalObj.loggedInUserPassword, txtEmailAddress.getText().toString());
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			changeEmailHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
	}
	
	private Handler changeEmailHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(globalObj.jsonResult.contains("userid")){    			
    			AlertDialog.Builder builder = new AlertDialog.Builder(myApp);
    			builder.setCancelable(true);
    			builder.setIcon(R.drawable.alert_info);
    			builder.setTitle("Info");
    			builder.setMessage("Email address has been changed successfully.");
    			builder.setInverseBackgroundForced(true);
    			builder.setPositiveButton("OK",
    					new DialogInterface.OnClickListener() {
    						@Override
    						public void onClick(DialogInterface dialog, int which) {
    							globalObj.jsonResult = null;
    							SettingsGroup.group.back();
    						}
    					});

    			AlertDialog alert = builder.create();
    			alert.show();				
			}
		}
	};
	
	public void onBackPressed() {
		SettingsGroup.group.back();
	};
}

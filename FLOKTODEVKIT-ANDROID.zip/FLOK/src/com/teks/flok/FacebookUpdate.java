package com.teks.flok;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;
import com.facebook.android.AsyncFacebookRunner;
import com.facebook.android.Facebook;
import com.facebook.android.FacebookError;
import com.facebook.android.Util;
import com.teks.flok.SessionEvents.AuthListener;
import com.teks.flok.SessionEvents.LogoutListener;

public class FacebookUpdate extends Activity {
	
	LinearLayout adWhirlFacebookLogin = null;
	GlobalValues globalObj = null;

	private static final String[] PERMISSIONS = new String[] {
			"publish_stream", "read_stream", "offline_access" };
	private LoginButton mLoginButton = null;
	private TextView mText = null;
	private Button mPostButton = null;
	private Facebook mFacebook = null;
	private AsyncFacebookRunner mAsyncRunner = null;
	private String PROFILE_ID = "" ;
	private String name = "", calledFromActivity = "";
	private static final String KEY = "facebook-session";

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.facebook_layout);
		
		globalObj = GlobalValues.getInstance();
		adWhirlFacebookLogin = (LinearLayout) findViewById(R.id.adWhirlFacebookLogin);
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlFacebookLogin.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlFacebookLogin.invalidate();
		}
		else{
			adWhirlFacebookLogin.setVisibility(View.GONE);
		}
		
		
		mLoginButton = (LoginButton) findViewById(R.id.login);
		mText = (TextView) FacebookUpdate.this.findViewById(R.id.txt);

		Bundle received = getIntent().getExtras();
		calledFromActivity = received.getString("com.teks.flok.forFacebookCalledFrom");
		mPostButton = (Button) findViewById(R.id.postButton);

		mFacebook = new Facebook();
		mAsyncRunner = new AsyncFacebookRunner(mFacebook);

		SessionStore.restore(mFacebook, this);
		SessionEvents.addAuthListener(new SampleAuthListener());
		SessionEvents.addLogoutListener(new SampleLogoutListener());
		mLoginButton.init(mFacebook, PERMISSIONS);
//		mAsyncRunner.request("me", new SampleRequestListener());

		// get user post
		try {
			String resp = mFacebook.request("me/feed");
			System.out.println("feeds:" + resp);

		}

		catch (Exception e1) {
			e1.printStackTrace();
		}
		mPostButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

//				try {
//					Bundle values = new Bundle();
//					values.putString("message", "message12");
//					//mFacebook.request(PROFILE_ID + "/feed", values, "POST"); 
//					mFacebook.request("100000411193558/feed", values, "POST");
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
			}
		});
		mPostButton.setVisibility(mFacebook.isSessionValid() ? View.VISIBLE
				: View.INVISIBLE);
	}

	public class SampleAuthListener implements AuthListener {

		public void onAuthSucceed() {
//			mText.setText("You have logged in! ");
//			mPostButton.setVisibility(View.VISIBLE);
			mAsyncRunner.request("me", new SampleRequestListener());
			
			/* now finish this activity and return to calling activity
			 * 
			 */
			if(calledFromActivity.equals("Settings")){
				globalObj.isFacebookCredentialsSaved = true;
			}
			Intent intent = new Intent();
			intent.putExtra("com.teks.flok.facebookCredentials","Saved");
	        setResult(12,intent);
	        FacebookUpdate.this.finish(); 
		}

		public void onAuthFail(String error) {
			mText.setText("Login Failed: " + error);
		}
	}

	public class SampleLogoutListener implements LogoutListener {
		public void onLogoutBegin() {
			mText.setText("Logging out...");
		}

		public void onLogoutFinish() {
			mText.setText("You have logged out! ");

			mPostButton.setVisibility(View.INVISIBLE);
		}
	}

	public class SampleRequestListener extends BaseRequestListener {

		public void onComplete(final String response) {
			try {
				// process the response here: executed in background thread
				Log.d("Facebook-Example", "Response: " + response.toString());
				JSONObject json = Util.parseJson(response);
				name = json.getString("name");
				PROFILE_ID = json.getString("id");
				
				 Editor editor =getSharedPreferences(KEY, Context.MODE_PRIVATE).edit();
			     editor.putString("PROFILE_ID", PROFILE_ID);
			     editor.commit();
				
				System.out.println("Profile id is "+PROFILE_ID+" and name is "+name);
				// then post the processed result back to the UI thread
				// if we do not do this, an runtime exception will be generated
				// e.g. "CalledFromWrongThreadException: Only the original
				// thread that created a view hierarchy can touch its views."
				FacebookUpdate.this.runOnUiThread(new Runnable() {
					public void run() {
						mText.setText("Hello there, " + name + "!");
					}
				});
			} catch (JSONException e) {
				Log.w("Facebook-Example", "JSON Error in response");
			} catch (FacebookError e) {
				Log.w("Facebook-Example", "Facebook Error: " + e.getMessage());
			}
		}
	}
}
package com.teks.flok;

import org.json.JSONArray;
import org.json.JSONObject;

import android.graphics.drawable.Drawable;

public class GlobalValues {

	
	public String APP_ID = "116605668391502";  //Facebook application id
	public String consumerKey = "tlcOUtyhcpKdadK3K6YvFQ"; // Twitter consumer key
	public String consumerSecretKey = "W0v8cVZY6uENV1JUUxpCki61Ku485ovHQOEDnX5Jo";  // Twitter secret key
	public String adWhirlSDKKey = "3c9cb7d17ba0448db6e18587c4b62337";  // AdWhirl SDK Key
	
	public String peopleTags = "";
	public String placeName = "";
	public String placeTags = "";
	public String loggedInUserName = "";   // current user
	public String loggedInUserPassword = ""; // current user's password
	public String jsonResult = "";
	
	public String[][] placeDetails = null;
	public String[] newPlaceToBeAdded = null;
	
	public int imageResizeWidth = 50;
	public int imageResizeHeight = 50;
	public int DIP_WIDTH = 320;          // adWhirl layout width
	public int DIP_HEIGHT = 52;          // adWhirl layout height
	
	public double longitude = 0;
	public double latitude = 0;
	
	public boolean isTagsReset = false;
	public boolean isTwitterCredentialsSaved = false;
	public boolean isFacebookCredentialsSaved = false;
	public boolean isLOcationUpdated = false;
	public boolean testFlag = false;  // flag to decide whethet application will run in testing mode or not.
	public boolean isDemoApplication = false;  // if flag is true then display the ad from adWhirl otherwise do not show any ad.
	
	public JSONArray ja = null;
	public JSONObject job = null;
	
	public Drawable avatar = null;
	
	private static GlobalValues instance = null;

	
	
	protected GlobalValues() {
		// Exists only to defeat instantiation.
	}

	
	public static GlobalValues getInstance() {
		if (instance == null) {
			instance = new GlobalValues();
		}
		return instance;
	}
	
	

}

package com.teks.flok;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class ClearTagsDialog extends Activity implements OnClickListener {
	Button btnOk = null;
	Button btnCancel = null;
	Button btnClearTagByOthers = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.clear_tags_dialog);
		btnOk = (Button) findViewById(R.id.btnClearTagOk);
		btnOk.setOnClickListener(this);

		btnClearTagByOthers = (Button) findViewById(R.id.btnClearTagByOthers);
		btnClearTagByOthers.setOnClickListener(this);

		btnCancel = (Button) findViewById(R.id.btnClearTagCancel);
		btnCancel.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		String choice = "";
		if (v.getId() == R.id.btnClearTagOk) {
			choice = "All";
		} else if (v.getId() == R.id.btnClearTagByOthers) {
			choice = "By Others";
		} else {
			choice = "Cancel";
		}
		Intent intent = new Intent();
		intent.putExtra("com.teks.flok.clearTags", choice);
		setResult(1, intent);
		finish();
	}
}

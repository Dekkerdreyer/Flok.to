package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

public class UpdatePassword extends Activity implements OnClickListener{
	
	EditText txtOldPassword = null;
	EditText txtNewPassword = null;
	EditText txtConfirmPassword = null;
	Button btnUpdatePassword = null;
	String userName = "", password = "";
	public Context myApp;
	public ProgressDialog progDialog = null;
	String updatePasswordresult = "";
	String newPassword = "";
	
	ScrollView background = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;
	LinearLayout adWhirlUpdatePassword  = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.update_password);
		
		globalObj = GlobalValues.getInstance();
		adWhirlUpdatePassword = (LinearLayout) findViewById(R.id.adWhirlUpdatePassword);
		txtOldPassword = (EditText) findViewById(R.id.txtOldPassword);
		txtNewPassword = (EditText) findViewById(R.id.txtNewPassword);
		txtConfirmPassword = (EditText) findViewById(R.id.txtConfirmPassword);
		btnUpdatePassword = (Button) findViewById(R.id.btnUpdatePassword);
		btnUpdatePassword.setOnClickListener(this);
		
		txtOldPassword.requestFocus();
		myApp = SettingsGroup.myContext;  // SettingsGroup is the main class which launches sub activities.
		
		
		background=(ScrollView)findViewById(R.id.updatePasswordBackground);
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}	
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlUpdatePassword.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlUpdatePassword.invalidate();
		}
		else{
			adWhirlUpdatePassword.setVisibility(View.GONE);
		}
		
	}

	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	public boolean isConnected(){
		 ConnectivityManager connManager =  (ConnectivityManager)getSystemService(UpdatePassword.CONNECTIVITY_SERVICE);
		 if(connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable()   || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) 
			return true;
		 else
			return false;
	 }
	
	public void readUserInfo(){
		SharedPreferences userPreferences = getSharedPreferences("LoginInfo",MODE_PRIVATE);
		userName=userPreferences.getString("UserName", "NA");
		password=userPreferences.getString("Password", "NA");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnUpdatePassword){
			InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtConfirmPassword.getWindowToken(), 0);
			readUserInfo();  // read user name and password
			if(!txtOldPassword.getText().toString().equals("") && !txtNewPassword.getText().toString().equals("") && !txtConfirmPassword.getText().toString().equals("")){
				if(txtOldPassword.getText().toString().equals(password)){
					if(txtNewPassword.getText().toString().equals(txtConfirmPassword.getText().toString())){
						newPassword=txtNewPassword.getText().toString();
						if(isConnected()){
							updatePassword();
						}
						else{
							new AlertDialog.Builder(myApp)
							.setMessage("Network is not available, try agian after some time.")
							.setPositiveButton(android.R.string.ok, null)
							.setCancelable(true)
							.create()
							.show();
							SettingsGroup.group.back();
						}
					}
					else{
						// New password and confirm password are not same
						new AlertDialog.Builder(myApp)
						.setMessage("New password and confirm password are not same!")
						.setPositiveButton(android.R.string.ok, null)
						.setCancelable(true)
						.create()
						.show();
						txtConfirmPassword.requestFocus();
						return;
					}
				}
				else{
					// old password is not correct
					new AlertDialog.Builder(myApp)
					.setMessage("Wrong old password!")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtOldPassword.requestFocus();
					return;
				}
			}
			else{
				// some fields are missing
				if(txtOldPassword.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter old password!")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtOldPassword.requestFocus();
					return;
				}
				else if(txtNewPassword.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter new password!")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtNewPassword.requestFocus();
					return;
				}
				else if(txtConfirmPassword.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter confirm password!")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtConfirmPassword.requestFocus();
					return;
				}
			}			
		}
	}
	
	
	public void updatePassword(){
		progDialog = ProgressDialog.show(myApp,"Info", "Updating password. Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				System.out.println("user name old password and new password are "+userName+" "+password+" "+newPassword);
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.changePassword(userName, password, newPassword);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			updatePasswordHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
	}
	
	private Handler updatePasswordHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(globalObj.jsonResult.contains("userid")){
				//password changed successfully
				SharedPreferences userPreferences = getSharedPreferences("LoginInfo",MODE_PRIVATE);
    			SharedPreferences.Editor editor = userPreferences.edit();
    			editor.putString("UserName", userName);
    			editor.putString("Password",newPassword);
    			globalObj.loggedInUserPassword = newPassword;
    			editor.commit();
    			txtOldPassword.setText("");
    			txtNewPassword.setText("");
    			txtConfirmPassword.setText("");    			
    			globalObj.jsonResult = null;
    			AlertDialog.Builder builder = new AlertDialog.Builder(myApp);
    			builder.setCancelable(true);
    			builder.setIcon(R.drawable.alert_info);
    			builder.setTitle("Info");
    			builder.setMessage("Password has been changed successfully");
    			builder.setInverseBackgroundForced(true);
    			builder.setPositiveButton("OK",
    					new DialogInterface.OnClickListener() {
    						@Override
    						public void onClick(DialogInterface dialog, int which) {
    							SettingsGroup.group.back();
    						}
    					});

    			AlertDialog alert = builder.create();
    			alert.show();				
			}
		}
	};
	
	public void onBackPressed() {
		SettingsGroup.group.back();
	};
	
}

package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.adwhirl.AdWhirlLayout;

public class MyProfile extends Activity implements OnClickListener {

	String tagValues = "", tagCSV = "";
	String[] userAndTagInfo = new String[3]; // array to hold the user details, self tags and tags by others.
	String backgroundImage = "";
	String existingTagJSON = "";
	String[] userDetails = new String[10];
	String[][] selfTags = null;
	String[][] tagsByOthres = null;
	final Context myApp = this;
	public ProgressDialog progDialog = null;

	Button btnEditSelfTags = null;
	Button btnClearTags = null;
	Button btnChangeAvtar = null;
	TextView txtUserSince = null;
	TextView txtUserName = null;
	TextView txtSelfTags = null;
	WebView tagsByOthersWebView = null;
	ImageView avatarProfile = null;
	ScrollView myProfileBackground = null;
	LinearLayout adWhirlMyProfile = null;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.my_profile);
		
		globalObj = GlobalValues.getInstance();
		adWhirlMyProfile = (LinearLayout) findViewById(R.id.adWhirlMyProfile);		
		btnEditSelfTags = (Button) findViewById(R.id.btnSelfTagEdit);
		btnClearTags = (Button) findViewById(R.id.btnClearMyTags);
		btnChangeAvtar = (Button) findViewById(R.id.btnSelectNewAvtar);
		txtUserSince = (TextView) findViewById(R.id.lblUserSince);
		txtUserName = (TextView) findViewById(R.id.lblUserName);
		txtSelfTags = (TextView) findViewById(R.id.txtSelfTags);
		tagsByOthersWebView = (WebView) findViewById(R.id.myProfileTagWebView);
		avatarProfile = (ImageView) findViewById(R.id.avtarProfile);
		btnEditSelfTags.setOnClickListener(this);
		btnClearTags.setOnClickListener(this);
		btnChangeAvtar.setOnClickListener(this);
		myProfileBackground = (ScrollView) findViewById(R.id.myProfileBackground);

		WebSettings settings = tagsByOthersWebView.getSettings();
		settings.setPluginsEnabled(true);
		settings.setJavaScriptEnabled(true);
		settings.setJavaScriptCanOpenWindowsAutomatically(true);
		settings.setLoadsImagesAutomatically(true);
		settings.setUserAgentString("Mozilla/5.0 (Linux; U; Android 1.6; en-us; Android Dev Phone 1 Build/DRC83) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1");
		tagsByOthersWebView.setWebChromeClient(new WebChromeClient());
		tagsByOthersWebView.setScrollBarStyle(2);
		tagsByOthersWebView.setHorizontalScrollBarEnabled(false);
		tagsByOthersWebView.setVerticalScrollBarEnabled(false);

		globalObj.isTagsReset = false; // When this activity runs first time set the flag false
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			myProfileBackground.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlMyProfile.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlMyProfile.invalidate();
		}
		else{
			adWhirlMyProfile.setVisibility(View.GONE);
		}
		
		if (isConnected()) {
			getProfileInfo();
		} else {
			new AlertDialog.Builder(myApp)
			.setTitle("Error!")
			.setIcon(R.drawable.error)
			.setMessage("Network is not available, try agian after some time.")
			.setPositiveButton(android.R.string.ok, null)
			.setCancelable(false)
			.create()
			.show();
			return;
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	public boolean isConnected() {
		ConnectivityManager connManager = (ConnectivityManager) getSystemService(MyProfile.CONNECTIVITY_SERVICE);
		if (connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable() || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable())
			return true;
		else
			return false;
	}

	public void getProfileInfo() {
		progDialog = ProgressDialog.show(this, "Loading", "Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.getUserProfileDetails(globalObj.loggedInUserName, globalObj.loggedInUserPassword);
				} catch (Exception e) {
					e.printStackTrace();
				}
				profileInfoHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler profileInfoHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("userid")) {
				userAndTagInfo = globalObj.jsonResult.split("###");
				try {
					globalObj.job = new JSONObject(userAndTagInfo[0]);
					userDetails[0] = globalObj.job.getString("userid").toString();
					userDetails[1] = globalObj.job.getString("username").toString();
					userDetails[2] = globalObj.job.getString("email").toString();
					userDetails[3] = globalObj.job.getString("avatarflink").toString();
					userDetails[4] = globalObj.job.getString("longitude").toString();
					userDetails[5] = globalObj.job.getString("latitude").toString();
					userDetails[6] = globalObj.job.getString("dateofbirth").toString();
					userDetails[7] = globalObj.job.getString("PA").toString();
					userDetails[8] = globalObj.job.getString("SA").toString();
					userDetails[9] = globalObj.job.getString("cd").toString();

					globalObj.job = new JSONObject(userAndTagInfo[1]);
					globalObj.ja = globalObj.job.getJSONArray("jsonResult");
					selfTags = new String[globalObj.ja.length()][2];
					for (int i = 0; i < globalObj.ja.length(); i++) {
						selfTags[i][0] = globalObj.ja.getJSONObject(i).getString("tagname").toString();
						selfTags[i][1] = globalObj.ja.getJSONObject(i).getString(	"categoryname").toString();
					}
					
					globalObj.jsonResult = null;
					globalObj.job = null;
					globalObj.ja =null;

					getUserAvatar(); // download user avatar and populate the UI

				} catch (Exception e) {
					e.printStackTrace();
				}
				System.out.println("User Detail is " + userAndTagInfo[0]);
				System.out.println("Self tags are " + userAndTagInfo[1]);
				System.out.println("Tags by others " + userAndTagInfo[2]);
			} else {
				new AlertDialog.Builder(myApp)
				.setMessage("Username or password is incorrect.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		}
	};

	public void getUserAvatar() {
		progDialog = ProgressDialog.show(this, "Loading", "Please wait....",true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.avatar = obj.getUserAvatar(userDetails[3]);
				} catch (Exception e) {
					e.printStackTrace();
				}
				userAvatarHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler userAvatarHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.avatar != null) {
				avatarProfile.setBackgroundDrawable(globalObj.avatar);
			} else { // if image couldn't download then set default profile
						// image
				avatarProfile.setBackgroundResource(R.drawable.avatar10);
				globalObj.avatar = getResources().getDrawable(R.drawable.avatar10);
			}

			String[] dt = userDetails[9].split(" ");
			txtUserSince.setText("Part of the flok since "+ dt[0].split("-")[2] + "/" + dt[0].split("-")[1] + "/"+ dt[0].split("-")[0]);
			txtUserName.setText(userDetails[1]);
			String st = "";
			for (int i = 0; i < selfTags.length; i++) {
				st += selfTags[i][0] + "   ";
			}
			txtSelfTags.setText(st);
			if (!userAndTagInfo[2].contains("No data found"))
				tagsByOthersWebView.loadData(userAndTagInfo[2], "text/html", "UTF-8");
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnSelfTagEdit) {
			Intent intentEditSelfTag = new Intent(this, EditSelfTag.class);
			startActivityForResult(intentEditSelfTag, 4);
		} else if (v.getId() == R.id.btnClearMyTags) {
			Intent intent_clear_dialog = new Intent(this, ClearTagsDialog.class);
			startActivityForResult(intent_clear_dialog, 1);
		} else if (v.getId() == R.id.btnSelectNewAvtar) {
			Intent intentSelectNewAvatar = new Intent(this,
					SelectNewAvatar.class);
			startActivityForResult(intentSelectNewAvatar, 3);
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == 1) {
			Bundle receivedSel = data.getExtras();
			String selected_ans = receivedSel.getString("com.teks.flok.clearTags");
			if (selected_ans.equals("All")) {
				System.out.println("Launch the self tagging activity");
				Intent intentTagActivity = new Intent(this,	ProfileNewTags.class);
				startActivityForResult(intentTagActivity, 2);
			} else if (selected_ans.equals("By Others")) {
				clearTagByOthers();
			} else {
				System.out.println("Don't do anything");
			}
		} else if (resultCode == 2) {
			Bundle receivedSel = data.getExtras();
			tagCSV = receivedSel.getString("com.teks.flok.tagCSV");
			tagValues = receivedSel.getString("com.teks.flok.tagValues");
			if (!tagCSV.equals("")) {
				System.out.println("Selected tags are " + tagCSV);
				clearTagsAndUpdateNewSelfTags();
			}
		} else if (resultCode == 3) {
			avatarProfile.setBackgroundDrawable(globalObj.avatar);
		} else if (resultCode == 4) {
			// edit self tags
			Bundle receivedSel = data.getExtras();
			tagCSV = receivedSel.getString("com.teks.flok.editTagCSV");
			tagValues = receivedSel.getString("com.teks.flok.editTagValues");
			if (tagCSV != "") {
				System.out.println("Selected tags are " + tagCSV);
				editSelfTags();
			}
		}
	}

	public void editSelfTags() {
		progDialog = ProgressDialog.show(this, "", "Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.updateUserTag(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userDetails[0], tagCSV);
					System.out.println("Profile tags edited result is "	+ globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				editTagHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler editTagHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("errmsg") || globalObj.jsonResult.equals("")) {
				// show error message here
			} else {
				txtSelfTags.setText(tagValues);
			}
		}
	};

	public void clearTagsAndUpdateNewSelfTags() {
		progDialog = ProgressDialog.show(this, "Info", "Updating profile. Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.clearTagsAndUpdateSelfTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userDetails[0], tagCSV, "all");
				} catch (Exception e) {
					e.printStackTrace();
				}
				clearTagHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler clearTagHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("errmsg") || globalObj.jsonResult.equals("")) {
				// show error message if required
			} else {
				txtSelfTags.setText(tagValues);
				tagsByOthersWebView.loadData("", "text/html", "UTF-8");
			}
		}
	};

	public void clearTagByOthers() {
		progDialog = ProgressDialog.show(this, "Info", "Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.clearTagsByOthers(globalObj.loggedInUserName, globalObj.loggedInUserPassword, userDetails[0], "byothers");
				} catch (Exception e) {
					e.printStackTrace();
				}
				clearOthersTagHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler clearOthersTagHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			tagsByOthersWebView.loadData("", "text/html", "UTF-8");
		}
	};

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			myProfileBackground.setBackgroundResource(imageResource);
		}
		if (globalObj.isTagsReset) {
			globalObj.isTagsReset = false;
			updateUIWithNewTags(); // populate the UI with new tags
		}
	}

	/*
	 * this method will be executed when tag will be reset from settings screen
	 * and user will come back on MyProfile screen
	 */
	public void updateUIWithNewTags() {
		progDialog = ProgressDialog.show(this, "Loading", "Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					existingTagJSON = obj.getSelfTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword); // fetch existing self tags
				} catch (Exception e) {
					e.printStackTrace();
				}
				tagInfoHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler tagInfoHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			parseExistingTags();
		}
	};

	public void parseExistingTags() {
		try {
			globalObj.job = new JSONObject(existingTagJSON);
			globalObj.ja = globalObj.job.getJSONArray("jsonResult");

			String tags = "";
			for (int i = 0; i < globalObj.ja.length(); i++) {
				tags += globalObj.ja.getJSONObject(i).getString("tagname").toString()+ "  ";
			}
			txtSelfTags.setText(tags); // updates self tag textview with new tags
			tagsByOthersWebView.loadData("", "text/html", "UTF-8");  
			System.out.println("New tags after reset are " + tags);
			
			globalObj.jsonResult = "";
			globalObj.job = null;
			globalObj.ja = null;
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

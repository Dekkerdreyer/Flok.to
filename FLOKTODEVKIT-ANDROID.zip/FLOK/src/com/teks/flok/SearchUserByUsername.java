package com.teks.flok;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class SearchUserByUsername extends Activity implements OnClickListener {

	EditText txtSearchKeyword = null;
	ImageView imgSearchUser = null;
	GlobalValues globalObj = null;
	Context myApp = null;
	ProgressDialog progDialog = null;
	LinearLayout adWhirlSearchUser = null;
	LinearLayout searchUserBackgroung = null;
	String backgroundImage = "";
	String[] userInfo = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.search_user_layout);

		globalObj = GlobalValues.getInstance();
		adWhirlSearchUser = (LinearLayout) findViewById(R.id.adWhirlSearchUser);
//		myApp = this;
		myApp = SearchGroup.myContext;
		searchUserBackgroung = (LinearLayout) findViewById(R.id.searchUserBackground);
		txtSearchKeyword = (EditText) findViewById(R.id.txtSearchUserName);
		imgSearchUser = (ImageView) findViewById(R.id.imgSearchUser);
		imgSearchUser.setOnClickListener(this);
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlSearchUser.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlSearchUser.invalidate();
		}
		else{
			adWhirlSearchUser.setVisibility(View.GONE);
		}
		
        
        backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			searchUserBackgroung.setBackgroundResource(imageResource);
		}
		
        

	}
	
	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences(
				"Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.imgSearchUser) {
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtSearchKeyword.getWindowToken(), 0);
			if (txtSearchKeyword.getText().toString().equals("")) {
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter username.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(true)
				.create()
				.show();
				txtSearchKeyword.requestFocus();
				return;
			} else {
				searchUserByUsername();
			}
		}
	}

	public void searchUserByUsername() {
		progDialog = ProgressDialog.show(myApp, "Loading", "Please wait....",
				true, true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.searchUserByUserName(globalObj.loggedInUserName, globalObj.loggedInUserPassword, txtSearchKeyword.getText().toString());
				} catch (Exception e) {
					e.printStackTrace();
				}
				searchUserHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler searchUserHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.equals("") && !globalObj.jsonResult.contains("errmsg") && globalObj.jsonResult.contains("userid")) {
				parseUserData();
				Intent intentUserProfile = new Intent(SearchUserByUsername.this, PeopleLikeMeProfile.class);
				intentUserProfile.putExtra("com.teks.flok.peopleInfo", userInfo);
				startActivity(intentUserProfile);
				SearchGroup.group.back();
//				SearchUserByUsername.this.finish();
				
			} else {
				try {
					globalObj.job = new JSONObject(globalObj.jsonResult);
					new AlertDialog.Builder(myApp)
					.setTitle("Search")
					.setMessage(globalObj.job.getString("errdesc").toString())
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					globalObj.jsonResult = null;
					globalObj.job = null;
					txtSearchKeyword.requestFocus();
					return;
				} catch (Exception e) {
				}

			}
		}
	};

	public void parseUserData() {
		try {
			globalObj.job = new JSONObject(globalObj.jsonResult);
			userInfo = new String[6];
			userInfo[0] = globalObj.job.getString("userid").toString();
			userInfo[1] = globalObj.job.getString("avatarflink").toString();
			userInfo[2] = globalObj.job.getString("longitude").toString();
			userInfo[3] = globalObj.job.getString("latitude").toString();
			userInfo[4] = globalObj.job.getString("username").toString();
			userInfo[5] = globalObj.job.getString("cd").toString();
			globalObj.jsonResult = null;
			globalObj.job = null;
		} catch (Exception e) {
		}
	}
	
	public void onBackPressed() {
		SearchGroup.group.back();
	};
}

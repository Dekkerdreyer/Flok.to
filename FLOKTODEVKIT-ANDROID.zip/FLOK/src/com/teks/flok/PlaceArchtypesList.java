package com.teks.flok;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PlaceArchtypesList extends Activity implements OnItemClickListener {

	String[][] arrArchtypes = null;
	String[] arrArchNames = null;
	TextView txtHeader = null;
	ListView placeList = null;
	ArrayAdapter<String> placeAdapter = null;
	LinearLayout viewLast = null, current = null;

	LinearLayout background = null;
	LinearLayout adWhirlPlaceListView = null;
	String backgroundImage = "";
	ProgressDialog progDialog = null;
	GlobalValues globalObj = null;
	Context myApp = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_list_view);

		myApp = SearchGroup.myContext;
		globalObj = GlobalValues.getInstance(); // creates singleton object
		adWhirlPlaceListView = (LinearLayout) findViewById(R.id.adWhirlPlaceListView);
		txtHeader = (TextView) findViewById(R.id.txtTotalPlaces);
		txtHeader.setVisibility(View.GONE);
		placeList = (ListView) findViewById(R.id.placeList);
		background = (LinearLayout) findViewById(R.id.placeListViewBackground);
		placeList.setOnItemClickListener(this);

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication) {
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceListView.invalidate();
		}
		else{
			adWhirlPlaceListView.setVisibility(View.GONE);
		}
		
		
		parseArcheJSON();
		if (arrArchtypes != null) {
			placeAdapter = new myAdapter(this, arrArchNames);
			placeList.setAdapter(placeAdapter);
		}

		// downloadArcheTypes();
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences(
				"Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	public void parseArcheJSON() {
		try {
			if (!globalObj.jsonResult.equals("")
					&& !globalObj.jsonResult.contains("errmsg")) {
				globalObj.job = new JSONObject(globalObj.jsonResult);
				globalObj.ja = globalObj.job.getJSONArray("jsonResult");
				arrArchtypes = new String[globalObj.ja.length()][2];
				arrArchNames = new String[globalObj.ja.length()];
				for (int i = 0; i < globalObj.ja.length(); i++) {
					arrArchtypes[i][0] = globalObj.ja.getJSONObject(i).getString("placetagid").toString();
					arrArchtypes[i][1] = globalObj.ja.getJSONObject(i).getString("arche_type").toString();
					arrArchNames[i] = globalObj.ja.getJSONObject(i).getString("arche_type").toString();
				}
				globalObj.job = null;
				globalObj.ja = null;
				globalObj.jsonResult = null;
			}
		} catch (Exception e) {
		}
	}

	public void createListView() {
		placeAdapter = new myAdapter(PlaceArchtypesList.this, arrArchNames);
		placeList.setAdapter(placeAdapter);
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.row_view, objects);

		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.row_view, null);
			}
			TextView txtFilter = (TextView) v
					.findViewById(R.id.txtListViewPlaceName);
			txtFilter.setText(arrArchNames[position]);
			return v;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (viewLast != null) {
			viewLast.setBackgroundColor(Color.WHITE);
			TextView place = (TextView) viewLast.findViewById(R.id.txtListViewPlaceName);
			place.setBackgroundColor(Color.WHITE);
			place.setTextColor(Color.parseColor("#000000"));
			viewLast.refreshDrawableState();
		}
		int c = Color.parseColor("#0275ee");
		arg1.setBackgroundColor(c);
		TextView currentplace = (TextView) arg1.findViewById(R.id.txtListViewPlaceName);
		currentplace.setBackgroundColor(c);
		currentplace.setTextColor(Color.WHITE);
		arg1.refreshDrawableState();
		viewLast = (LinearLayout) arg1;
		current = (LinearLayout) arg1;
		System.out.println("Placetagid is " + arrArchtypes[arg2][0]);
		downloadMatchingPlaces(arrArchtypes[arg2][0]);

	}

	public void downloadMatchingPlaces(final String tagID) {
		progDialog = ProgressDialog.show(myApp, "Loading", "Please wait....",
				true, true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.searchPlaceByTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword, tagID);
				} catch (Exception e) {
					e.printStackTrace();
				}
				placeHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler placeHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.equals("")) {
				Intent i = new Intent(PlaceArchtypesList.this,
						MatchingPlacesListView.class);
				View view = SearchGroup.group.getLocalActivityManager()
						.startActivity("MPLV",
								i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				SearchGroup.group.replaceView(view);
			}
		}
	};

}

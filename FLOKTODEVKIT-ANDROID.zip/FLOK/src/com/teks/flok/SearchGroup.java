package com.teks.flok;

import java.util.ArrayList;

import android.app.ActivityGroup;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SearchGroup extends ActivityGroup {

    
	public static Context myContext;
	// Keep this in a static variable to make it accessible for all the nesten
	// activities, lets them manipulate the view
	public static SearchGroup group;

	// Need to keep track of the history if you want the back-button to work
	// properly, don't use this if your activities requires a lot of memory.
	private ArrayList<View> history;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.history = new ArrayList<View>();
		myContext = this;
		group = this;

		// Start the root activity withing the group and get its view
		View view = getLocalActivityManager().startActivity("SearchActivity",
				new Intent(this, SearchFlok.class)
						.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				.getDecorView();

		// Replace the view of this ActivityGroup
		replaceView(view);

	}

	public void replaceView(View v) {
		// Adds the old one to history
		history.add(v);
		System.out.println("Size of history is " + history.size());
		// Changes this Groups View to the new View.
		setContentView(v);
	}

	public void back() {
		if (history.size() > 1) {
			history.remove(history.size() - 1);
			setContentView(history.get(history.size() - 1));
		} else {
			finish();
		}
	}

	@Override
	public void onBackPressed() {
		SearchGroup.group.back();
		return;
	}

	
//	@Override
//	protected void onResume() {
//		// TODO Auto-generated method stub
//		super.onResume();
//		while (history.size() > 1) {
//			back();
//		}
//	}
}

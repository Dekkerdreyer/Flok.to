package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

import com.adwhirl.AdWhirlLayout;


public class QuestionAnswer extends Activity implements OnClickListener {
	
	ProgressDialog progDialog = null;
	Spinner spinner1_1 = null;
	Spinner spinner1_2 = null;
	Spinner spinner1_3 = null;
	Spinner spinner2_1 = null;
	Spinner spinner2_2 = null;
	Spinner spinner2_3 = null;
	Spinner spinner3_1 = null;
	Spinner spinner3_2 = null;
	Spinner spinner3_3 = null;	
	Button btnSubmit = null;

	public String[][] musicCategory = null;
	public String[][] attributeCategory = null;
	public String[][] activityCategory = null;
	public int[] ansMusic=new int[3];
	public int[] ansAttribute=new int[3];
	public int[] ansActivity=new int[3];
	boolean retry = true, isConnected = false;
	GlobalValues globalObj = null;
	LinearLayout adWhirlLayoutTag = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.question_answer);
		
		globalObj = GlobalValues.getInstance();
		adWhirlLayoutTag = (LinearLayout) findViewById(R.id.adWhirlQuestionAnswer);
		spinner1_1 = (Spinner) findViewById(R.id.spinner1_1);
		spinner1_2 = (Spinner) findViewById(R.id.spinner1_2);
		spinner1_3 = (Spinner) findViewById(R.id.spinner1_3);
		spinner2_1 = (Spinner) findViewById(R.id.spinner2_1);
		spinner2_2 = (Spinner) findViewById(R.id.spinner2_2);
		spinner2_3 = (Spinner) findViewById(R.id.spinner2_3);
		spinner3_1 = (Spinner) findViewById(R.id.spinner3_1);
		spinner3_2 = (Spinner) findViewById(R.id.spinner3_2);
		spinner3_3 = (Spinner) findViewById(R.id.spinner3_3);
		
		btnSubmit=(Button)findViewById(R.id.btnAnswerSubmit);
		btnSubmit.setOnClickListener(this);
		
		if(globalObj.isDemoApplication) {
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlLayoutTag.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlLayoutTag.invalidate();
		}
		else{
			adWhirlLayoutTag.setVisibility(View.GONE);
		}
		
        
		checkConnectivity();
		
	}
	
	
	public void checkConnectivity(){
		Intent intent_for_dialog = new Intent(this,Dialog.class);
		
		ConnectivityManager connManager =  (ConnectivityManager)getSystemService(QuestionAnswer.CONNECTIVITY_SERVICE);

		 if(connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable()   || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) {
				isConnected = true;
				fetchTagInfo();
			}
			else{
				isConnected = false;
				startActivityForResult(intent_for_dialog,1);
			}
	}
	
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == 1) {
			Bundle receivedSel = data.getExtras();
			String selected_ans = receivedSel.getString("com.teks.flok.choice");
			if(selected_ans.equals("retry")){
				retry = true;
				checkConnectivity();
			}else{
				retry = false;
				this.finish();
			}
		}
	}
	
	
	
	public void fetchTagInfo(){
    	progDialog = ProgressDialog.show(this,"Loading", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult =  obj.fetchTagsCategory("","","0");  // send username as null to get all tags while registartion
    				if(globalObj.jsonResult.equals(""))
    					globalObj.jsonResult = obj.fetchTagsCategory("","","0");  // if not succeeded in one go then try again
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			tagInfoHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
	
	private Handler tagInfoHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
    		if(!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")){
    			populateMusicArr();
        		populateActivityArr();
        		populateAttributeArr();
        		globalObj.jsonResult = null;
        		globalObj.job = null;
        		globalObj.ja = null;
        		populateSpinners();
    		}
			
    	}
    };
    
    public void populateMusicArr(){
    	try{
    		globalObj.job=new JSONObject(globalObj.jsonResult);
    		globalObj.ja=globalObj.job.getJSONArray("jsonResult");
    		int count=0;
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("music"))
    				count++;
    		}
    		musicCategory=new String[count+1][2];
    		int j=1;
    		musicCategory[0][0]="-1";
    		musicCategory[0][1]="Select Tag";
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("music")){
    				musicCategory[j][0]=globalObj.ja.getJSONObject(i).getString("tagid").toString();
    				musicCategory[j][1]=globalObj.ja.getJSONObject(i).getString("tagname").toString();
    				j++;
    			}
    		}
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    public void populateActivityArr(){
    	try{
    		globalObj.job=new JSONObject(globalObj.jsonResult);
    		globalObj.ja=globalObj.job.getJSONArray("jsonResult");
    		int count=0;
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("activities"))
    				count++;
    		}
    		
    		activityCategory=new String[count+1][2];
    		activityCategory[0][0]="-1";
    		activityCategory[0][1]="Select Tag";
    		int j=1;
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("activities")){
    				activityCategory[j][0]=globalObj.ja.getJSONObject(i).getString("tagid").toString();
    				activityCategory[j][1]=globalObj.ja.getJSONObject(i).getString("tagname").toString();
    				j++;
    			}
    		}
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    public void populateAttributeArr(){
    	try{
    		globalObj.job = new JSONObject(globalObj.jsonResult);
    		globalObj.ja = globalObj.job.getJSONArray("jsonResult");
    		int count=0;
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("attributes"))
    				count++;
    		}
    		attributeCategory=new String[count+1][2];
    		attributeCategory[0][0]="-1";
    		attributeCategory[0][1]="Select Tag";
    		int j=1;
    		for(int i=0;i<globalObj.ja.length();i++){
    			if(globalObj.ja.getJSONObject(i).getString("categoryname").toString().equals("attributes")){
    				attributeCategory[j][0]=globalObj.ja.getJSONObject(i).getString("tagid").toString();
    				attributeCategory[j][1]=globalObj.ja.getJSONObject(i).getString("tagname").toString();
    				j++;
    			}
    		}
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    public void populateSpinners(){
    	System.out.println("Attribute array length is "+attributeCategory.length);
    	System.out.println("Activity array length is "+activityCategory.length);
    	System.out.println("Music array length is "+musicCategory.length);
    	String[] strArr=new String[musicCategory.length];
    	for(int i=0;i<musicCategory.length;i++){
    		strArr[i]=musicCategory[i][1];
    	}
    	ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3_1.setAdapter(arrayAdapter);
        spinner3_1.setSelection(0);
        ansMusic[0]=0;
        spinner3_1.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner3_1: position=" + position + " id=" + id);
                        ansMusic[0]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        
        arrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3_2.setAdapter(arrayAdapter);
        spinner3_2.setSelection(0);
        ansMusic[1]=0;
        spinner3_2.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner3_2: position=" + position + " id=" + id);
                        ansMusic[1]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3_3.setAdapter(arrayAdapter);
        spinner3_3.setSelection(0);
        ansMusic[2]=0;
        spinner3_3.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner3_3: position=" + position + " id=" + id);
                        ansMusic[2]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
      
        strArr=new String[activityCategory.length];
        for(int i=0;i<activityCategory.length;i++){
    		strArr[i]=activityCategory[i][1];
    	}
    	arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2_1.setAdapter(arrayAdapter);
        spinner2_1.setSelection(0);
        ansActivity[0]=0;
        spinner2_1.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner2_1: position=" + position + " id=" + id);
                        ansActivity[0]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        
        spinner2_2.setAdapter(arrayAdapter);
        spinner2_2.setSelection(0);
        ansActivity[1]=0;
        spinner2_2.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner2_2: position=" + position + " id=" + id);
                        ansActivity[1]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        spinner2_3.setAdapter(arrayAdapter);
        spinner2_3.setSelection(0);
        ansActivity[2]=0;
        spinner2_3.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner2_3: position=" + position + " id=" + id);
                        ansActivity[2]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        
        
        strArr=new String[attributeCategory.length];
        for(int i=0;i<attributeCategory.length;i++){
    		strArr[i]=attributeCategory[i][1];
    	}
    	arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1_1.setAdapter(arrayAdapter);
        spinner1_1.setSelection(0);
        ansAttribute[0]=0;
        spinner1_1.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner1_1: position=" + position + " id=" + id);
                        ansAttribute[0]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        spinner1_2.setAdapter(arrayAdapter);
        spinner1_2.setSelection(0);
        ansAttribute[1]=0;
        spinner1_2.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner1_2: position=" + position + " id=" + id);
                        ansAttribute[1]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
        spinner1_3.setAdapter(arrayAdapter);
        spinner1_3.setSelection(0);
        ansAttribute[2]=0;
        spinner1_3.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                        AdapterView<?> parent, View view, int position, long id) {
                        System.out.println("Spinner1_3: position=" + position + " id=" + id);
                        ansAttribute[2]=(int)id;
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnAnswerSubmit){
			if(isConnected){
				
				
				if((ansAttribute[0]!=0 || ansAttribute[1]!=0 || ansAttribute[2]!=0) && (ansActivity[0]!=0 || ansActivity[1]!=0 || ansActivity[2]!=0) && (ansMusic[0]!=0 || ansMusic[1]!=0 || ansMusic[2]!=0)){
					saveSelectedTags();
				
				}
				else{
					
					new AlertDialog.Builder(this)
					.setTitle("Info")
					.setMessage("Please select upto 3 tags in each category.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false)
					.create()
					.show();
					return;
				}	

				
				
//				String tagCSV=attributeCategory[ansAttribute[0]][0]+","+attributeCategory[ansAttribute[1]][0]+
//				","+attributeCategory[ansAttribute[2]][0]+","+activityCategory[ansActivity[0]][0]+
//				","+activityCategory[ansActivity[1]][0]+","+activityCategory[ansActivity[2]][0]+
//				","+musicCategory[ansMusic[0]][0]+","+musicCategory[ansMusic[1]][0]+
//				","+musicCategory[ansMusic[2]][0];
//	
//				SharedPreferences userPreferences = getSharedPreferences("Questions",MODE_PRIVATE);
//				SharedPreferences.Editor editor = userPreferences.edit();
//				editor.putString("Attribute_Tag_Id1",attributeCategory[ansAttribute[0]][0]);
//				editor.putString("Attribute_Tag_Name1",attributeCategory[ansAttribute[0]][1]);
//				editor.putString("Attribute_Tag_Id2",attributeCategory[ansAttribute[1]][0]);
//				editor.putString("Attribute_Tag_Name2",attributeCategory[ansAttribute[1]][1]);
//				editor.putString("Attribute_Tag_Id3",attributeCategory[ansAttribute[2]][0]);
//				editor.putString("Attribute_Tag_Name3",attributeCategory[ansAttribute[2]][1]);
//				
//				editor.putString("Activity_Tag_Id1",activityCategory[ansActivity[0]][0]);
//				editor.putString("Activity_Tag_Name1",activityCategory[ansActivity[0]][1]);
//				editor.putString("Activity_Tag_Id2",activityCategory[ansActivity[1]][0]);
//				editor.putString("Activity_Tag_Name2",activityCategory[ansActivity[1]][1]);
//				editor.putString("Activity_Tag_Id3",activityCategory[ansActivity[2]][0]);
//				editor.putString("Activity_Tag_Name3",activityCategory[ansActivity[2]][1]);
//				
//				editor.putString("Music_Tag_Id1",musicCategory[ansMusic[0]][0]);
//				editor.putString("Music_Tag_Name1",musicCategory[ansMusic[0]][1]);
//				editor.putString("Music_Tag_Id2",musicCategory[ansMusic[1]][0]);
//				editor.putString("Music_Tag_Name2",musicCategory[ansMusic[1]][1]);
//				editor.putString("Music_Tag_Id3",musicCategory[ansMusic[2]][0]);
//				editor.putString("Music_Tag_Name3",musicCategory[ansMusic[2]][1]);
//				
//				editor.putString("TagCSV", tagCSV);
//				editor.putString("status", "Complete");	    			
//				editor.commit();
//				
//				Intent avtarIntent=new Intent(QuestionAnswer.this,Avtar.class);
//				startActivity(avtarIntent);
//				QuestionAnswer.this.finish();
		
			}
			else{
				new AlertDialog.Builder(this)
				.setMessage("Network is not available.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		}
	}
	
	
	public void saveSelectedTags(){
		progDialog = ProgressDialog.show(this,"","Please wait....",true,true);
    	new Thread() {
			public void run() {
    			try{
    				String tagCSV="";
//    				String tagValues="";
    				
    				if(ansAttribute[0]!=0){
    					tagCSV+=attributeCategory[ansAttribute[0]][0]+",";
//    					tagValues+=attributeCategory[ansAttribute[0]][1]+"   ";
    				}
    					
    				if(ansAttribute[1]!=0){
    					tagCSV+=attributeCategory[ansAttribute[1]][0]+",";
//    					tagValues+=attributeCategory[ansAttribute[1]][1]+"   ";
    				}
    					
    				if(ansAttribute[2]!=0){
    					tagCSV+=attributeCategory[ansAttribute[2]][0]+",";
//    					tagValues+=attributeCategory[ansAttribute[2]][1]+"   ";
    				}
    					
    				
    				if(ansActivity[0]!=0){
    					tagCSV+=activityCategory[ansActivity[0]][0]+",";
//    					tagValues+=activityCategory[ansActivity[0]][1]+"   ";
    				}
    					
    				if(ansActivity[1]!=0){
    					tagCSV+=activityCategory[ansActivity[1]][0]+",";
//    					tagValues+=activityCategory[ansActivity[1]][1]+"   ";
    				}
    					
    				if(ansActivity[2]!=0){
    					tagCSV+=activityCategory[ansActivity[2]][0]+",";
//    					tagValues+=activityCategory[ansActivity[2]][1]+"   ";
    				}
    					

    				if(ansMusic[0]!=0){
    					tagCSV+=musicCategory[ansMusic[0]][0]+",";
//    					tagValues+=musicCategory[ansMusic[0]][1]+"   ";
    				}
    					
    				if(ansMusic[1]!=0){
    					tagCSV+=musicCategory[ansMusic[1]][0]+",";
//    					tagValues+=musicCategory[ansMusic[1]][1]+"   ";
    				}
    					
    				if(ansMusic[2]!=0){
    					tagCSV+=musicCategory[ansMusic[2]][0]+",";
//    					tagValues+=musicCategory[ansMusic[2]][1]+"   ";
    				}
    				
    				tagCSV=tagCSV.substring(0, tagCSV.length()-1);
//    				tagValues=tagValues.substring(0, tagValues.length()-3);
//    				System.out.println("tagCSV is "+tagCSV);
//    				System.out.println("tag values are "+tagValues);
    				
    				SharedPreferences userPreferences = getSharedPreferences("Questions",MODE_PRIVATE);
    				SharedPreferences.Editor editor = userPreferences.edit();
    				editor.putString("TagCSV", tagCSV);
    				editor.putString("status", "Complete");	    			
    				editor.commit();
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			tagHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();		
	}
	
	private Handler tagHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			Intent avtarIntent=new Intent(QuestionAnswer.this,Avtar.class);
			startActivity(avtarIntent);
			QuestionAnswer.this.finish();
    	}
    };

	
}

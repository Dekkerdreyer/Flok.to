package com.teks.flok;

public class Clustering {

	public final double OFFSET = 268435456;
	public final double RADIUS = 85445659.4471;

	public long lonToX(double lon) {
		return (long) (OFFSET + RADIUS * lon * Math.PI / 180);
	}

	public long latToY(double lat) {
		return (long) (OFFSET - RADIUS
				* Math.log((1 + Math.sin(lat * Math.PI / 180))
						/ (1 - Math.sin(lat * Math.PI / 180))) / 2);
	}

	public long pixelDistance(double lat1, double lon1, double lat2,
			double lon2, int zoom) {
		long x1 = lonToX(lon1);
		long y1 = latToY(lat1);

		long x2 = lonToX(lon2);
		long y2 = latToY(lat2);

		return (long) (Math.sqrt(Math.pow((x1 - x2), 2)
				+ Math.pow((y1 - y2), 2))) >> (21 - zoom);

	}

	// ======================================================================================================================================================================
	// ############################################################ Method to
	// create cluster array from given points.
	// ################################################
	// ======================================================================================================================================================================
	public void cluster(double[][] markers, long distance, int zoom) {
		double[][] tempArr = markers;
		String clustered = "";
		while (tempArr.length > 0) {

			double[] marker = new double[2];
			marker[0] = tempArr[0][0];
			marker[1] = tempArr[0][1];

			// -------------- delete first element ---------------------------

			double[][] temp1 = new double[tempArr.length - 1][2];

			for (int y = 1; y < tempArr.length; y++) {
				temp1[y - 1] = tempArr[y];
			}
			tempArr = new double[temp1.length][2];
			for (int y = 0; y < tempArr.length; y++)
				tempArr[y] = temp1[y];

			// -----------------------------------------------------------------

			String cluster = "";

			for (int x = 0; x < tempArr.length; x++) {
				long pixels = pixelDistance(marker[0], marker[1],
						tempArr[x][0], tempArr[x][1], zoom);
				// System.out.println("Distance between  "+marker[0]+" , "+marker[1]+", and "+tempArr[x][0]+", "+tempArr[x][1]+" is "+pixels);
				if (distance > pixels) {
					if (cluster.length() == 0)
						cluster = tempArr[x][0] + "##" + tempArr[x][1];
					else
						cluster += "###" + tempArr[x][0] + "##" + tempArr[x][1];

					// ------------------- delete element from array
					// ------------------
					temp1 = new double[tempArr.length - 1][2];
					for (int xx = 0, y = 0; y < tempArr.length; y++) {
						if (y == x)
							continue;
						temp1[xx++] = tempArr[y];
					}
					tempArr = new double[temp1.length][2];
					for (int y = 0; y < temp1.length; y++)
						tempArr[y] = temp1[y];
					// ------------------------------------------------------------------------
					x--;
				}
			}

			if (cluster.length() > 0) {
				cluster += "###" + marker[0] + "##" + marker[1];
				if (clustered.length() == 0)
					clustered = cluster;
				else
					clustered += "##~~##" + cluster;
			} else {
				if (clustered.length() == 0)
					clustered = marker[0] + "##" + marker[1];
				else
					clustered += "##~~##" + marker[0] + "##" + marker[1];
			}
		}

		String[] clusteredPoint = clustered.split("##~~##");
		double[][][] arrClustedredPoint = new double[clusteredPoint.length][][];
		for (int i = 0; i < clusteredPoint.length; i++) {
			String[] clus = clusteredPoint[i].split("###");
			arrClustedredPoint[i] = new double[clus.length][2];
			for (int j = 0; j < clus.length; j++) {
				arrClustedredPoint[i][j][0] = Double.parseDouble(clus[j]
						.split("##")[0]);
				arrClustedredPoint[i][j][1] = Double.parseDouble(clus[j]
						.split("##")[1]);
			}
		}

		for (int i = 0; i < arrClustedredPoint.length; i++) {
			System.out.println("Resultant array for cluster " + (i + 1));
			System.out.println("==================================");
			for (int j = 0; j < arrClustedredPoint[i].length; j++) {
				System.out.println("Latitude : " + arrClustedredPoint[i][j][0]
						+ " Longitude : " + arrClustedredPoint[i][j][1]);
			}
			System.out.println("--------------------------------------");
		}
		// System.out.println("Clustered points are "+clustered);
	}

	// =================================================== Clustering of points
	// ends here ==============================================================

	// =====================================================================================================================================================
	// ################################# Method to cluster the place points and
	// return the clustered array of places. ################################
	// =====================================================================================================================================================
	public String[][][] makeClusteredPointsForPlaces(String[][] places,
			long distance, int zoom) {
		// System.out.println("Clustering function has been called. and total number of places are "+places.length);
		String[][] tempArr = places;
		String clustered = "";
		while (tempArr.length > 0) {

			String[][] marker = new String[1][4];
			marker[0] = tempArr[0];

			// -------------- delete first element ---------------------------

			String[][] temp1 = new String[tempArr.length - 1][4];

			for (int y = 1; y < tempArr.length; y++) {
				temp1[y - 1] = tempArr[y];
			}
			tempArr = new String[temp1.length][4];
			for (int y = 0; y < tempArr.length; y++)
				tempArr[y] = temp1[y];

			// -----------------------------------------------------------------

			String cluster = "";

			for (int x = 0; x < tempArr.length; x++) {
				long pixels = pixelDistance(Double.parseDouble(marker[0][3]),
						Double.parseDouble(marker[0][2]), Double
								.parseDouble(tempArr[x][3]), Double
								.parseDouble(tempArr[x][2]), zoom);
				// System.out.println("Distance between  "+marker[0][11]+" , "+marker[0][10]+", and "+tempArr[x][11]+", "+tempArr[x][10]+" is "+pixels);
				if (distance > pixels) {
					if (cluster.length() == 0)
						cluster = tempArr[x][0] + "#~#" + tempArr[x][1] + "#~#"
								+ tempArr[x][2] + "#~#" + tempArr[x][3];
					else
						cluster += "###" + tempArr[x][0] + "#~#"
								+ tempArr[x][1] + "#~#" + tempArr[x][2] + "#~#"
								+ tempArr[x][3];

					// ------------------- delete element from array
					// ------------------
					temp1 = new String[tempArr.length - 1][4];
					for (int xx = 0, y = 0; y < tempArr.length; y++) {
						if (y == x)
							continue;
						temp1[xx++] = tempArr[y];
					}
					tempArr = new String[temp1.length][4];
					for (int y = 0; y < temp1.length; y++)
						tempArr[y] = temp1[y];
					// ------------------------------------------------------------------------
					x--;
				}
			}

			if (cluster.length() > 0) {
				cluster += "###" + marker[0][0] + "#~#" + marker[0][1] + "#~#"
						+ marker[0][2] + "#~#" + marker[0][3];
				if (clustered.length() == 0)
					clustered = cluster;
				else
					clustered += "##~~##" + cluster;
			} else {
				if (clustered.length() == 0)
					clustered = marker[0][0] + "#~#" + marker[0][1] + "#~#"
							+ marker[0][2] + "#~#" + marker[0][3];
				else
					clustered += "##~~##" + marker[0][0] + "#~#" + marker[0][1]
							+ "#~#" + marker[0][2] + "#~#" + marker[0][3];
			}
		}
		// System.out.println("Clustered points are "+clustered);

		String[] clusteredPoint = clustered.split("##~~##");
		String[][][] arrClustedredPoint = new String[clusteredPoint.length][][];
		for (int i = 0; i < clusteredPoint.length; i++) {
			String[] clus = clusteredPoint[i].split("###");
			arrClustedredPoint[i] = new String[clus.length][4];
			for (int j = 0; j < clus.length; j++) {
				String[] arrElement = clus[j].split("#~#");
				for (int k = 0; k < arrElement.length; k++)
					arrClustedredPoint[i][j][k] = arrElement[k];
				// arrClustedredPoint[i][j][0]=clus[j].split("#~#")[0];
				// arrClustedredPoint[i][j][1]=clus[j].split("#~#")[1];
				// arrClustedredPoint[i][j][2]=clus[j].split("#~#")[2];
				// arrClustedredPoint[i][j][3]=clus[j].split("#~#")[3];
				// arrClustedredPoint[i][j][4]=clus[j].split("#~#")[4];
				// arrClustedredPoint[i][j][5]=clus[j].split("#~#")[5];
				// arrClustedredPoint[i][j][6]=clus[j].split("#~#")[6];
				// arrClustedredPoint[i][j][7]=clus[j].split("#~#")[7];
				// arrClustedredPoint[i][j][8]=clus[j].split("#~#")[8];
				// arrClustedredPoint[i][j][9]=clus[j].split("#~#")[9];
				// arrClustedredPoint[i][j][10]=clus[j].split("#~#")[10];
				// arrClustedredPoint[i][j][11]=clus[j].split("#~#")[11];
				// arrClustedredPoint[i][j][12]=clus[j].split("#~#")[12];
				// arrClustedredPoint[i][j][13]=clus[j].split("#~#")[13];
			}
		}

		// for(int i=0;i<arrClustedredPoint.length;i++){
		// System.out.println("Resultant array for cluster "+(i+1));
		// System.out.println("===============================================================================================================================================");
		// for(int j=0;j<arrClustedredPoint[i].length;j++){
		// String str="";
		// for(int k=0;k<arrClustedredPoint[i][j].length;k++){
		// str+=arrClustedredPoint[i][j][k]+"  ";
		// }
		// System.out.println(str);
		// }
		// System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");
		// }
		return arrClustedredPoint;
	}

	// ================================================================ Place
	// clustering ends here
	// ==============================================================================

	// =====================================================================================================================================================
	// ################################# Method to cluster the place points and
	// return the clustered array of places. ################################
	// =====================================================================================================================================================
	public String[][][] makeClusteredPointsForPeople(String[][] people,
			long distance, int zoom) {
		// System.out.println("Clustering function has been called. and total number of places are "+people.length);
		String[][] tempArr = people;
		String clustered = "";
		while (tempArr.length > 0) {

			String[][] marker = new String[1][6];
			marker[0] = tempArr[0];

			// -------------- delete first element ---------------------------

			String[][] temp1 = new String[tempArr.length - 1][6];

			for (int y = 1; y < tempArr.length; y++) {
				temp1[y - 1] = tempArr[y];
			}
			tempArr = new String[temp1.length][6];
			for (int y = 0; y < tempArr.length; y++)
				tempArr[y] = temp1[y];

			// -----------------------------------------------------------------

			String cluster = "";

			for (int x = 0; x < tempArr.length; x++) {
				long pixels = pixelDistance(Double.parseDouble(marker[0][3]),
						Double.parseDouble(marker[0][2]), Double
								.parseDouble(tempArr[x][3]), Double
								.parseDouble(tempArr[x][2]), zoom);
				// System.out.println("Distance between  "+marker[0][3]+" , "+marker[0][2]+", and "+tempArr[x][3]+", "+tempArr[x][2]+" is "+pixels);
				if (distance > pixels) {
					if (cluster.length() == 0)
						cluster = tempArr[x][0] + "#~#" + tempArr[x][1] + "#~#"
								+ tempArr[x][2] + "#~#" + tempArr[x][3] + "#~#"
								+ tempArr[x][4] + "#~#" + tempArr[x][5];
					else
						cluster += "###" + tempArr[x][0] + "#~#"
								+ tempArr[x][1] + "#~#" + tempArr[x][2] + "#~#"
								+ tempArr[x][3] + "#~#" + tempArr[x][4] + "#~#"
								+ tempArr[x][5];

					// ------------------- delete element from array
					// ------------------
					temp1 = new String[tempArr.length - 1][6];
					for (int xx = 0, y = 0; y < tempArr.length; y++) {
						if (y == x)
							continue;
						temp1[xx++] = tempArr[y];
					}
					tempArr = new String[temp1.length][6];
					for (int y = 0; y < temp1.length; y++)
						tempArr[y] = temp1[y];
					// ------------------------------------------------------------------------
					x--;
				}
			}

			if (cluster.length() > 0) {
				cluster += "###" + marker[0][0] + "#~#" + marker[0][1] + "#~#"
						+ marker[0][2] + "#~#" + marker[0][3] + "#~#"
						+ marker[0][4] + "#~#" + marker[0][5];
				if (clustered.length() == 0)
					clustered = cluster;
				else
					clustered += "##~~##" + cluster;
			} else {
				if (clustered.length() == 0)
					clustered = marker[0][0] + "#~#" + marker[0][1] + "#~#"
							+ marker[0][2] + "#~#" + marker[0][3] + "#~#"
							+ marker[0][4] + "#~#" + marker[0][5];
				else
					clustered += "##~~##" + marker[0][0] + "#~#" + marker[0][1]
							+ "#~#" + marker[0][2] + "#~#" + marker[0][3]
							+ "#~#" + marker[0][4] + "#~#" + marker[0][5];
			}
		}
		// System.out.println("Clustered points are "+clustered);

		String[] clusteredPoint = clustered.split("##~~##");
		String[][][] arrClustedredPoint = new String[clusteredPoint.length][][];
		for (int i = 0; i < clusteredPoint.length; i++) {
			String[] clus = clusteredPoint[i].split("###");
			arrClustedredPoint[i] = new String[clus.length][6];
			for (int j = 0; j < clus.length; j++) {
				arrClustedredPoint[i][j][0] = clus[j].split("#~#")[0];
				arrClustedredPoint[i][j][1] = clus[j].split("#~#")[1];
				arrClustedredPoint[i][j][2] = clus[j].split("#~#")[2];
				arrClustedredPoint[i][j][3] = clus[j].split("#~#")[3];
				arrClustedredPoint[i][j][4] = clus[j].split("#~#")[4];
				arrClustedredPoint[i][j][5] = clus[j].split("#~#")[5];

			}
		}

		// for(int i=0;i<arrClustedredPoint.length;i++){
		// System.out.println("Resultant array for cluster "+(i+1));
		// System.out.println("===============================================================================================================================================");
		// for(int j=0;j<arrClustedredPoint[i].length;j++){
		// String str="";
		// for(int k=0;k<arrClustedredPoint[i][j].length;k++){
		// str+=arrClustedredPoint[i][j][k]+"  ";
		// }
		// System.out.println(str);
		// }
		// System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");
		// }
		return arrClustedredPoint;
	}

	// ================================================================ People
	// clustering ends here
	// ==============================================================================

	// ==============================================================================================================================================================================
	// ####################################################################
	// Method to claculate mean point from given points
	// #################################################
	// ==============================================================================================================================================================================
	public double[] calculateMeanPointforPlace(String[][] arrPlace) {
		double lon = 0.0, lat = 0.0;
		double[] meanPoint = new double[2];
		for (int i = 0; i < arrPlace.length; i++) {
			lon += Double.parseDouble(arrPlace[i][2]);
			lat += Double.parseDouble(arrPlace[i][3]);
		}
		meanPoint[0] = lon / arrPlace.length;
		meanPoint[1] = lat / arrPlace.length;
		return meanPoint;
	}

	// ========================================================================
	// Mean point calculation ends here
	// ================================================================

	// ==============================================================================================================================================================================
	// ####################################################################
	// Method to claculate mean point from given points
	// #################################################
	// ==============================================================================================================================================================================
	public double[] calculateMeanPointforPeople(String[][] arrPeople) {
		double lon = 0.0, lat = 0.0;
		double[] meanPoint = new double[2];
		for (int i = 0; i < arrPeople.length; i++) {
			lon += Double.parseDouble(arrPeople[i][2]);
			lat += Double.parseDouble(arrPeople[i][3]);
		}
		meanPoint[0] = lon / arrPeople.length;
		meanPoint[1] = lat / arrPeople.length;
		return meanPoint;
	}
	// ========================================================================
	// Mean point calculation ends here
	// ================================================================

}

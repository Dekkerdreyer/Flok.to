package com.teks.flok;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;

/**
 * 
 * The Class which holds all the tabs and manages navigation. on a tab click, a
 * different activity is invoked which handles the functionality meant for the
 * particular tab
 * 
 */

public class Host extends TabActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.tab_host);
		Resources res = getResources();
		final TabHost tabHost = getTabHost();

		// Initializing Tabs

		tabHost.addTab(tabHost.newTabSpec("searchFlok").setIndicator(
				"Search Flok", res.getDrawable(R.drawable.search_green))
				.setContent(new Intent(this, SearchGroup.class)));

		tabHost.addTab(tabHost.newTabSpec("tag").setIndicator("Tag",
				res.getDrawable(R.drawable.tag_grey)).setContent(
				new Intent(this, TagGroup.class)));

		tabHost.addTab(tabHost.newTabSpec("myProfile").setIndicator(
				"My Profile", res.getDrawable(R.drawable.my_profile_grey))
				.setContent(new Intent(this, MyProfile.class)));

		tabHost.addTab(tabHost.newTabSpec("settings").setIndicator("Settings",
				res.getDrawable(R.drawable.settings_grey)).setContent(
				new Intent(this, SettingsGroup.class)));

		TextView tv = (TextView) tabHost.getTabWidget().getChildAt(0)
				.findViewById(android.R.id.title);
		tv.setTextColor(Color.parseColor("#1F7E08"));

		// tabHost.getTabWidget().setCurrentTab(1);

		tabHost.setOnTabChangedListener(new OnTabChangeListener() {

			@Override
			public void onTabChanged(String tabId) {
				// TODO Auto-generated method stub
				if ("searchFlok".equals(tabId)) {

					ImageView iv = (ImageView) tabHost.getTabWidget()
							.getChildAt(0).findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.search_green));
					TextView tv = (TextView) tabHost.getTabWidget().getChildAt(
							0).findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#1f7e08"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.tag_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.my_profile_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.settings_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));
				} else if ("tag".equals(tabId)) {

					ImageView iv = (ImageView) tabHost.getTabWidget()
							.getChildAt(0).findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.search_grey));
					TextView tv = (TextView) tabHost.getTabWidget().getChildAt(
							0).findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.tag_green));
					tv = (TextView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#1f7e08"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.my_profile_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.settings_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));
				} else if ("myProfile".equals(tabId)) {

					ImageView iv = (ImageView) tabHost.getTabWidget()
							.getChildAt(0).findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.search_grey));
					TextView tv = (TextView) tabHost.getTabWidget().getChildAt(
							0).findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.tag_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.my_profile_green));
					tv = (TextView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#1f7e08"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.settings_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));
				} else if ("settings".equals(tabId)) {

					ImageView iv = (ImageView) tabHost.getTabWidget()
							.getChildAt(0).findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.search_grey));
					TextView tv = (TextView) tabHost.getTabWidget().getChildAt(
							0).findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.tag_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(1)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.my_profile_grey));
					tv = (TextView) tabHost.getTabWidget().getChildAt(2)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#8a8a8a"));

					iv = (ImageView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.icon);
					iv.setImageDrawable(getResources().getDrawable(
							R.drawable.settings_green));
					tv = (TextView) tabHost.getTabWidget().getChildAt(3)
							.findViewById(android.R.id.title);
					tv.setTextColor(Color.parseColor("#1f7e08"));
				}
			}
		});

		// Changing Tabs's height
		// tabHost.getTabWidget().getChildAt(0).getLayoutParams().height = 55;
		// tabHost.getTabWidget().getChildAt(1).getLayoutParams().height = 55;
		// tabHost.getTabWidget().getChildAt(2).getLayoutParams().height = 55;
		// tabHost.getTabWidget().getChildAt(3).getLayoutParams().height = 55;

	}

}
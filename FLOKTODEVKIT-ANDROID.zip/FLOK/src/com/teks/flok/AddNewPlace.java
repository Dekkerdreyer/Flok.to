package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

import com.adwhirl.AdWhirlLayout;

public class AddNewPlace extends Activity implements OnClickListener{
	
	EditText txtPlaceName = null;
	EditText txtAddress1 = null;
	EditText txtAddress2 = null;
	EditText txtAddress3 = null;
	EditText txtCity = null;
	EditText txtState = null;
	EditText txtCountry = null;
	EditText txtWebsite = null;
	Spinner spinnerPlaceType = null;
	Button btnSavePlace = null;
	LinearLayout adWhirlAddPlace = null;
	
	ProgressDialog progDialog = null;
	ScrollView background = null;
	String backgroundImage = "";
	String[][] arrPlaceType = null;
	int selectedType = 0;
	
	boolean placeFlag = false;
	
	public final Context myApp = this;
	GlobalValues globalObj = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.add_place);
		
		globalObj = GlobalValues.getInstance();
		adWhirlAddPlace = (LinearLayout) findViewById(R.id.adWhirlAddPlace);
		txtPlaceName = (EditText) findViewById(R.id.txtPlaceName);
		txtAddress1 = (EditText) findViewById(R.id.txtAddress1);
		txtAddress2 = (EditText) findViewById(R.id.txtAddress2);
		txtAddress3 = (EditText) findViewById(R.id.txtAddress3);
		txtCity = (EditText) findViewById(R.id.txtCity);
		txtState = (EditText) findViewById(R.id.txtState);
		txtCountry = (EditText) findViewById(R.id.txtCountry);
		txtWebsite = (EditText) findViewById(R.id.txtWebsite);
		background = (ScrollView) findViewById(R.id.addPlaceBackground);
		
		spinnerPlaceType = (Spinner) findViewById(R.id.spinnerPlaceType);
		
		btnSavePlace = (Button) findViewById(R.id.btnSavePlace);
		btnSavePlace.setOnClickListener(this);
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlAddPlace.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlAddPlace.invalidate();
		}
		else{
			adWhirlAddPlace.setVisibility(View.GONE);
		}
		
        
        
        backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
        
		getPlaceType();
		
	}
	
	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnSavePlace){
			if(!txtPlaceName.getText().toString().equals("") && !txtAddress1.getText().toString().equals("") && !txtCity.getText().toString().equals("") && !txtState.getText().toString().equals("") && !txtCountry.getText().toString().equals("") && selectedType != 0){
				
				globalObj.placeName=txtPlaceName.getText().toString();  // to keep the track of  place name while tagging the place.
				addNewPlace();   //method to add the place
			}
			else{
				if(txtPlaceName.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter the place name.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtPlaceName.requestFocus();
					return;
				}
				else if(txtAddress1.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter address of the place.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtAddress1.requestFocus();
					return;
				}
				else if(txtCity.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter city name.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtCity.requestFocus();
					return;
				}
				else if(txtState.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter state.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtState.requestFocus();
					return;
				}
				else if(txtCountry.getText().toString().equals("")){
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter country name.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					txtCountry.requestFocus();
					return;
				}
				else if(selectedType==0){
					new AlertDialog.Builder(myApp)
					.setMessage("Please select place type.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(true)
					.create()
					.show();
					spinnerPlaceType.requestFocus();
					return;
				}
			}
		}
	}
	
	public void getPlaceType(){
		progDialog = ProgressDialog.show(this,"Info", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.getPlaceType(globalObj.loggedInUserName, globalObj.loggedInUserPassword);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			placeTypeHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
	
	private Handler placeTypeHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(!globalObj.jsonResult.contains("errmsg")){
				populateTypeArr();
				populateSpinners();	    		
			}			
    	}
    };	
    
    public void populateTypeArr(){
    	try{
    		globalObj.job=new JSONObject(globalObj.jsonResult);
    		globalObj.ja=globalObj.job.getJSONArray("jsonResult");
    		arrPlaceType=new String[globalObj.ja.length()+1][2];
    		arrPlaceType[0][0]="-1";
    		arrPlaceType[0][1]="Select Type";
    		for(int i=0;i<globalObj.ja.length();i++){
    			arrPlaceType[i+1][0]=globalObj.ja.getJSONObject(i).getString("placetypeid").toString();
    			arrPlaceType[i+1][1]=globalObj.ja.getJSONObject(i).getString("type").toString();
    		}
    		globalObj.jsonResult = null;
    		globalObj.job = null;
    		globalObj.ja= null;
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
    
    public void populateSpinners(){  
        
		String[] strArr=new String[arrPlaceType.length];
	    for(int i=0;i<arrPlaceType.length;i++){
			strArr[i]=arrPlaceType[i][1];
		}
	    
	    
	    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,strArr);
	    arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	
	    
	    spinnerPlaceType.setAdapter(arrayAdapter);
	    spinnerPlaceType.setSelection(0);
	    spinnerPlaceType.setOnItemSelectedListener(
	            new OnItemSelectedListener() {
	                public void onItemSelected(
	                    AdapterView<?> parent, View view, int position, long id) {
	                	selectedType=(int)id;
	                }
	
	                public void onNothingSelected(AdapterView<?> parent) {
	                }
	            });
	}

//	================================================================================================
//  ======================  Method to Show progress dialog and add new place  ======================
//  ================================================================================================

    public void addNewPlace(){
    	progDialog = ProgressDialog.show(this,"Info", "please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
//    				jsonString=obj.AddUpdateNewPlcaes(userName, password, txtPlaceName.getText().toString(), "0", txtAddress1.getText().toString(), txtAddress2.getText().toString(), txtAddress3.getText().toString(), txtCity.getText().toString(), txtState.getText().toString(), txtCountry.getText().toString(), txtWebsite.getText().toString(), arrPlaceType[selectedType][0]);
    				globalObj.jsonResult = obj.isValidPlace(globalObj.loggedInUserName, globalObj.loggedInUserPassword, txtAddress1.getText().toString(), txtAddress2.getText().toString(), txtAddress3.getText().toString(), txtCity.getText().toString(), txtState.getText().toString(), txtCountry.getText().toString());
    				if(globalObj.jsonResult.contains("errmsg")){  // means place is not available so add it now.
    					globalObj.jsonResult = obj.AddUpdateNewPlcaes(globalObj.loggedInUserName, globalObj.loggedInUserPassword, txtPlaceName.getText().toString(), "0", txtAddress1.getText().toString(), txtAddress2.getText().toString(), txtAddress3.getText().toString(), txtCity.getText().toString(), txtState.getText().toString(), txtCountry.getText().toString(), txtWebsite.getText().toString(), arrPlaceType[selectedType][0]);
    				}
    				else{
    					placeFlag=true;
    				}
    				System.out.println("Result after adding the place is "+globalObj.jsonResult);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			addPlaceHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
    
    private Handler addPlaceHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(placeFlag){
				globalObj.newPlaceToBeAdded = new String[12];
				globalObj.newPlaceToBeAdded[0] = globalObj.loggedInUserName;
				globalObj.newPlaceToBeAdded[1] = globalObj.loggedInUserPassword;
				globalObj.newPlaceToBeAdded[2] = txtPlaceName.getText().toString();
				globalObj.placeName=txtPlaceName.getText().toString();
				globalObj.newPlaceToBeAdded[3] = "0";
				globalObj.newPlaceToBeAdded[4] = txtAddress1.getText().toString();
				globalObj.newPlaceToBeAdded[5] = txtAddress2.getText().toString(); 
				globalObj.newPlaceToBeAdded[6] = txtAddress3.getText().toString();
				globalObj.newPlaceToBeAdded[7] = txtCity.getText().toString();
				globalObj.newPlaceToBeAdded[8] = txtState.getText().toString();
				globalObj.newPlaceToBeAdded[9] = txtCountry.getText().toString();
				globalObj.newPlaceToBeAdded[10] = txtWebsite.getText().toString();
				globalObj.newPlaceToBeAdded[11] = arrPlaceType[selectedType][0];
				
				Intent intentPlaceSuggestionList=new Intent(AddNewPlace.this,PlaceNameSuggestion.class);
				startActivity(intentPlaceSuggestionList);
				AddNewPlace.this.finish();
				
				
			}
			else{
				
				if(!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")){
					 // launch new activity to select place tag. and finish this activity
					try{
						globalObj.job = new JSONObject(globalObj.jsonResult);
						String placeId=globalObj.job.getString("placeid").toString();
						Intent intentTagNewPlace=new Intent(AddNewPlace.this,AssignTagToNewPlace.class);
						intentTagNewPlace.putExtra("com.teks.flok.placeId", placeId);
						startActivity(intentTagNewPlace);
						AddNewPlace.this.finish();
						globalObj.jsonResult = null;
						globalObj.job = null;
					}catch(Exception e){e.printStackTrace();}
				}
				else{				
					String errDesc="";
					try{
						globalObj.job=new JSONObject(globalObj.jsonResult);
						errDesc=globalObj.job.getString("errdesc").toString();
						globalObj.jsonResult = null;
						globalObj.job = null;
					}catch(Exception e){e.printStackTrace();}
					new AlertDialog.Builder(myApp)
					.setMessage(errDesc)
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false)
					.create()
					.show();
					return;
				}
			}
    	}
    };	
    
//  ================================================================================================


}

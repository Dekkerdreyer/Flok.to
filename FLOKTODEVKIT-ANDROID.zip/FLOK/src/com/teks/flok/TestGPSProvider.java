package com.teks.flok;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class TestGPSProvider extends Activity implements OnClickListener{
	Button btnSend = null;
	EditText txtLongitude = null;
	EditText txtLatitude = null;
	String calledFromActivty = "";
	GlobalValues globalObj = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.test_gps_provider_layout);
		
		globalObj = GlobalValues.getInstance();
		txtLongitude = (EditText) findViewById(R.id.txtLongitude);
		txtLatitude = (EditText) findViewById(R.id.txtLatitude);
		btnSend = (Button)findViewById(R.id.btnTestGPSSend);
		btnSend.setOnClickListener(this);
		Bundle received = getIntent().getExtras();
		calledFromActivty = received.getString("com.teks.flok.calledFrom");
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.btnTestGPSSend){
			if(txtLongitude.getText().toString().length()>1 && txtLatitude.getText().toString().length()>1){
				if(calledFromActivty.equals("Settings")){
					globalObj.longitude = Double.parseDouble(txtLongitude.getText().toString());
					globalObj.latitude = Double.parseDouble(txtLatitude.getText().toString());
					globalObj.isLOcationUpdated = true;
				}
				Intent intent = new Intent();
				intent.putExtra("com.teks.flok.longitude",txtLongitude.getText().toString());
				intent.putExtra("com.teks.flok.latitude",txtLatitude.getText().toString());
		        setResult(200,intent);
		        finish(); 
			}
			else if(txtLongitude.getText().toString().length()==0){
				txtLongitude.requestFocus();
				return;
			}
			else if(txtLatitude.getText().toString().length()==0){
				txtLatitude.requestFocus();
				return;
			}
		}
		
	}
}

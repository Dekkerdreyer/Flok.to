package com.teks.flok;

import java.util.Calendar;

import org.apache.commons.validator.EmailValidator;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class EmailAddress extends Activity implements OnClickListener {

	EditText txtEmail = null;
	EditText txtDOB = null;
	Button btnEmail = null;
	ImageView btnDatePicker = null;
	LinearLayout adWhirlLayoutEmail = null;
	final Context myApp = this;

	private int mYear = 0;
	private int mMonth = 0;
	private int mDay = 0;
	static final int DATE_DIALOG_ID = 0;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.setContentView(R.layout.email_address);

		globalObj = GlobalValues.getInstance();
		adWhirlLayoutEmail = (LinearLayout) findViewById(R.id.adWhirlEmailAddress);
		txtEmail = (EditText) findViewById(R.id.emailAddress);
		txtDOB = (EditText) findViewById(R.id.txtdob);
		btnEmail = (Button) findViewById(R.id.btnEmail);
		btnEmail.setOnClickListener(this);
		btnDatePicker = (ImageView) findViewById(R.id.btnDatePicker);
		btnDatePicker.setOnClickListener(this);

		final Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this,globalObj.adWhirlSDKKey);
			RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
			adWhirlLayoutEmail.addView(adWhirlLayout, adWhirlLayoutParams);
			adWhirlLayoutEmail.invalidate();
		}
		else{
			adWhirlLayoutEmail.setVisibility(View.GONE);
		}
		

	}

	private void updateDisplay() {
		txtDOB.setText(new StringBuilder()
				// Month is 0 based so add 1
				.append(mDay).append("-").append(mMonth + 1).append("-")
				.append(mYear));
	}

	public boolean isValidEmail(String email) {
		if (EmailValidator.getInstance().isValid(email))
			return true;
		else
			return false;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnEmail) {
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(txtEmail.getWindowToken(), 0);
			if (!txtEmail.getText().toString().equals("") && !txtDOB.getText().toString().equals("")) {
				if (isValidEmail(txtEmail.getText().toString())) {

					String dob = txtDOB.getText().toString();
					String d = dob.split("-")[2] + "-" + dob.split("-")[1]+ "-" + dob.split("-")[0];
					System.out.println(d);
					SharedPreferences userPreferences = getSharedPreferences("EmailAddress", MODE_PRIVATE);
					SharedPreferences.Editor editor = userPreferences.edit();
					editor.putString("emailAddress", txtEmail.getText().toString());
					editor.putString("DOB", d);
					editor.putString("status", "Complete");
					editor.commit();

					Intent emailIntent = new Intent(EmailAddress.this, QuestionAnswer.class);
					startActivity(emailIntent);
					EmailAddress.this.finish();
				} else {
					new AlertDialog.Builder(myApp)
					.setMessage("Please enter a valid email address.")
					.setPositiveButton(android.R.string.ok, null)
					.setCancelable(false)
					.create()
					.show();
					txtEmail.requestFocus();
					return;
				}
			} else if (txtEmail.getText().toString().equals("")) {
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter email address.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				txtEmail.requestFocus();
				return;
			} else if (txtDOB.getText().toString().equals("")) {
				new AlertDialog.Builder(myApp)
				.setMessage("Please enter Date of Birth.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			}
		} else if (v.getId() == R.id.btnDatePicker) {
			showDialog(DATE_DIALOG_ID);
		}
	}

	// the callback received when the user "sets" the date in the dialog
	private DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {

		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			mMonth = monthOfYear;
			mDay = dayOfMonth;
			updateDisplay();
		}
	};

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DATE_DIALOG_ID:
			return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
					mDay);
		}
		return null;
	}

}

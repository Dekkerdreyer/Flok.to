package com.teks.flok;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;

public class Main extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.setContentView(R.layout.main);
//    	new Handler().postDelayed(new Runnable() { public void run() { openOptionsMenu(); } }, 1000);
		initializeFlok();
    
	}
  
//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		  MenuInflater inflater = getMenuInflater();
//		  inflater.inflate(R.menu.menu, menu);
//		  return true;
//	}
//	  
//	public boolean onOptionsItemSelected(MenuItem item) {
//		// Handle item selection
//		switch (item.getItemId()) {
//			case R.id.people_like_me:
//				System.out.println("Search Flok => People like me");
//				break;
//	      
//			case R.id.people_by_tag:
//				System.out.println("Search Flok => People bby tag");
//				break;
//	          
//			case R.id.places_i_like:
//				System.out.println("Search Flok => Places I like");
//				break;
//	      
//			case R.id.places_by_tag:
//				System.out.println("Search Flok => Places by tag");
//				break;
//	          
//			case R.id.tag_a_person:
//				System.out.println("Tag => Tag a person");
//				break;
//	          
//			case R.id.tag_a_place:
//				System.out.println("Tag => Tag a place");
//				break;
//	          
//			case R.id.my_profile:
//				System.out.println("My Profile");
//				break;
//	          
//			case R.id.update_my_location:
//				System.out.println("Update my location");
//				break;
//	         
//			default:
//				return super.onOptionsItemSelected(item);
//		}
//		return true;
//	}
  
  
	public void initializeFlok() {
	  
		SharedPreferences editor = getSharedPreferences("UserPassword",MODE_PRIVATE);
		String status = editor.getString("status","Incomplete");
		boolean flag=false;
	  
		if(status.equals("Incomplete")){
			Intent userPassIntent=new Intent(Main.this,UserPassword.class);
			flag=true;
			startActivity(userPassIntent);
			this.finish();
		}
	  
		if(!flag){
			editor=getSharedPreferences("EmailAddress",MODE_PRIVATE);
			status = editor.getString("status","Incomplete");
			if(status.equals("Incomplete")){
				Intent emailAddIntent=new Intent(Main.this,EmailAddress.class);
				flag=true;
				startActivity(emailAddIntent);
				this.finish();
			} 
		}
	  
		if(!flag){
			editor=getSharedPreferences("Questions",MODE_PRIVATE);
			status = editor.getString("status","Incomplete");	  
			if(status.equals("Incomplete")){
				Intent questionIntent=new Intent(Main.this,QuestionAnswer.class);
				flag=true;
				startActivity(questionIntent);
				this.finish();
			} 
		}
	  
		if(!flag){
			editor=getSharedPreferences("Avtar",MODE_PRIVATE);
			status = editor.getString("status","Incomplete");	  
			if(status.equals("Incomplete")){
				Intent avtarIntent=new Intent(Main.this,Avtar.class);
				flag=true;
				startActivity(avtarIntent);
				this.finish();
			}
		}
	  
		if(!flag){
			Intent loginIntent=new Intent(Main.this,Login.class);
			startActivity(loginIntent);
			this.finish();
		}
	}
  
}
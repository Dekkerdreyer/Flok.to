package com.teks.flok;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PeopleListView extends Activity implements OnItemClickListener {

	String[][] arrPeopleDetails = null;
	String[] arrPeopleName = null;
	TextView txtTotalPeople = null;
	ListView peopleList = null;
	ArrayAdapter<String> peopleAdapter = null;
	LinearLayout viewLast = null;
	LinearLayout current = null;
	LinearLayout adWhirlPlaceListView = null;
	LinearLayout background = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_list_view);

		globalObj = GlobalValues.getInstance();
		adWhirlPlaceListView = (LinearLayout) findViewById(R.id.adWhirlPlaceListView);		
		txtTotalPeople = (TextView) findViewById(R.id.txtTotalPlaces);
		peopleList = (ListView) findViewById(R.id.placeList);
		background = (LinearLayout) findViewById(R.id.placeListViewBackground);
		peopleList.setOnItemClickListener(this);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceListView.invalidate();
		}
		else{
			adWhirlPlaceListView.setVisibility(View.GONE);
		}
		
		
		Bundle received = getIntent().getExtras();
		String placeData = received.getString("com.teks.flok.peopleInfo");
		arrPeopleDetails = new String[placeData.split("###").length][6];
		arrPeopleName = new String[arrPeopleDetails.length];
		String[] temp = placeData.split("###");
		for (int i = 0; i < arrPeopleDetails.length; i++) {
			String[] people = temp[i].split("#~#");
			arrPeopleName[i] = people[4];
			for (int j = 0; j < 6; j++) {
				arrPeopleDetails[i][j] = people[j];
			}
		}

		txtTotalPeople.setText("Number of matches: " + arrPeopleDetails.length);

		peopleAdapter = new myAdapter(this, arrPeopleName);
		peopleList.setAdapter(peopleAdapter);

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,
					null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences(
				"Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (viewLast != null) {
			viewLast.setBackgroundColor(Color.WHITE);
			TextView place = (TextView) viewLast.findViewById(R.id.txtListViewPlaceName);
			place.setBackgroundColor(Color.WHITE);
			place.setTextColor(Color.parseColor("#000000"));
			viewLast.refreshDrawableState();
		}
		int c = Color.parseColor("#0275ee");
		arg1.setBackgroundColor(c);
		TextView currentplace = (TextView) arg1.findViewById(R.id.txtListViewPlaceName);
		currentplace.setBackgroundColor(c);
		currentplace.setTextColor(Color.WHITE);
		arg1.refreshDrawableState();
		viewLast = (LinearLayout) arg1;
		current = (LinearLayout) arg1;

		Intent intentPeopleProfile = new Intent(PeopleListView.this, PeopleLikeMeProfile.class);
		intentPeopleProfile.putExtra("com.teks.flok.peopleInfo", arrPeopleDetails[arg2]);
		startActivity(intentPeopleProfile);
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.row_view, objects);

		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.row_view, null);
			}
			TextView txtFilter = (TextView) v
					.findViewById(R.id.txtListViewPlaceName);
			txtFilter.setText(arrPeopleDetails[position][4]);
			return v;
		}
	}

}

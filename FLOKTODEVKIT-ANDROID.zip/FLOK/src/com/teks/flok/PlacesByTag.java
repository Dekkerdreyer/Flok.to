package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

import com.adwhirl.AdWhirlLayout;

public class PlacesByTag extends Activity implements OnClickListener {

	ProgressDialog progDialog = null;
	Spinner spinnerPBT1 = null;
	Spinner spinnerPBT2 = null;
	Spinner spinnerPBT3 = null;
	Spinner spinnerPBT4 = null;
	Button btnSearch = null;
	String placeTags = "";
	public Context myApp = null;
	public String[][] tags = null;
	public int[] criteriaTag = new int[4];
	ScrollView background = null;
	LinearLayout adWhirlPeopleByTag = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.people_by_tag);

		myApp = this;
		globalObj = GlobalValues.getInstance();
		adWhirlPeopleByTag = (LinearLayout) findViewById(R.id.adWhirlPeopleByTag);
		spinnerPBT1 = (Spinner) findViewById(R.id.spinnerPBT1);
		spinnerPBT2 = (Spinner) findViewById(R.id.spinnerPBT2);
		spinnerPBT3 = (Spinner) findViewById(R.id.spinnerPBT3);
		spinnerPBT4 = (Spinner) findViewById(R.id.spinnerPBT4);

		btnSearch = (Button) findViewById(R.id.btnSearchPeopleByTag); // Same  xml is being used for PeopleByTag and PlaceByTag so id are similar for both.
		btnSearch.setOnClickListener(this);
		background = (ScrollView) findViewById(R.id.peopleByTagBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
			RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
			adWhirlPeopleByTag.addView(adWhirlLayout, adWhirlLayoutParams);
			adWhirlPeopleByTag.invalidate();
		}
		else{
			adWhirlPeopleByTag.setVisibility(View.GONE);
		}
		

		fetchTagInfo();

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnSearchPeopleByTag) { 
			if (tags[criteriaTag[0]][0].equals("-1")
					&& tags[criteriaTag[1]][0].equals("-1")
					&& tags[criteriaTag[2]][0].equals("-1")
					&& tags[criteriaTag[3]][0].equals("-1")) {
				
				new AlertDialog.Builder(myApp)
				.setMessage("Sorry, you didn't select any tag.")
				.setPositiveButton(android.R.string.ok, null)
				.setCancelable(false)
				.create()
				.show();
				return;
			} else {
				for (int i = 0; i < criteriaTag.length; i++) {
					if (criteriaTag[i] > 0) {
						if (placeTags.equals("")) {
							placeTags = tags[criteriaTag[i]][0] + ",";
						} else {
							placeTags += tags[criteriaTag[i]][0] + ",";
						}
						System.out.println("tag id " + (i + 1) + "==> "	+ tags[criteriaTag[i]][0]);

					}
				}
				placeTags = placeTags.substring(0, placeTags.length() - 1);

				if (placeTags != "") {
					Intent i = new Intent(this, PlacesByTagMap.class);
					i.putExtra("com.teks.flok.placeTags", placeTags);
					View view = SearchGroup.group.getLocalActivityManager()
							.startActivity("PlacesByTagMap",
									i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
							.getDecorView();
					SearchGroup.group.replaceView(view);
				}
				finish();
			}
		}

	}

	public void fetchTagInfo() {
		progDialog = ProgressDialog
				.show(myApp, "Info", "Please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.fetchAllPlaceTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword);
					if (globalObj.jsonResult.equals(""))
						globalObj.jsonResult = obj.fetchAllPlaceTags(globalObj.loggedInUserName, globalObj.loggedInUserPassword); // if not succeeded in one go then try once again
					} catch (Exception e) {
					e.printStackTrace();
				}
				tagInfoHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler tagInfoHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")) {
				populateTagArr();
				populateSpinners();
			} 
		}
	};

	public void populateTagArr() {
		try {
			globalObj.job = new JSONObject(globalObj.jsonResult);
			globalObj.ja = globalObj.job.getJSONArray("jsonResult");
			tags = new String[globalObj.ja.length() + 1][2];
			tags[0][0] = "-1";
			tags[0][1] = "Select Tag";
			for (int i = 0; i < globalObj.ja.length(); i++) {
				tags[i + 1][0] = globalObj.ja.getJSONObject(i).getString("placetagid")
						.toString();
				tags[i + 1][1] = globalObj.ja.getJSONObject(i).getString("placetagname")
						.toString();
			}
			
			globalObj.jsonResult = null;
			globalObj.job = null;
			globalObj.ja = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void populateSpinners() {

		String[] strArr = new String[tags.length];
		for (int i = 0; i < tags.length; i++) {
			strArr[i] = tags[i][1];
		}

		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(myApp,
				android.R.layout.simple_spinner_item, strArr);
		arrayAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		spinnerPBT1.setAdapter(arrayAdapter);
		spinnerPBT1.setSelection(0);
		spinnerPBT1.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				criteriaTag[0] = (int) id;
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}
		});
		spinnerPBT2.setAdapter(arrayAdapter);
		spinnerPBT2.setSelection(0);
		spinnerPBT2.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				criteriaTag[1] = (int) id;
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}
		});
		spinnerPBT3.setAdapter(arrayAdapter);
		spinnerPBT3.setSelection(0);
		spinnerPBT3.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				criteriaTag[2] = (int) id;
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}
		});

		spinnerPBT4.setAdapter(arrayAdapter);
		spinnerPBT4.setSelection(0);
		spinnerPBT4.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				criteriaTag[3] = (int) id;
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}
		});
	}

}

package com.teks.flok;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ZoomButtonsController;
import android.widget.ZoomControls;
import android.widget.ZoomButtonsController.OnZoomListener;

import com.adwhirl.AdWhirlLayout;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

public class PlacesIWouldLike extends MapActivity implements OnZoomListener {

	List<Overlay> mapOverlays = null;
	Drawable drawable = null;
	MapItemizedOverlay itemizedOverlay = null;

	public Context myApp = null;
	private MapView myMapView = null;
	MapController mc = null;
	GeoPoint p = null;
	public ProgressDialog progDialog = null;
	String[][] arrPlaceDetails = null;
	double longitude = 0, latitude = 0;
	RelativeLayout background = null;
	LinearLayout adWhirlPlacesIWouldLikeMap = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle icicle) {
		// TODO Auto-generated method stub
		super.onCreate(icicle);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.places_i_would_like_map);

		globalObj = GlobalValues.getInstance();
		adWhirlPlacesIWouldLikeMap = (LinearLayout) findViewById(R.id.adWhirlPlacesIWouldLikeMap);
		myMapView = (MapView) findViewById(R.id.mapPlacesIWdLIke);
		myApp = SearchGroup.myContext;
		mapOverlays = myMapView.getOverlays();

		background = (RelativeLayout) findViewById(R.id.placesIWouldLikeBackground);
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage,null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlacesIWouldLikeMap.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlacesIWouldLikeMap.invalidate();
		}
		else{
			adWhirlPlacesIWouldLikeMap.setVisibility(View.GONE);
		}
		
		
		
		LinearLayout linearLayout;
		ZoomControls mZoom;
		linearLayout = (LinearLayout) findViewById(R.id.zoomview);
		mZoom = (ZoomControls) myMapView.getZoomControls();
		linearLayout.addView(mZoom);
		myMapView.invalidate();
		myMapView.displayZoomControls(true);
		myMapView.setStreetView(true);

		myMapView.setBuiltInZoomControls(true);

		ZoomButtonsController zoomButton = myMapView.getZoomButtonsController();
		zoomButton.setOnZoomListener(new ZoomButtonsController.OnZoomListener() {

					@Override
					public void onZoom(boolean zoomIn) {
						// TODO Auto-generated method stub
						int zl = myMapView.getZoomLevel();
						System.out.println("Current zoom level is " + zl);
						if (zoomIn && zl <= 21) {
							myMapView.getOverlays().clear();
							myMapView.invalidate();
							populatePlacesOnMap(zl + 1);
							showCurrentUserOnMap();

							mc = myMapView.getController();
							mc.setZoom(zl + 1);
							myMapView.invalidate();

						} else if (!zoomIn && zl > 1) {
							myMapView.getOverlays().clear();
							myMapView.invalidate();
							populatePlacesOnMap(zl - 1);
							showCurrentUserOnMap();

							mc = myMapView.getController();
							mc.setZoom(zl - 1);
							myMapView.invalidate();
						}
					}

					@Override
					public void onVisibilityChanged(boolean visible) {
						// TODO Auto-generated method stub
					}
				});

		fetchPlaceData();

	}

	@Override
	public void onZoom(boolean zoomIn) {
		// TODO Auto-generated method stub
		int zl = myMapView.getZoomLevel();
		System.out.println("Current zoom level is " + zl);
		if (zoomIn && zl <= 21) {
			myMapView.getOverlays().clear();
			myMapView.invalidate();
			populatePlacesOnMap(zl + 1);
			showCurrentUserOnMap();

			mc = myMapView.getController();
			mc.setZoom(zl + 1);
			myMapView.invalidate();

		} else if (!zoomIn && zl > 1) {
			myMapView.getOverlays().clear();
			myMapView.invalidate();
			populatePlacesOnMap(zl - 1);
			showCurrentUserOnMap();

			mc = myMapView.getController();
			mc.setZoom(zl - 1);
			myMapView.invalidate();
		}
	}

	@Override
	public void onVisibilityChanged(boolean visible) {
		// TODO Auto-generated method stub
	}
	
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	@SuppressWarnings("unchecked")
	private class MapItemizedOverlay extends ItemizedOverlay {
		String text;
		@SuppressWarnings("unused")
		GeoPoint gp;

		private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();

		public MapItemizedOverlay(Drawable defaultMarker, String text, GeoPoint gp) {
			super(boundCenterBottom(defaultMarker));
			this.text = text;
			this.gp = gp;
		}

		public MapItemizedOverlay(Drawable defaultMarker, GeoPoint gp) {
			super(boundCenterBottom(defaultMarker));
			this.gp = gp;
		}

		@Override
		protected OverlayItem createItem(int i) {
			// TODO Auto-generated method stub
			return mOverlays.get(i);

		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return mOverlays.size();
		}

		public void addOverlay(OverlayItem overlay) {
			mOverlays.add(overlay);
			populate();
		}

		@Override
		public boolean onTap(GeoPoint p, MapView mapView) {
			// TODO Auto-generated method stub
			return super.onTap(p, mapView);

		}

		@Override
		protected boolean onTap(int index) {

			// TODO Auto-generated method stub
			String pInfo = mOverlays.get(index).getTitle();
			System.out.println("places are on this point " + pInfo);
			if (!pInfo.equals("current_user")) {

				Intent i = new Intent(PlacesIWouldLike.this, PlaceListView.class);
				i.putExtra("com.teks.flok.placeInfo", pInfo);
				View view = SearchGroup.group.getLocalActivityManager()
						.startActivity("PlacesListView", i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
						.getDecorView();
				SearchGroup.group.replaceView(view);
			}

			return super.onTap(index);
		}

		@Override
		public boolean draw(Canvas canvas, MapView mapView, boolean shadow,
				long when) {
			// TODO Auto-generated method stub
			if (text != "") {
				// Point screenPts = new Point();
				// mapView.getProjection().toPixels(gp, screenPts);
				// Paint textPaint = new Paint();
				// textPaint.setARGB(255, 255, 255, 255);
				// textPaint.setTextAlign(Paint.Align.CENTER);
				// textPaint.setStyle(Style.FILL);
				// textPaint.setTextSize(16);
				// textPaint.setColor(Color.WHITE);
				// textPaint.setTypeface(Typeface.DEFAULT_BOLD);
				// canvas.drawText(text, screenPts.x, screenPts.y-50,
				// textPaint);
			}
			return super.draw(canvas, mapView, shadow, when);
		}
	}

	public void fetchPlaceData() {
		progDialog = ProgressDialog.show(myApp, "Info", "Collecting information, please wait....", true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.getPlaceDetails( globalObj.loggedInUserName, globalObj.loggedInUserPassword, "0");
					System.out.println("Details of places are " + globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				placeInfoHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler placeInfoHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (globalObj.jsonResult.contains("errmsg") || globalObj.jsonResult.equals("")) {
				new AlertDialog.Builder(myApp)
				.setMessage("Sorry. No results match right now.")
				.setPositiveButton(android.R.string.ok,	new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,
							int whichButton) {
						showCurrentUserOnMap();

						mc.animateTo(p);
						mc.setCenter(p);
						mc.setZoom(10);
						myMapView.invalidate();
					}
				})
				.setCancelable(false)
				.create()
				.show();
			} else {
				if (!globalObj.jsonResult.contains("errmsg") && !globalObj.jsonResult.equals("")) {
					parsePlaceData();
					populatePlacesOnMap(10);
					showCurrentUserOnMap();

					mc.animateTo(p);
					mc.setCenter(p);
					mc.setZoom(10);
					myMapView.invalidate();
				}

			}
		}
	};

	public void populatePlacesOnMap(int zoomLevel) {
		if (arrPlaceDetails != null) {
			Clustering objCluster = new Clustering();
			String[][][] arrPlaceCluster = objCluster
					.makeClusteredPointsForPlaces(arrPlaceDetails, 150,
							zoomLevel);
			System.out.println("Total number of clusters are " 	+ arrPlaceCluster.length);
			for (int i = 0; i < arrPlaceCluster.length; i++) {

				if (arrPlaceCluster[i].length >= 1	&& arrPlaceCluster[i].length <= 5)
					drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.blue);
				else if (arrPlaceCluster[i].length >= 6 && arrPlaceCluster[i].length <= 10)
					drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.green);
				else if (arrPlaceCluster[i].length >= 11 && arrPlaceCluster[i].length <= 20)
					drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.yellow);
				else if (arrPlaceCluster[i].length >= 21 && arrPlaceCluster[i].length <= 50)
					drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.orange);
				else if (arrPlaceCluster[i].length > 50)
					drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.red);

				double[] meanPoint = objCluster.calculateMeanPointforPlace(arrPlaceCluster[i]);
				double lng = meanPoint[0];
				double lat = meanPoint[1];
				GeoPoint point = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
				itemizedOverlay = new MapItemizedOverlay(drawable, point);

				String tagData = "";
				for (int j = 0; j < arrPlaceCluster[i].length; j++) {
					String rec = "";
					for (int k = 0; k < arrPlaceCluster[i][j].length; k++) {
						if (rec == "") {
							rec = arrPlaceCluster[i][j][k];
						} else {
							rec += "#~#" + arrPlaceCluster[i][j][k];
						}
					}
					if (tagData.length() > 0)
						tagData += "###" + rec;
					else
						tagData = rec;
				}

				OverlayItem overlayitem = new OverlayItem(point, tagData, "");

				itemizedOverlay.addOverlay(overlayitem);
				mapOverlays.add(itemizedOverlay);
			}
		}
	}

	// =============== Method to show the current user position on map ===================
	public void showCurrentUserOnMap() {
		drawable = PlacesIWouldLike.this.getResources().getDrawable(R.drawable.current_position_of_user);
		double lat = globalObj.latitude;
		double lng = globalObj.longitude;
		System.out.println("Current user position is Long : " + lng + " Lat : "	+ lat);
		GeoPoint point = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
		itemizedOverlay = new MapItemizedOverlay(drawable, point);

		OverlayItem overlayitem = new OverlayItem(point, "current_user", "");
		itemizedOverlay.addOverlay(overlayitem);
		mapOverlays.add(itemizedOverlay);

		p = new GeoPoint((int) (lat * 1E6), (int) (lng * 1E6));
		mc = myMapView.getController();
		// ====================================================================================
	}

	public void parsePlaceData() {
		try {
			globalObj.job = new JSONObject(globalObj.jsonResult);
			globalObj.ja = globalObj.job.getJSONArray("jsonResult");
			arrPlaceDetails = new String[globalObj.ja.length()][4];
			for (int i = 0; i < globalObj.ja.length(); i++) {
				arrPlaceDetails[i][0] = globalObj.ja.getJSONObject(i).getString("placeid").toString();
				arrPlaceDetails[i][1] = globalObj.ja.getJSONObject(i).getString("placename").toString();
				arrPlaceDetails[i][2] = globalObj.ja.getJSONObject(i).getString("longitude").toString();
				arrPlaceDetails[i][3] = globalObj.ja.getJSONObject(i).getString("latitude").toString();
			}
			globalObj.jsonResult = null;
			globalObj.job = null;
			globalObj.ja = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

}

package com.teks.flok;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthConsumer;

import org.json.JSONArray;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TweetListView extends Activity {
	
	String accessToken = "", tokenSecret = "", userName = "", lastFiveTweets = "";
	OAuthConsumer consumer = null;
	OAuthProvider provider = null;
	String[] arrTweets = new String[5];
	public ProgressDialog progDialog = null;
	ListView tweetList = null;
	ArrayAdapter<String> tweetAdapter = null;
	public Context myApp = null;
	LinearLayout background = null, tweetListParentLayout = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;
	LinearLayout adWhirlTweetListView = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.tweet_list_view);

		tweetList = (ListView) findViewById(R.id.tweetList);
		myApp = SettingsGroup.myContext; // SettingsGroup is the main class
											// which launches sub activities.

		globalObj = GlobalValues.getInstance();
		adWhirlTweetListView = (LinearLayout) findViewById(R.id.adWhirlTweetListView);
		background = (LinearLayout) findViewById(R.id.tweetListViewBackground);
		tweetListParentLayout = (LinearLayout) findViewById(R.id.tweetListParentLayout);

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlTweetListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlTweetListView.invalidate();
		}
		else{
			adWhirlTweetListView.setVisibility(View.GONE);
		}
		
		
		readOAuthKeys(); // read accesstoken and secret token and fills the
							// global variables
		System.out.println("Token values are " + accessToken + " "	+ tokenSecret);
		if (!accessToken.equals("") && !tokenSecret.equals("")) {
			fetchTweetsOfUser(); // method to extract the tweets.
		} else {
			Intent intentTwitter = new Intent(TweetListView.this, GetTwitterToken.class);
			startActivityForResult(intentTwitter, 11);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	public void readOAuthKeys() {
		SharedPreferences twitterPreferences = getSharedPreferences("TwitterInfo", MODE_PRIVATE);
		accessToken = twitterPreferences.getString("AccessToken", "");
		tokenSecret = twitterPreferences.getString("TokenSecret", "");
		System.out.println("Access Token and token secret are " + accessToken+ " " + tokenSecret);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		System.out.println("Actvity result is returned");
		if (resultCode == 11) {
			Bundle receivedSel = data.getExtras();
			String status = receivedSel.getString("com.teks.flok.TwitterCredentials");
			if (status.equals("Saved")) {
				readOAuthKeys();
				fetchTweetsOfUser();
			}
		}
	};

	public void fetchTweetsOfUser() {

		progDialog = ProgressDialog.show(myApp, "Loading", "Please wait....",
				true);
		new Thread() {
			public void run() {
				try {

					// here u can get tokens from saved file
					consumer = new DefaultOAuthConsumer(globalObj.consumerKey,globalObj.consumerSecretKey);
					consumer.setTokenWithSecret(accessToken, tokenSecret);
					// URL url = new
					// URL("http://api.twitter.com/1/statuses/user_timeline.xml");
					URL url = new URL("http://api.twitter.com/1/statuses/friends_timeline.json");
					HttpURLConnection request = (HttpURLConnection) url.openConnection();
					consumer.sign(request);
					request.connect();

					System.out.println("Response: " + request.getResponseCode()+ " " + request.getResponseMessage());

					if (request.getResponseCode() == 200 && request.getResponseMessage().equals("OK")) {
						BufferedReader reader = new BufferedReader(	new InputStreamReader(request.getInputStream()));
						StringBuilder stringBuilder = new StringBuilder();
						String line = null;
						while ((line = reader.readLine()) != null) {
							stringBuilder.append(line);
							// System.out.println("status:"+line);
						}
						lastFiveTweets = stringBuilder.toString();
						System.out.println("Last five tweets are "
								+ lastFiveTweets);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				tweetHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler tweetHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (lastFiveTweets != "") {
				parseTweets(); // parse the json and extract required field
				populateList(); // populates tweets in list view.

			} else {
				// tweet fetching fail, retry here

				AlertDialog.Builder alertDialog = new AlertDialog.Builder(myApp);
				alertDialog.setMessage("Tweets couldn't be retrieved.");

				alertDialog.setPositiveButton("Retry",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								fetchTweetsOfUser();
								return;
							}
						});
				alertDialog.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								SettingsGroup.group.back();
								return;
							}
						});
				alertDialog.show();
			}

		}
	};

	public void parseTweets() {
		try {
			globalObj.ja = new JSONArray(lastFiveTweets);
			System.out.println("Number of tweets are " + globalObj.ja.length());
			for (int i = 0; i < 5; i++) {
				arrTweets[i] = globalObj.ja.getJSONObject(i).getString("text").toString();
				// if more information are required to show then parse more
				// element from this json array.
				// right now only text is being parsed i.e. the message.
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public void populateList() {
		tweetListParentLayout.setVisibility(tweetListParentLayout.VISIBLE);
		tweetAdapter = new myAdapter(TweetListView.this, arrTweets);
		tweetList.setAdapter(tweetAdapter);
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.tweet_row, objects);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.tweet_row, null);
			}
			TextView txtTweet = (TextView) v.findViewById(R.id.txtTweetRow);
			txtTweet.setText(arrTweets[position]);
			return v;
		}
	}

	public void onBackPressed() {
		System.out.println("Back button is pressed on TweetListView");
		SettingsGroup.group.back();

	};
}
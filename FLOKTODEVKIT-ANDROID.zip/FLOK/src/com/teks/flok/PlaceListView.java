package com.teks.flok;


import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PlaceListView extends Activity implements OnItemClickListener {

	String[][] arrPlaceDetails = null;
	String[] arrPlaceName = null;
	TextView txtTotalPlaces = null;
	ListView placeList = null;
	ArrayAdapter<String> placeAdapter = null;
	LinearLayout viewLast = null;
	LinearLayout current = null;
	LinearLayout adWhirlPlaceListView = null;
	LinearLayout background = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_list_view);
		
		globalObj = GlobalValues.getInstance();
		adWhirlPlaceListView = (LinearLayout) findViewById(R.id.adWhirlPlaceListView);
		txtTotalPlaces=(TextView)findViewById(R.id.txtTotalPlaces);
		placeList=(ListView)findViewById(R.id.placeList);
		background=(LinearLayout)findViewById(R.id.placeListViewBackground);
		placeList.setOnItemClickListener(this);
		
		if(globalObj.isDemoApplication) {
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceListView.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceListView.invalidate();
		}
		else{
			adWhirlPlaceListView.setVisibility(View.GONE);
		}
		
		Bundle received =getIntent().getExtras();
		String placeData=received.getString("com.teks.flok.placeInfo");
		arrPlaceDetails=new String[placeData.split("###").length][4];
		arrPlaceName=new String[arrPlaceDetails.length];
		String[] temp=placeData.split("###");
		for(int i=0;i<arrPlaceDetails.length;i++){
			String[] place=temp[i].split("#~#");
			arrPlaceName[i]=place[1];
			for(int j=0;j<4;j++){
				arrPlaceDetails[i][j]=place[j];
			}
		}
		
		txtTotalPlaces.setText("Number of matches: "+arrPlaceDetails.length);
		
		placeAdapter=new myAdapter(this, arrPlaceName);
		placeList.setAdapter(placeAdapter);
		
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}		
	}
	
	
	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	
	private class myAdapter extends ArrayAdapter<String> {
    	public myAdapter(Activity context, String[] objects) {
    		// TODO Auto-generated constructor stub
    		super(context, R.layout.row_view, objects);
    		
       }
       @Override
       public View getView(int position, View convertView, ViewGroup parent) {
    	   View v;
    	   if (convertView!= null) {
    		   v = convertView;
   		   
    	   } else {
    		   LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
                v = vi.inflate(R.layout.row_view, null);
    	   }
    	   TextView txtFilter=(TextView) v.findViewById(R.id.txtListViewPlaceName);
    	   txtFilter.setText(arrPlaceDetails[position][1]);
    	   return v;
       }
    }


	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if(viewLast!=null){
			viewLast.setBackgroundColor(Color.WHITE);
			TextView place =(TextView)viewLast.findViewById(R.id.txtListViewPlaceName);
			place.setBackgroundColor(Color.WHITE);		
			place.setTextColor(Color.parseColor("#000000"));	
			viewLast.refreshDrawableState();
		}
		int c = Color.parseColor("#0275ee");
		arg1.setBackgroundColor(c);
		TextView currentplace=(TextView)arg1.findViewById(R.id.txtListViewPlaceName);
		currentplace.setBackgroundColor(c);
		currentplace.setTextColor(Color.WHITE);
		arg1.refreshDrawableState();
		viewLast=(LinearLayout)arg1;
		current=(LinearLayout)arg1;
		
		Intent intentPlaceProfile=new Intent(PlaceListView.this, PlaceProfile.class);
		intentPlaceProfile.putExtra("com.teks.flok.placeID",arrPlaceDetails[arg2][0]);
		startActivity(intentPlaceProfile);
		
	}	
}

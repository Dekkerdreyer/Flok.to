package com.teks.flok;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PlaceProfile extends Activity implements OnClickListener{
	
	TextView txtPlaceName = null;
	TextView txtAddress = null;
	TextView txtCity = null;
	TextView txtState = null;
	TextView txtCountry = null;
	TextView txtWebsite = null;
	WebView placeTagsWebView = null;
	ProgressDialog progDialog = null;
	Context myApp = this;
	Button btnTagThisPlace = null;
	String[] arrPlaceInfo = null;
	String tags = "", placeId = "", jsonString = "";
	
	ScrollView background = null;
	LinearLayout adWhirlPlaceProfile = null;
	String backgroundImage = "";
	GlobalValues globalObj = null;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_profile);
		
		globalObj = GlobalValues.getInstance();
		adWhirlPlaceProfile = (LinearLayout) findViewById(R.id.adWhirlPlaceProfile);
		txtPlaceName=(TextView)findViewById(R.id.txtPlaceName);
		txtAddress=(TextView)findViewById(R.id.txtAddress);
		txtCity=(TextView)findViewById(R.id.txtCity);
		txtState=(TextView)findViewById(R.id.txtState);
		txtCountry=(TextView)findViewById(R.id.txtCountry);
		txtWebsite=(TextView)findViewById(R.id.txtWebsite);
		placeTagsWebView=(WebView)findViewById(R.id.placeTagWebView);
		
		btnTagThisPlace=(Button)findViewById(R.id.btnTagThisPlace);
		btnTagThisPlace.setOnClickListener(this);
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceProfile.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceProfile.invalidate();
		}
		else{
			adWhirlPlaceProfile.setVisibility(View.GONE);
		}
		
		
		Bundle received = getIntent().getExtras();
		placeId = received.getString("com.teks.flok.placeID");
		
		background=(ScrollView)findViewById(R.id.placeProfileBackground);
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}		
		
		
		WebSettings settings = placeTagsWebView.getSettings(); 
        settings.setPluginsEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUserAgentString("Mozilla/5.0 (Linux; U; Android 1.6; en-us; Android Dev Phone 1 Build/DRC83) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1");
        placeTagsWebView.setWebChromeClient(new WebChromeClient());  
        placeTagsWebView.setScrollBarStyle(2);
        placeTagsWebView.setHorizontalScrollBarEnabled(false);
        placeTagsWebView.setVerticalScrollBarEnabled(false);
		
        downloadPlaceInfo();
		
	}
	
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		backgroundImage=getBackgroundImage();
		if(!backgroundImage.equals("NA")){
			 int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			 background.setBackgroundResource(imageResource);
		}		
	}
	
	public String getBackgroundImage(){
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings",MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}
	
	
	public void fetchPlaceTags(){
    	progDialog = ProgressDialog.show(myApp,"Info", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj=HttpConnection.getInstance();
    				jsonString = obj.getPlaceTagsOfAPlace(globalObj.loggedInUserName, globalObj.loggedInUserPassword, placeId);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			placeTagHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
	
	private Handler placeTagHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			fillPlaceInfo();
    	}
    };
    

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnTagThisPlace){
			Intent intentTagThisPlace=new Intent(PlaceProfile.this, TagToPlace.class);
			intentTagThisPlace.putExtra("com.teks.flok.placeId", placeId);
			startActivityForResult(intentTagThisPlace, 1);
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == 1) {
			Bundle receivedSel = data.getExtras();
			String newTags = receivedSel.getString("com.teks.flok.newTags");
			if(newTags.length()>0){
				placeTagsWebView.loadData(newTags, "text/html", "UTF-8");
			}
		}
	}
	
	public void downloadPlaceInfo(){
		progDialog = ProgressDialog.show(myApp,"Loading", "Please wait....",true, true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.getPlaceInfo(globalObj.loggedInUserName, globalObj.loggedInUserPassword, placeId);
    				System.out.println("Place details are "+globalObj.jsonResult);
    				jsonString = obj.getPlaceTagsOfAPlace(globalObj.loggedInUserName, globalObj.loggedInUserPassword, placeId);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			placeHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
	}
	private Handler placeHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(!globalObj.jsonResult.equals("") && !globalObj.jsonResult.contains("errmsg")){
				parsePlaceJsonData();
				fillPlaceInfo();
			}
    	}
    };
    
    public void parsePlaceJsonData(){
    	try{
    		globalObj.job = new JSONObject(globalObj.jsonResult);
    		arrPlaceInfo = new String[9];
    		arrPlaceInfo[0] = globalObj.job.getString("placename").toString();
    		arrPlaceInfo[1] = globalObj.job.getString("address1").toString();
    		if(globalObj.job.getString("address2").toString().length()>0){
    			arrPlaceInfo[2] = globalObj.job.getString("address2").toString();
    		}
    		else{
    			arrPlaceInfo[2] = "NA";
    		}
    		if(globalObj.job.getString("address3").toString().length()>0){
    			arrPlaceInfo[3] = globalObj.job.getString("address3").toString();
    		}
    		else{
    			arrPlaceInfo[3] = "NA";
    		}
    		arrPlaceInfo[4] = globalObj.job.getString("city").toString();
    		arrPlaceInfo[5] = globalObj.job.getString("state").toString();
    		arrPlaceInfo[6] = globalObj.job.getString("country").toString();
    		if(globalObj.job.getString("website").toString().length()>1){
    			arrPlaceInfo[7] = globalObj.job.getString("website").toString();
    		}
    		else{
    			arrPlaceInfo[7] = "N/A";
    		}
    		arrPlaceInfo[8] = globalObj.job.getString("cd").toString();  
    		
    		globalObj.jsonResult = null;
    		globalObj.job = null;
    	}catch(Exception e){}
    }
    
    public void fillPlaceInfo(){
		txtPlaceName.setText(arrPlaceInfo[0]);
		globalObj.placeName = arrPlaceInfo[0];
		String addr = arrPlaceInfo[1];
		if(!arrPlaceInfo[2].equals("NA"))
			addr+=",\n"+arrPlaceInfo[2];
		if(!arrPlaceInfo[3].equals("NA"))
			addr+=",\n"+arrPlaceInfo[3];
		txtAddress.setText(addr);
		txtCity.setText(arrPlaceInfo[4]);
		txtState.setText(arrPlaceInfo[5]);
		txtCountry.setText(arrPlaceInfo[6]);
		txtWebsite.setText(arrPlaceInfo[7]);
		placeTagsWebView.loadData(jsonString, "text/html", "UTF-8");
	}
}

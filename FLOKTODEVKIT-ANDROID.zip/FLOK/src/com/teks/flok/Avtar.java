package com.teks.flok;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONObject;

import com.adwhirl.AdWhirlLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class Avtar extends Activity implements OnClickListener, LocationListener {
	
	Button btnGenericAvtar = null;
	Button btnUserAvtar = null;
	Button btnDone = null;
	ImageView imgViewAvtar = null;
	
	public ProgressDialog progDialog = null;
	LocationManager locationManager = null;
	boolean flag = false;
	boolean retry = true;
	final Context myApp = this;
	String userName = "", password = "", emailId = "", dob = "", avtarName = "";
	String profileResult = "";
	boolean GPSFlag = false;
	GlobalValues globalObj = null;
	LinearLayout adWhirlLayoutAvatar = null;
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.avtar);
		
		globalObj = GlobalValues.getInstance();
		adWhirlLayoutAvatar = (LinearLayout) findViewById(R.id.adWhirlAvtar);
		btnGenericAvtar=(Button)findViewById(R.id.btnAvtarGeneric);
		btnGenericAvtar.setOnClickListener(this);
		btnUserAvtar=(Button)findViewById(R.id.btnAvtarUser);
		btnUserAvtar.setOnClickListener(this);
		btnDone=(Button)findViewById(R.id.btnAvtarDone);
		btnDone.setOnClickListener(this);
		
		imgViewAvtar=(ImageView)findViewById(R.id.avtar);
		WriteAvtarFiles();
		
		
		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || !isConnected()){
			new AlertDialog.Builder(myApp)
			.setTitle("Error!")
			.setIcon(R.drawable.error)
			.setMessage("Flok is unable to connect at this time due to poor gps reception. Please try again later.")
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            		public void onClick(DialogInterface dialog, int whichButton) {
            			Avtar.this.finish();
            		}})
			.setCancelable(false)
			.create()
			.show();
			return;
		}
		if(!globalObj.testFlag)
			startLocationServices();  // start  GPS service
		
		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlLayoutAvatar.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlLayoutAvatar.invalidate();
		}
		else{
			adWhirlLayoutAvatar.setVisibility(View.GONE);
		}
		
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnAvtarGeneric){
			Intent genericAvtarIntent=new Intent(this,GenericAvtarGallery.class);
			startActivityForResult(genericAvtarIntent, 10);
		}
		else if(v.getId()==R.id.btnAvtarDone){
			readUserInfo();
			if(isConnected()){
				if(globalObj.testFlag){
					Intent intentTestGPSProvider = new Intent(Avtar.this, TestGPSProvider.class);
					intentTestGPSProvider.putExtra("com.teks.flok.calledFrom", "Avtar");
					startActivityForResult(intentTestGPSProvider, 200);
				}
				else{
					makeNewProfile();
				}				
			}
			else{
				Intent intent_for_dialog = new Intent(this,Dialog.class);
				startActivityForResult(intent_for_dialog,1);
			}
		}
		else if(v.getId()==R.id.btnAvtarUser){
//			Intent userAvtarIntent=new Intent(this,AvtarsFromSDCard.class);
//			startActivityForResult(userAvtarIntent, 4);
			startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 4);
//			startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), 3);

		}
	}
	
	public void makeNewProfile(){
    	progDialog = ProgressDialog.show(this,"Info", "Profile is being created. Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				while(!GPSFlag){
    					
    				}    	
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.createNewProfile(userName, password, emailId, dob, ""+globalObj.longitude, ""+globalObj.latitude, avtarName);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			profileHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
	
	private Handler profileHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(globalObj.jsonResult.contains("userid")){
				String userId="";
				try{
					globalObj.job=new JSONObject(globalObj.jsonResult);
					userId = globalObj.job.getString("userid").toString();
				}catch(Exception e){ e.printStackTrace();}
				SharedPreferences userPreferences = getSharedPreferences("LoginInfo",MODE_PRIVATE);
    			SharedPreferences.Editor editor = userPreferences.edit();
    			editor.putString("UserName", userName);
    			editor.putString("Password",password);
    			editor.putString("UserID", userId);
    			globalObj.loggedInUserName = userName;
    			globalObj.loggedInUserPassword = password;
    			stopLocationServices();
    			editor.commit();  
    			String tagCSV = "";
    			globalObj.jsonResult = null;
    			globalObj.job = null;
    			userPreferences = getSharedPreferences("Questions",MODE_PRIVATE);
    			tagCSV = userPreferences.getString("TagCSV", "NULL");
    			
    			System.out.println(tagCSV);
    			
    			updateUserTag(userName, password, userId, tagCSV);
			}
    	}
    };
	
    
    
    public void updateUserTag(final String userName, final String password, final String userId, final String tagCSV){
    	progDialog = ProgressDialog.show(this,"Info", "Please wait....",true);
    	new Thread() {
			public void run() {
    			try{
    				HttpConnection obj = HttpConnection.getInstance();
    				globalObj.jsonResult = obj.updateUserTag(userName, password, userId, tagCSV);
    				System.out.println("Tag update response from server " +globalObj.jsonResult);
    			}
    			catch (Exception e)
    			{ 
    				e.printStackTrace();
    			}
    			tagHandler.sendEmptyMessage(0);
    			progDialog.dismiss(); 
    		}
    	}.start();
    }
    
    private Handler tagHandler = new Handler() {
		@Override
    	public void handleMessage(Message msg) {
			if(globalObj.jsonResult.contains("userid")){
				 System.out.println("Tag information has been updated");
				 SharedPreferences userPreferences = getSharedPreferences("Avtar",MODE_PRIVATE);
				 SharedPreferences.Editor editor = userPreferences.edit();
				 editor.putString("status", "Complete");	    			
				 editor.commit();
				 globalObj.jsonResult = null;
				 Intent tabIntent=new Intent(Avtar.this, Host.class);
				 startActivity(tabIntent);
				 Avtar.this.finish();
			}
    	}
    };
    

	 public boolean isConnected(){
			ConnectivityManager connManager =  (ConnectivityManager)getSystemService(Avtar.CONNECTIVITY_SERVICE);
			 if(connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isAvailable()   || connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isAvailable()) {
				return true;
			}
			else{
				return false;
			}
		}

	 private void startLocationServices() {
	    	Log.d("GPS","Location Services Started");
	    	locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
	    	locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, this);
	    }

		 private void stopLocationServices() {
			 Log.d("GPS","Location Services Stopped");
			 if(locationManager != null) {
				 locationManager.removeUpdates(this);
			 }
		 }
	 
	 
	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		if (location != null) {
	        globalObj.longitude = location.getLongitude();
	        globalObj.latitude = location.getLatitude();
	        GPSFlag=true;
	    }
		System.out.println("Longitude and latitude are "+globalObj.longitude+ " "+globalObj.latitude);
	}
	
	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == 1) {
			Bundle receivedSel = data.getExtras();
			String selected_ans = receivedSel.getString("com.teks.flok.choice");
			if(selected_ans.equals("retry")){
				retry = true;
			}else{
				retry = false;
				this.finish();
			}
		}else if(requestCode==10){
			try{
				Bundle receivedSel = data.getExtras();
				String selected_avatr = receivedSel.getString("com.teks.flok.genericAvtar");
				
				Drawable d;
				switch(Integer.parseInt(selected_avatr)){
				case 1:
					d=getResources().getDrawable(R.drawable.avatar1);
					break;
				case 2:
					d=getResources().getDrawable(R.drawable.avatar2);
					break;
				case 3:
					d=getResources().getDrawable(R.drawable.avatar3);
					break;
				case 4:
					d=getResources().getDrawable(R.drawable.avatar4);
					break;
				case 5:
					d=getResources().getDrawable(R.drawable.avatar5);
					break;
				case 6:
					d=getResources().getDrawable(R.drawable.avatar6);
					break;
				case 7:
					d=getResources().getDrawable(R.drawable.avatar7);
					break;
				case 8:
					d=getResources().getDrawable(R.drawable.avatar8);
					break;
				case 9:
					d=getResources().getDrawable(R.drawable.avatar9);
					break;
				case 10:
					d=getResources().getDrawable(R.drawable.avatar10);
					break;
				default :
					d=getResources().getDrawable(R.drawable.avatar10);
					break;	
				}
				imgViewAvtar.setBackgroundDrawable(d);
				avtarName="/data/data/com.teks.flok/avatar"+selected_avatr+".png";
			}catch(Exception e){e.printStackTrace();}
			
		}
		else if(requestCode==3){
			// manipulate SD card images here (Internal storage )
			if (resultCode == Activity.RESULT_OK) {
//				Uri selectedImage = data.getData();
//				InputStream fileInputStream=this.getContentResolver().openInputStream(selectedImage);

				// TODO Do something with the select image URI
			}
		}
		else if(requestCode==4){ // Phone external storage
			try{
				
				if( data != null){
					System.gc();
					Uri selectedImage = data.getData();				
					Cursor cursor = getContentResolver().query(selectedImage, null, null, null, null);
					cursor.moveToFirst();
					int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
					avtarName = cursor.getString(idx);
					System.out.println("Path of the image to be uploaded is "+avtarName);
					flag=true;
					cursor.close();
					
					File file = new File(avtarName);
					FileInputStream fis = null;
					fis = new FileInputStream(file);
					Bitmap bitmapOrg = BitmapFactory.decodeStream(fis);
					
					int width = bitmapOrg.getWidth();
			        int height = bitmapOrg.getHeight();
			        int newWidth = globalObj.imageResizeWidth;
			        int newHeight = globalObj.imageResizeHeight;
			        
			        float scaleWidth = ((float) newWidth) / width;
			        float scaleHeight = ((float) newHeight) / height;
			        
			        Matrix matrix = new Matrix();
			        matrix.postScale(scaleWidth, scaleHeight);
			        Bitmap resizedBitmap = Bitmap.createBitmap(bitmapOrg, 0, 0,width, height, matrix, true);
			        BitmapDrawable bmd = new BitmapDrawable(resizedBitmap);
			        
			        imgViewAvtar.setBackgroundDrawable(bmd);
				}
//				Bundle receivedSel = data.getExtras();
//				String selected_avatr = receivedSel.getString("com.teks.flok.userAvtar");			
//				Drawable d=Drawable.createFromPath(selected_avatr);
//				imgViewAvtar.setBackgroundDrawable(d);
//				System.out.println("Picture returned from SD card intent "+selected_avatr);
//				avtarName=selected_avatr;
			}catch(Exception e){e.printStackTrace();}
		}
		else if(requestCode == 200){
			if(data != null){
				Bundle received = data.getExtras();
				String lng = received.getString("com.teks.flok.longitude");
				String lat = received.getString("com.teks.flok.latitude");
				if(lng.length()>0 && lat.length()>0){
					globalObj.longitude = Double.parseDouble(lng);
			        globalObj.latitude = Double.parseDouble(lat);
			        GPSFlag = true;
			        makeNewProfile();
				}
			}
		}
	}
	
	public void readUserInfo(){
		SharedPreferences editor = getSharedPreferences("UserPassword",MODE_PRIVATE);
		userName=editor.getString("userName", "null");
		password=editor.getString("password", "null");
		editor=getSharedPreferences("EmailAddress",MODE_PRIVATE);
		emailId=editor.getString("emailAddress", "null");
		dob=editor.getString("DOB", "null");
	}
	
	public void WriteAvtarFiles(){
		SharedPreferences userPreferences = getSharedPreferences("AvtarFileStatus",MODE_PRIVATE);
		int flag=userPreferences.getInt("Flag", 0);
		AssetManager mgr=getAssets();
		if(flag==0){
			try{
				for(int i=1;i<=10;i++){
					
					FileOutputStream fist = openFileOutput("avatar"+i+".png", Context.MODE_PRIVATE);
					
					
					System.out.println("Avtar files are being created");
					File f=new File("/data/data/com.teks.flok/avatar"+i+".png");
					InputStream inputStream=mgr.open("avtars/avatar"+i+".png");
				    OutputStream out=new FileOutputStream(f);
				    byte buf[]=new byte[1024];
				    int len;
				    while((len=inputStream.read(buf))>0){
				    	out.write(buf,0,len);
				    	fist.write(buf,0,len);
				    }
					fist.close();
				    out.close();
				    inputStream.close();
				}
    			SharedPreferences.Editor editor = userPreferences.edit();
    			editor.putInt("Flag", 1);	    			
    			editor.commit();
			}catch(Exception e){ 
				e.printStackTrace();
			}
		} // flag if closes
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		stopLocationServices();
	}
	
}

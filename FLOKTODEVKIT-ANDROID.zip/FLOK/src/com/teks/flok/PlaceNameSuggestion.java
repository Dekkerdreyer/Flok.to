package com.teks.flok;

import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.adwhirl.AdWhirlLayout;

public class PlaceNameSuggestion extends Activity implements
		OnItemClickListener, OnClickListener {

	String[][] arrPlaceDetails = null;
	String[] arrPlaceName = null;
	ListView placeList = null;
	ArrayAdapter<String> placeAdapter = null;
	LinearLayout viewLast = null;
	LinearLayout current = null;
	Button btnAddPlaceAnyWay = null;
	LinearLayout background = null;
	LinearLayout adWhirlPlaceSuggestionList = null;
	String backgroundImage = "";
	ProgressDialog progDialog = null;
	GlobalValues globalObj = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.place_suggestion_list);

		globalObj = GlobalValues.getInstance();
		adWhirlPlaceSuggestionList = (LinearLayout) findViewById(R.id.adWhirlPlaceSuggestionList);
		placeList = (ListView) findViewById(R.id.placeSuggestionList);
		background = (LinearLayout) findViewById(R.id.suggestionPlaceListViewBackground);
		placeList.setOnItemClickListener(this);

		btnAddPlaceAnyWay = (Button) findViewById(R.id.btnAddPlaceAnyWay);
		btnAddPlaceAnyWay.setOnClickListener(this);

		if(globalObj.isDemoApplication){
			final float DENSITY = getResources().getDisplayMetrics().density;
			int scaledWidth = (int) (DENSITY * globalObj.DIP_WIDTH + 0.5f);
			int scaledHeight = (int) (DENSITY * globalObj.DIP_HEIGHT + 0.5f);
			AdWhirlLayout adWhirlLayout = new AdWhirlLayout(this, globalObj.adWhirlSDKKey);
	        RelativeLayout.LayoutParams adWhirlLayoutParams = new RelativeLayout.LayoutParams(scaledWidth, scaledHeight);
	        adWhirlPlaceSuggestionList.addView(adWhirlLayout, adWhirlLayoutParams);
	        adWhirlPlaceSuggestionList.invalidate();
		}
		else{
			adWhirlPlaceSuggestionList.setVisibility(View.GONE);
		}
		
		
		arrPlaceName = new String[globalObj.placeDetails.length];
		for (int i = 0; i < arrPlaceName.length; i++) {
			arrPlaceName[i] = globalObj.placeDetails[i][1];
		}

		placeAdapter = new myAdapter(this, arrPlaceName);
		placeList.setAdapter(placeAdapter);

		backgroundImage = getBackgroundImage();
		if (!backgroundImage.equals("NA")) {
			int imageResource = getResources().getIdentifier(backgroundImage, null, getPackageName());
			background.setBackgroundResource(imageResource);
		}
	}

	public String getBackgroundImage() {
		SharedPreferences backgroundImagePref = getSharedPreferences("Settings", MODE_PRIVATE);
		return backgroundImagePref.getString("BackgroundImage", "NA");
	}

	private class myAdapter extends ArrayAdapter<String> {
		public myAdapter(Activity context, String[] objects) {
			// TODO Auto-generated constructor stub
			super(context, R.layout.suggestion_list_row, objects);

		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v;
			if (convertView != null) {
				v = convertView;

			} else {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				v = vi.inflate(R.layout.suggestion_list_row, null);
			}
			TextView txtPlace = (TextView) v.findViewById(R.id.txtsuggestionPlaceName);
			txtPlace.setText(globalObj.placeDetails[position][1]);
			TextView txtAddress = (TextView) v.findViewById(R.id.txtsuggestionPlaceAddress);
			String address = "";

			address = globalObj.placeDetails[position][2];
			if (globalObj.placeDetails[position][3].length() > 0)
				address = ",\n" + globalObj.placeDetails[position][3];
			if (globalObj.placeDetails[position][4].length() > 0)
				address = ",\n" + globalObj.placeDetails[position][4];
			txtAddress.setText(address);
			return v;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (viewLast != null) {
			viewLast.setBackgroundColor(Color.WHITE);

			TextView place = (TextView) viewLast.findViewById(R.id.txtsuggestionPlaceName);
			place.setBackgroundColor(Color.WHITE);
			place.setTextColor(Color.parseColor("#000000"));

			TextView address = (TextView) viewLast.findViewById(R.id.txtsuggestionPlaceAddress);
			address.setBackgroundColor(Color.WHITE);
			address.setTextColor(Color.parseColor("#000000"));

			viewLast.refreshDrawableState();
		}
		int c = Color.parseColor("#0275ee");
		arg1.setBackgroundColor(c);

		TextView currentplace = (TextView) arg1.findViewById(R.id.txtsuggestionPlaceName);
		currentplace.setBackgroundColor(c);
		currentplace.setTextColor(Color.WHITE);

		TextView currentAddress = (TextView) arg1.findViewById(R.id.txtsuggestionPlaceAddress);
		currentAddress.setBackgroundColor(c);
		currentAddress.setTextColor(Color.WHITE);

		arg1.refreshDrawableState();
		viewLast = (LinearLayout) arg1;
		current = (LinearLayout) arg1;

		Intent intentTagNewPlace = new Intent(PlaceNameSuggestion.this, AssignTagToNewPlace.class);
		intentTagNewPlace.putExtra("com.teks.flok.placeId",globalObj.placeDetails[arg2][0]);
		startActivity(intentTagNewPlace);
		PlaceNameSuggestion.this.finish();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnAddPlaceAnyWay) {
			addPlaceAnyWay();
		}
	}

	public void addPlaceAnyWay() {
		progDialog = ProgressDialog.show(this, "Loading", "Please wait....",
				true);
		new Thread() {
			public void run() {
				try {
					HttpConnection obj = HttpConnection.getInstance();
					globalObj.jsonResult = obj.AddUpdateNewPlcaes(globalObj.newPlaceToBeAdded[0], globalObj.newPlaceToBeAdded[1], globalObj.newPlaceToBeAdded[2], globalObj.newPlaceToBeAdded[3], globalObj.newPlaceToBeAdded[4], globalObj.newPlaceToBeAdded[5], globalObj.newPlaceToBeAdded[6], globalObj.newPlaceToBeAdded[7], globalObj.newPlaceToBeAdded[8], globalObj.newPlaceToBeAdded[9], globalObj.newPlaceToBeAdded[10], globalObj.newPlaceToBeAdded[11]);
					if (globalObj.jsonResult.equals(""))
						globalObj.jsonResult = obj.AddUpdateNewPlcaes(globalObj.newPlaceToBeAdded[0], globalObj.newPlaceToBeAdded[1], globalObj.newPlaceToBeAdded[2], globalObj.newPlaceToBeAdded[3], globalObj.newPlaceToBeAdded[4], globalObj.newPlaceToBeAdded[5], globalObj.newPlaceToBeAdded[6], globalObj.newPlaceToBeAdded[7], globalObj.newPlaceToBeAdded[8], globalObj.newPlaceToBeAdded[9], globalObj.newPlaceToBeAdded[10], globalObj.newPlaceToBeAdded[11]);
					System.out.println("Result after adding the place is "+ globalObj.jsonResult);
				} catch (Exception e) {
					e.printStackTrace();
				}
				addPlaceHandler.sendEmptyMessage(0);
				progDialog.dismiss();
			}
		}.start();
	}

	private Handler addPlaceHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			if (!globalObj.jsonResult.contains("errmsg")) {
				// launch new activity to select place tag. and finish this
				// activity
				try {
					globalObj.newPlaceToBeAdded = null;
					globalObj.placeDetails = null;

					globalObj.job = new JSONObject(globalObj.jsonResult);
					String placeId = globalObj.job.getString("placeid").toString();
					globalObj.jsonResult = null;
					globalObj.job = null;
					Intent intentTagNewPlace = new Intent(PlaceNameSuggestion.this, AssignTagToNewPlace.class);
					intentTagNewPlace.putExtra("com.teks.flok.placeId", placeId);
					startActivity(intentTagNewPlace);
					PlaceNameSuggestion.this.finish();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	};
}

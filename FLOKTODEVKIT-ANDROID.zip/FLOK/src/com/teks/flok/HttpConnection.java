package com.teks.flok;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public class HttpConnection {
	public String baseURL="http://staging.teks.co.in/Flok/index.php/";
	private static HttpConnection instance = null;
	
    protected HttpConnection() {
         // Exists only to defeat instantiation.
    }
    
    public static HttpConnection getInstance() {
        if(instance == null) {
           instance = new HttpConnection();
        }
        return instance;
     }

    
    
	
//	================================================================================
//	This method is used to check whether the provided user name is available or not.
//	================================================================================
	public String userAvailable(String userName){
		String urlStr=baseURL+"user/validateusername?username="+URLEncoder.encode(userName);
		URL url = null;
		BufferedReader reader = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
 		    StringBuilder stringBuilder = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
//	==============================================================================
	//get user details
	public String getUserDetails(String userName, String password){
		String urlStr=baseURL+"user/getuserdetails?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		System.out.println("URL to update usertag "+urlStr);
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {

			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(25000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		   return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
	
//	==============================================================================
//	This method is used to fetch all tags with category information.  
//	==============================================================================
	public String fetchTagsCategory(String userName, String password, String categoryId){
		String urlStr=baseURL+"usertag/gettagcategories?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&categoryid="+categoryId;
		System.out.println("requesting URL is "+urlStr);
		URL url = null;
		BufferedReader reader = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
 		    StringBuilder stringBuilder = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}	
//	==============================================================================
	
//	==============================================================================
//	==============  Method to create new profile =================================
//	==============================================================================
	
	public String createNewProfile(String userName, String password, String emailId, String dob, String longitude, String latitude, String avtarName){
		 try {
	        	File uploadFile =new File(avtarName);
		        FileInputStream fileInputStream = new FileInputStream(uploadFile);
		
		        String lineEnd = "\r\n";
		        String twoHyphens = "--";
		        String boundary = "*****";
		        
		        String urlStr=baseURL+"user/newprofile";
		        URL connectURL = new URL(urlStr);
		        HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();
		        System.out.println("Connection established");
		        conn.setDoInput(true);
		        conn.setDoOutput(true);
		        conn.setUseCaches(false);
		        conn.setRequestMethod("POST");
		        conn.setRequestProperty("Connection","Keep-Alive");
		        conn.setRequestProperty("Content-Type","multipart/form-data;boundary="+boundary);
		        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"media\";filename=\""+avtarName +"\"" + lineEnd);
		    	dos.writeBytes(lineEnd);
		        int bytesAvailable = fileInputStream.available();
		        int maxBufferSize = 1024;
		        int bufferSize = Math.min(bytesAvailable, maxBufferSize);
		    	byte[] buffer = new byte[bufferSize];
		        int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
		        while (bytesRead > 0){        
		                dos.write(buffer, 0, bufferSize);
		                bytesAvailable = fileInputStream.available();
		                bufferSize = Math.min(bytesAvailable, maxBufferSize);
		                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
		        }
		        dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
//		        --------------------------------------------------------------
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"username\";" + lineEnd);
		    	dos.writeBytes(lineEnd);
		    	dos.writeBytes(userName);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		        
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"password\";" + lineEnd);
		    	dos.writeBytes(lineEnd);
		    	dos.writeBytes(password);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		        
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"email\";" + lineEnd);
		    	dos.writeBytes(lineEnd);
		    	dos.writeBytes(emailId);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		        
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"dateofbirth\";" + lineEnd);
		    	dos.writeBytes(lineEnd);
		    	dos.writeBytes(dob);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		        
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"longitude\";" + lineEnd);
		        dos.writeBytes(lineEnd);
		    	dos.writeBytes(longitude);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		        
		        dos.writeBytes(twoHyphens + boundary + lineEnd);
		        dos.writeBytes("Content-Disposition: form-data;	name=\"latitude\";" + lineEnd);
		        dos.writeBytes(lineEnd);
		    	dos.writeBytes(latitude);
		    	dos.writeBytes(lineEnd);
		        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
		    	
//		        ------------------------------------------------------------------
		        
		        fileInputStream.close();
		        dos.flush();
		        InputStream is = conn.getInputStream();
		        int ch;
		        StringBuffer b =new StringBuffer();
		        while( ( ch = is.read() ) != -1 ) {
		                b.append( (char)ch );
		        }
		        String s=b.toString();
		        dos.close();
		        return s;
	       }
	       catch (Exception ex) {
	    	   ex.printStackTrace();
	       }
	       return null;
	}
	
//	==============================================================================
	
	
//	==============================================================================
//	=====================  Method to update user tag =============================
//	==============================================================================
	public String updateUserTag(String userName, String password, String userId, String tagCSV){
		String urlStr=baseURL+"usertag/updateusertag?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&touserid="+userId+"&tagcsv="+tagCSV;
		System.out.println("URL to update usertag "+urlStr);
		URL url = null;
		BufferedReader reader = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
 		    StringBuilder stringBuilder = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
//	==============================================================================
	
	
//	==============================================================================
//	============================  Login Method  ==================================
//	==============================================================================
	public String userLogin(String userName, String password,String longitude,String latitude){
		String urlStr=baseURL+"user/updategps?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&longitude="+longitude+"&latitude="+latitude;
		System.out.println("Requesting url is "+urlStr);
		URL url = null;
		BufferedReader reader = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
 		    StringBuilder stringBuilder = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		
		return null;
	}
	
//	==============================================================================
	
//	==============================================================================
//	=========  Method to fetch People like me within 10 KM of range  =============
//	==============================================================================
	public String peopleLikeMe(String userName, String password) {
		
		String urlStr=baseURL+"user/searchpeoplelikeme?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		System.out.println("requesting url is "+urlStr);
		URL url = null;
		BufferedReader reader = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(500000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
 		    StringBuilder stringBuilder = new StringBuilder();
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
//	==============================================================================
	
	
//	==============================================================================
//	====================== Method to get people's avatar ==========================
//	This method resizes the image too according to given size
//	==============================================================================
	public Drawable[] getPeopleAvtar(String[] avtarURL){
		Drawable[] d=new Drawable[avtarURL.length];
		URL myFileUrl = null;
		try {
			for(int i=0;i<avtarURL.length;i++){
				myFileUrl = new URL(avtarURL[i]);
				HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
				conn.setReadTimeout(500000);
				conn.setDoInput(true);
				conn.connect();
				InputStream is = conn.getInputStream();
				
//				---------------------------------------------------------  // code to resize the image
				Bitmap bitmapOrg = BitmapFactory.decodeStream(is);
				
				int width = bitmapOrg.getWidth();
		        int height = bitmapOrg.getHeight();
		        int newWidth = 40;
		        int newHeight = 40;
		        
		        float scaleWidth = ((float) newWidth) / width;
		        float scaleHeight = ((float) newHeight) / height;
		        
		        Matrix matrix = new Matrix();
		        matrix.postScale(scaleWidth, scaleHeight);
		        Bitmap resizedBitmap = Bitmap.createBitmap(bitmapOrg, 0, 0,width, height, matrix, true); 
		        BitmapDrawable bmd = new BitmapDrawable(resizedBitmap);
		        d[i]=bmd;	        
//				---------------------------------------------------------
				
//				d[i]=Drawable.createFromStream(is,"");
			}
			return d;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return d;
	}	
//	==============================================================================
	
	
//	==============================================================================
//	===================  Method to fetch data for User's own Profile  ====================
//	==============================================================================
	public String getUserProfileDetails(String userName, String password){
		String urlStr=baseURL+"user/getuserdetails?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		System.out.println("URL to update usertag "+urlStr);
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
//			-------------------  Get User details in this section -------------------------
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
//		    ---------------------------User detail section ends here--------------------------
		    
		    stringBuilder.append("###"); // Information separator
		    
//		    -------------------------- Get self tag details in this section ------------------
		    urlStr=baseURL+"usertag/getselftags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		    url = new URL(urlStr);
		    connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
//		    --------------------------- self tag section ends here ---------------------------
		    
		    stringBuilder.append("###"); // Information separator
		    
//		    ----------------------  get tags given by others ----------------------------------
		    urlStr=baseURL+"usertag/gettagsbyother?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		    url = new URL(urlStr);
		    connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }		    
//		    -----------------------------------------------------------------------------------
 		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    return stringBuilder.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
//	==============================================================================
	
	
//	==============================================================================
//	===============    Method to extract self existing self tags  ================
//	==============================================================================
	public String getSelfTags(String userName, String password){
		String urlStr=baseURL+"usertag/getselftags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
 		    connection.setRequestMethod("GET");
 		    connection.setReadTimeout(25000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
		}catch(Exception e){
			e.printStackTrace();
		}
		return stringBuilder.toString();
	}
//	==============================================================================
	
	
	
//	==============================================================================
//	======================   Downlaod User Avatar for My Profile    ==============
//	==============================================================================
	public Drawable getUserAvatar(String imageURL){
		Drawable d=null;
		GlobalValues globalObj = GlobalValues.getInstance();
		URL myFileUrl = null;
		try {
			myFileUrl = new URL(imageURL);
			HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
			conn.setDoInput(true);
			conn.connect();
			InputStream is = conn.getInputStream();
//			---------------------------------------------------------  // code to resize the image
			Bitmap bitmapOrg = BitmapFactory.decodeStream(is);
			
			int width = bitmapOrg.getWidth();
	        int height = bitmapOrg.getHeight();
	        int newWidth = globalObj.imageResizeWidth;
	        int newHeight = globalObj.imageResizeHeight;
	        
	        float scaleWidth = ((float) newWidth) / width;
	        float scaleHeight = ((float) newHeight) / height;
	        
	        Matrix matrix = new Matrix();
	        matrix.postScale(scaleWidth, scaleHeight);
	        Bitmap resizedBitmap = Bitmap.createBitmap(bitmapOrg, 0, 0,width, height, matrix, true); 
	        BitmapDrawable bmd = new BitmapDrawable(resizedBitmap);
	        d=bmd;	        
//			---------------------------------------------------------
			return d;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return d;
	}
//	==============================================================================
	
//	==============================================================================
//	================  Method to Clear all tags and update new tags ===============
//	==============================================================================
	public String clearTagsAndUpdateSelfTags(String userName, String password,String userId,String tagCSV, String clearOPtion){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"usertag/clearalltags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&tags="+clearOPtion;
			System.out.println("requested url to clear the tags "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(25000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    
		    if(stringBuilder.toString().contains("errmsg")){
		    	return stringBuilder.toString();
		    }
		    else{ // means tags are deleted successfully
		    	urlStr=baseURL+"usertag/updateusertag?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&touserid="+userId+"&tagcsv="+tagCSV;
		    	System.out.println("requested url to update the user tag "+urlStr);
		    	url = new URL(urlStr);
				connection = (HttpURLConnection) url.openConnection();
	 		    connection.setRequestMethod("GET");
	 		    connection.setReadTimeout(25000);
	 		    connection.connect();
	 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	 		    stringBuilder = new StringBuilder();
			    while ((line = reader.readLine()) != null) {
			    	stringBuilder.append(line);
			    }
	 		    try{
	 		    	reader.close();
	 		    }catch(IOException ioe){ioe.printStackTrace();}
	 		    connection.disconnect();
	 		    System.out.println("Response after updating the tag is "+stringBuilder.toString());
	 		    return stringBuilder.toString();
		    }			
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
//	==============================================================================
	
	
//	==============================================================================
//	================  Method to Clear all tags and update new tags ===============
//	==============================================================================
	public String clearTagsByOthers(String userName, String password,String userId, String clearOPtion){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"usertag/clearalltags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&tags="+clearOPtion;
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(25000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
		}
		catch(Exception e){e.printStackTrace();}
	    	return stringBuilder.toString();
	}
//	==============================================================================
	
	
//	==============================================================================
//	==================  Method to upload new avatar file  ========================
//	==============================================================================
	public String uploadNewAvatar(String userName, String password, String avatarFile){
		try {
        	File uploadFile =new File(avatarFile);
	        FileInputStream fileInputStream = new FileInputStream(uploadFile);
	
	        String lineEnd = "\r\n";
	        String twoHyphens = "--";
	        String boundary = "*****";
	        
	        String urlStr=baseURL+"user/uploadavatar";
	        URL connectURL = new URL(urlStr);
	        HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();
	        System.out.println("Connection established");
	        conn.setDoInput(true);
	        conn.setDoOutput(true);
	        conn.setUseCaches(false);
	        conn.setRequestMethod("POST");
	        conn.setRequestProperty("Connection","Keep-Alive");
	        conn.setRequestProperty("Content-Type","multipart/form-data;boundary="+boundary);
	        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
	        dos.writeBytes(twoHyphens + boundary + lineEnd);
	        dos.writeBytes("Content-Disposition: form-data;	name=\"media\";filename=\""+avatarFile +"\"" + lineEnd);
	    	dos.writeBytes(lineEnd);
	        int bytesAvailable = fileInputStream.available();
	        int maxBufferSize = 1024;
	        int bufferSize = Math.min(bytesAvailable, maxBufferSize);
	    	byte[] buffer = new byte[bufferSize];
	        int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
	        while (bytesRead > 0){        
	                dos.write(buffer, 0, bufferSize);
	                bytesAvailable = fileInputStream.available();
	                bufferSize = Math.min(bytesAvailable, maxBufferSize);
	                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
	        }
	        dos.writeBytes(lineEnd);
	        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
	        
//	        --------------------------  user name and password   ---------------------
	        dos.writeBytes(twoHyphens + boundary + lineEnd);
	        dos.writeBytes("Content-Disposition: form-data;	name=\"username\";" + lineEnd);
	    	dos.writeBytes(lineEnd);
	    	dos.writeBytes(userName);
	    	dos.writeBytes(lineEnd);
	        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
	        
	        dos.writeBytes(twoHyphens + boundary + lineEnd);
	        dos.writeBytes("Content-Disposition: form-data;	name=\"password\";" + lineEnd);
	    	dos.writeBytes(lineEnd);
	    	dos.writeBytes(password);
	    	dos.writeBytes(lineEnd);
	        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
//	        --------------------------------------------------------------------------
	        fileInputStream.close();
	        dos.flush();
	        InputStream is = conn.getInputStream();
	        int ch;
	        StringBuffer b =new StringBuffer();
	        while( ( ch = is.read() ) != -1 ) {
	                b.append( (char)ch );
	        }
	        String s=b.toString();
	        dos.close();
	        return s;
       }
       catch (Exception ex) {
    	   ex.printStackTrace();
       }
	        
		return null;
	}
//	==============================================================================
	
//	==============================================================================
//	====================   Method to update the password   =======================
//	==============================================================================
	public String changePassword(String userName, String password, String newPassword){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"user/changepassword?username="+URLEncoder.encode(userName)+"&oldpassword="+password+"&newpassword="+newPassword;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
//	==============================================================================
	
	
//	==============================================================================
//	======================  Method to get all tags of a user  ====================
//	==============================================================================
	public String getAllTags(String userName, String password, String userId){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"usertag/getusertags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&userid="+userId;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
//	================================================================================
	
	
//	================================================================================
//	=====================  Method to search people by tag  =========================
//	================================================================================
	public String searchPeopleByTag(String userName, String password, String tagCSV){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"usertag/searchuserbytag?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&tagcsv="+tagCSV;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	================================================================================
	
//	================================================================================
//	========================  Method to fetch all place tags  ======================
//	================================================================================
	public String fetchAllPlaceTags(String userName, String password){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"placetag/gettags?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
//	================================================================================
	
	
//	================================================================================
//	=======================  Method to search place by tags  =======================
//	================================================================================
	
	public String searchPlaceByTags(String userName, String password, String tagCSV){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"placetag/searchplacebytag?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&tagcsv="+tagCSV;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
//	================================================================================
	
//	================================================================================
//	================  Method to get place type  ====================================
//	================================================================================
	public String getPlaceType(String userName, String password){
		
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"place/gettypes?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	================================================================================
	
	
//	=================================================================================
//	====================================  Validate new place  =======================
//	=================================================================================
	public String isValidPlace(String userName, String password, String address1,String address2,String address3, String city, String state, String country){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			
			String params="username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&address1="+URLEncoder.encode(address1)+"&address2="+URLEncoder.encode(address2)+"&address3="+URLEncoder.encode(address3)+"&city="+URLEncoder.encode(city)+"&state="+URLEncoder.encode(state)+"&country="+URLEncoder.encode(country);
			//String urlStr=baseURL+"place/validateplace?username="+userName+"&password="+password+"&address1="+address1+"&address2="+address2+"&address3="+address3+"&city="+city+"&state="+state+"&country="+country;
			String urlStr=baseURL+"place/validateplace?"+params;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	=================================================================================
	
	
	
//	================================================================================
//	==============  Method to Add and Update new Places  ===========================
//	================================================================================
	public String AddUpdateNewPlcaes(String userName, String password, String placeName, String placeId, String address1,String address2,String address3, String city, String state, String country, String website, String placeTypeId){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			//String urlStr=baseURL+"place/updateplace?username="+userName+"&password="+password+"&placename="+placeName+"&placeid="+placeId+"&address1="+address1+"&address2="+address2+"&address3="+address3+"&city="+city+"&state="+state+"&country="+country+"&website="+website+"&placetypeid="+placeTypeId;
			String params="username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&placename="+URLEncoder.encode(placeName)+"&placeid="+placeId+"&address1="+URLEncoder.encode(address1)+"&address2="+URLEncoder.encode(address2)+"&address3="+URLEncoder.encode(address3)+"&city="+URLEncoder.encode(city)+"&state="+URLEncoder.encode(state)+"&country="+URLEncoder.encode(country)+"&website="+URLEncoder.encode(website)+"&placetypeid="+placeTypeId;
			//String urlStr=baseURL+"place/updateplace?username="+userName+"&password="+password+"&placename="+placeName+"&placeid="+placeId+"&address1="+address1+"&address2="+address2+"&address3="+address3+"&city="+city+"&state="+state+"&country="+country+"&website="+website+"&placetypeid="+placeTypeId;
			String urlStr=baseURL+"place/updateplace?"+params;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	================================================================================
	
	
//	================================================================================
//	===========================  Method to tag a place =============================
//	================================================================================
	public String tagAPlace(String userName, String password, String placeId, String tagCSV){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"placetag/updateplacetag?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&tagcsv="+tagCSV+"&placeid="+placeId;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
//	================================================================================
	
	
//	=================================================================================
//	========== Method to fetch place details (Within 10KM of range ==============
//	This method works for both all places and any specific places. If placetypeid is 0 
//	then it gives all the places otherwise specific places according to placetypeid.
//	=================================================================================
	public String getPlaceDetails(String userName, String password, String placeTypeId){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
			String urlStr=baseURL+"place/searchplace?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&placetypeid="+placeTypeId;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	=================================================================================
	
//	=================================================================================
//	======================  Get place tags of a place by its place id  ==============
//	=================================================================================
	public String getPlaceTagsOfAPlace(String userName, String password, String placeId){
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = null;
		try {
//			String urlStr=baseURL+"placetag/getplacetags?username="+userName+"&password="+password+"&placeid="+placeId;
			String urlStr=baseURL+"placetag/getplacetagshtml?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&placeid="+placeId;
			System.out.println("Requesting URL is "+urlStr);
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
 		    connection.setReadTimeout(50000);
 		    connection.connect();
 		    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		    while ((line = reader.readLine()) != null) {
		    	stringBuilder.append(line);
		    }
		    try{
 		    	reader.close();
 		    }catch(IOException ioe){ioe.printStackTrace();}
 		    connection.disconnect();
 		    System.out.println("Server response is "+stringBuilder.toString());
	 		return stringBuilder.toString();			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
//	=================================================================================
	
	
//	=================================================================================
//	=========  Get place tags assigned by this user to any specific place  ==========
//	=================================================================================
	public String getPlaceTagsAssignedByUser(String userName, String password, String placeId)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"placetag/getplacetagsbyuser?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&placeid="+placeId;
		System.out.println("Requesting URL is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
//	=================================================================================
//	====================  Method to change the email address  =======================
//	=================================================================================
	public String changeEmailAddress(String userName, String password, String emailAddress)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"user/editprofilevalues?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&email="+emailAddress;
		System.out.println("Requesting URL is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
//	=================================================================================
//	====================  Method to delete the user account   =======================
//	=================================================================================
	public String deleteAccount(String userName, String password)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"usertag/deleteprofile?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		System.out.println("Requesting URL is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
	
//	=================================================================================
//	====================      Method to download archetypes       ===================
//	=================================================================================
	public String getArcheTypes(String userName, String password)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"placetag/getplacearchetypes?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password);
		System.out.println("Requesting URL is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
	
//	=================================================================================
//	====================      Method to download place info       ===================
//	=================================================================================
	public String getPlaceInfo(String userName, String password, String placeId)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"place/getplacedetails?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&placeid="+placeId;
		System.out.println("Requesting URL for place info is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response for place info is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
	
//	=================================================================================
//	====================        Method to recover password        ===================
//	=================================================================================
	public String recoverPassword(String userName)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"user/forgotpassword?username="+URLEncoder.encode(userName);
		System.out.println("Requesting URL for password recovery is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response for password recovery is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
//	=================================================================================
//	====================    ethod to Search user by user name      ==================
//	=================================================================================
	public String searchUserByUserName(String userName, String password, String searchKeyword)throws Exception{
		StringBuilder stringBuilder = new StringBuilder();
		URL url = null;
		BufferedReader reader = null;
		String line = "";
		
		String urlStr=baseURL+"user/searchbyusername?username="+URLEncoder.encode(userName)+"&password="+URLEncoder.encode(password)+"&searchusername="+URLEncoder.encode(searchKeyword);
		System.out.println("Requesting URL search use by user name is "+urlStr);
		url = new URL(urlStr);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
	    connection.setReadTimeout(50000);
	    connection.connect();
	    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	    while ((line = reader.readLine()) != null) {
	    	stringBuilder.append(line);
	    }
	    reader.close();
	    connection.disconnect();
	    System.out.println("Server response for search user is "+stringBuilder.toString());
 		return stringBuilder.toString();			
	}
//	=================================================================================
	
}
